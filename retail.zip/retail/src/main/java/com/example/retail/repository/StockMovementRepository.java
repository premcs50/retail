package com.example.retail.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.StockMovement;

public interface StockMovementRepository extends JpaRepository<StockMovement, Long> {
	List<StockMovement> findByProductIdOrderByOccurredAtDesc(Long productId);
	List<StockMovement> findByOccurredAtBetweenOrderByOccurredAtDesc(LocalDateTime start, LocalDateTime end);
	List<StockMovement> findAllByOrderByOccurredAtDesc();
}
