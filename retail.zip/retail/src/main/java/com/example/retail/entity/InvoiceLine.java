package com.example.retail.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "invoice_lines")
@Getter
@Setter
@NoArgsConstructor
public class InvoiceLine {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private Long invoiceId;

	@Column(nullable = false)
	private Long productId;

	@Column(nullable = false, length = 180)
	private String productName;

	@Column(nullable = false, precision = 12, scale = 3)
	private BigDecimal quantity;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal unitPrice;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal unitCost = BigDecimal.ZERO;

	@Column(nullable = false, precision = 7, scale = 4)
	private BigDecimal taxRate;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal discount;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal lineTotal;
}
