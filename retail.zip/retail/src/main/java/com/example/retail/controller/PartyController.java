package com.example.retail.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.retail.controller.ApiModels.CustomerRequest;
import com.example.retail.controller.ApiModels.SupplierProductRequest;
import com.example.retail.controller.ApiModels.SupplierRequest;
import com.example.retail.entity.Customer;
import com.example.retail.entity.Invoice;
import com.example.retail.entity.Supplier;
import com.example.retail.entity.SupplierProduct;
import com.example.retail.service.PartyService;
import com.example.retail.service.SalesService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class PartyController {
	private final PartyService parties;
	private final SalesService sales;

	@GetMapping("/customers")
	public List<Customer> customers(@RequestParam(required = false) String q) {
		return parties.searchCustomers(q);
	}

	@PostMapping("/customers")
	public ResponseEntity<Customer> createCustomer(@Valid @RequestBody CustomerRequest request) {
		return ResponseEntity.status(HttpStatus.CREATED).body(parties.createCustomer(request));
	}

	@GetMapping("/customers/{id}")
	public Customer customer(@PathVariable long id) {
		return parties.getCustomer(id);
	}

	@PutMapping("/customers/{id}")
	public Customer updateCustomer(@PathVariable long id, @Valid @RequestBody CustomerRequest request) {
		return parties.updateCustomer(id, request);
	}

	@GetMapping("/customers/{id}/invoices")
	public List<Invoice> customerInvoices(@PathVariable long id) {
		parties.getCustomer(id);
		return sales.listInvoices(null, null, id, null);
	}

	@GetMapping("/suppliers")
	public List<Supplier> suppliers(
			@RequestParam(required = false) String q,
			@RequestParam(defaultValue = "false") boolean includeInactive) {
		return parties.searchSuppliers(q, includeInactive);
	}

	@PostMapping("/suppliers")
	public ResponseEntity<Supplier> createSupplier(@Valid @RequestBody SupplierRequest request) {
		return ResponseEntity.status(HttpStatus.CREATED).body(parties.createSupplier(request));
	}

	@GetMapping("/suppliers/{id}")
	public Supplier supplier(@PathVariable long id) {
		return parties.getSupplier(id);
	}

	@PutMapping("/suppliers/{id}")
	public Supplier updateSupplier(@PathVariable long id, @Valid @RequestBody SupplierRequest request) {
		return parties.updateSupplier(id, request);
	}

	@PutMapping("/suppliers/{id}/deactivate")
	public Supplier deactivateSupplier(@PathVariable long id) {
		return parties.deactivateSupplier(id);
	}

	@GetMapping("/suppliers/{id}/products")
	public List<SupplierProduct> supplierProducts(@PathVariable long id) {
		return parties.productsForSupplier(id);
	}

	@PutMapping("/suppliers/{supplierId}/products/{productId}")
	public SupplierProduct linkSupplierProduct(
			@PathVariable long supplierId,
			@PathVariable long productId,
			@Valid @RequestBody SupplierProductRequest request) {
		return parties.linkSupplierProduct(supplierId, productId, request.unitCost(), request.preferred());
	}

	@GetMapping("/products/{productId}/suppliers")
	public List<SupplierProduct> productSuppliers(@PathVariable long productId) {
		return parties.suppliersForProduct(productId);
	}
}
