package com.example.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.Supplier;

public interface SupplierRepository extends JpaRepository<Supplier, Long> {
	List<Supplier> findByNameContainingIgnoreCaseOrPhoneContainingIgnoreCaseOrEmailContainingIgnoreCase(
			String name, String phone, String email);
}
