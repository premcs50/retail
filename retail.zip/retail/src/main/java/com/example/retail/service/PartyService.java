package com.example.retail.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.retail.controller.ApiModels.CustomerRequest;
import com.example.retail.controller.ApiModels.SupplierRequest;
import com.example.retail.entity.Customer;
import com.example.retail.entity.Supplier;
import com.example.retail.entity.SupplierProduct;
import com.example.retail.repository.CustomerRepository;
import com.example.retail.repository.SupplierProductRepository;
import com.example.retail.repository.SupplierRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PartyService {
	private final CustomerRepository customers;
	private final SupplierRepository suppliers;
	private final SupplierProductRepository supplierProducts;
	private final RetailService retail;

	@Transactional(readOnly = true)
	public List<Customer> searchCustomers(String query) {
		return query == null || query.isBlank() ? customers.findAll()
				: customers.findByNameContainingIgnoreCaseOrPhoneContainingIgnoreCaseOrEmailContainingIgnoreCase(
						query.trim(), query.trim(), query.trim());
	}

	@Transactional
	public Customer createCustomer(CustomerRequest request) {
		Customer customer = new Customer();
		applyCustomer(customer, request);
		Customer saved = customers.save(customer);
		retail.audit("CUSTOMER_CREATED", "Customer", saved.getId(), saved.getName());
		return saved;
	}

	@Transactional
	public Customer updateCustomer(long id, CustomerRequest request) {
		Customer customer = customers.findById(id)
				.orElseThrow(() -> ApiException.notFound("Customer not found."));
		applyCustomer(customer, request);
		Customer saved = customers.save(customer);
		retail.audit("CUSTOMER_UPDATED", "Customer", id, saved.getName());
		return saved;
	}

	@Transactional(readOnly = true)
	public Customer getCustomer(long id) {
		return customers.findById(id).orElseThrow(() -> ApiException.notFound("Customer not found."));
	}

	@Transactional(readOnly = true)
	public List<Supplier> searchSuppliers(String query, boolean includeInactive) {
		List<Supplier> result = query == null || query.isBlank() ? suppliers.findAll()
				: suppliers.findByNameContainingIgnoreCaseOrPhoneContainingIgnoreCaseOrEmailContainingIgnoreCase(
						query.trim(), query.trim(), query.trim());
		return result.stream().filter(supplier -> includeInactive || supplier.isActive()).toList();
	}

	@Transactional
	public Supplier createSupplier(SupplierRequest request) {
		Supplier supplier = new Supplier();
		applySupplier(supplier, request);
		Supplier saved = suppliers.save(supplier);
		retail.audit("SUPPLIER_CREATED", "Supplier", saved.getId(), saved.getName());
		return saved;
	}

	@Transactional
	public Supplier updateSupplier(long id, SupplierRequest request) {
		Supplier supplier = getSupplier(id);
		applySupplier(supplier, request);
		Supplier saved = suppliers.save(supplier);
		retail.audit("SUPPLIER_UPDATED", "Supplier", id, saved.getName());
		return saved;
	}

	@Transactional
	public Supplier deactivateSupplier(long id) {
		Supplier supplier = getSupplier(id);
		supplier.setActive(false);
		Supplier saved = suppliers.save(supplier);
		retail.audit("SUPPLIER_DEACTIVATED", "Supplier", id, saved.getName());
		return saved;
	}

	@Transactional(readOnly = true)
	public Supplier getSupplier(long id) {
		return suppliers.findById(id).orElseThrow(() -> ApiException.notFound("Supplier not found."));
	}

	@Transactional
	public SupplierProduct linkSupplierProduct(
			long supplierId, long productId, java.math.BigDecimal unitCost, Boolean preferred) {
		Supplier supplier = getSupplier(supplierId);
		if (!supplier.isActive()) {
			throw ApiException.conflict("Inactive suppliers cannot be assigned to products.");
		}
		retail.getProduct(productId);
		SupplierProduct link = supplierProducts.findBySupplierIdAndProductId(supplierId, productId)
				.orElseGet(SupplierProduct::new);
		boolean markPreferred = preferred == null || preferred;
		if (markPreferred) {
			for (SupplierProduct existing : supplierProducts.findByProductId(productId)) {
				existing.setPreferred(false);
				supplierProducts.save(existing);
			}
		}
		link.setSupplierId(supplierId);
		link.setProductId(productId);
		link.setUnitCost(unitCost);
		link.setPreferred(markPreferred);
		SupplierProduct saved = supplierProducts.save(link);
		retail.audit("SUPPLIER_PRODUCT_LINKED", "Product", productId, "Supplier " + supplierId);
		return saved;
	}

	@Transactional(readOnly = true)
	public List<SupplierProduct> suppliersForProduct(long productId) {
		retail.getProduct(productId);
		return supplierProducts.findByProductId(productId);
	}

	@Transactional(readOnly = true)
	public List<SupplierProduct> productsForSupplier(long supplierId) {
		getSupplier(supplierId);
		return supplierProducts.findBySupplierId(supplierId);
	}

	private void applyCustomer(Customer customer, CustomerRequest request) {
		customer.setName(request.name().trim());
		customer.setEmail(blankToNull(request.email()));
		customer.setPhone(blankToNull(request.phone()));
		customer.setAddress(blankToNull(request.address()));
		customer.setSegment(blankToNull(request.segment()));
		if (request.active() != null) {
			customer.setActive(request.active());
		}
	}

	private void applySupplier(Supplier supplier, SupplierRequest request) {
		supplier.setName(request.name().trim());
		supplier.setEmail(blankToNull(request.email()));
		supplier.setPhone(blankToNull(request.phone()));
		supplier.setAddress(blankToNull(request.address()));
		supplier.setContractNotes(blankToNull(request.contractNotes()));
		if (request.active() != null) {
			supplier.setActive(request.active());
		}
	}

	private String blankToNull(String value) {
		return value == null || value.isBlank() ? null : value.trim();
	}
}
