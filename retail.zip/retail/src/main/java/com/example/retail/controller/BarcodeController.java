package com.example.retail.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.retail.controller.ApiModels.OfflineScanRequest;
import com.example.retail.controller.ApiModels.OfflineSyncRequest;
import com.example.retail.controller.ApiModels.OfflineSyncResponse;
import com.example.retail.entity.OfflineScan;
import com.example.retail.entity.Product;
import com.example.retail.service.OfflineScanService;
import com.example.retail.service.RetailService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/barcodes")
@RequiredArgsConstructor
public class BarcodeController {
	private final RetailService retail;
	private final OfflineScanService offlineScans;

	@GetMapping("/lookup/{barcode}")
	public Product lookup(@PathVariable String barcode) {
		return retail.findByBarcode(barcode);
	}

	@GetMapping("/missing")
	public List<Product> productsWithoutBarcode() {
		return retail.listProducts(null, null, null, true).stream()
				.filter(product -> product.getBarcode() == null || product.getBarcode().isBlank()).toList();
	}

	@GetMapping(value = "/labels", produces = MediaType.TEXT_HTML_VALUE)
	public String printLabels(@RequestParam String productIds) {
		List<Long> ids;
		try {
			ids = Arrays.stream(productIds.split(",")).map(String::trim).map(Long::valueOf).toList();
		} catch (NumberFormatException exception) {
			throw com.example.retail.service.ApiException.badRequest("productIds must be comma-separated numbers.");
		}
		StringBuilder html = new StringBuilder("<!doctype html><html><head><title>Barcode labels</title>")
				.append("<style>@media print{button{display:none}}.label{border:1px solid #333;")
				.append("display:inline-block;padding:16px;margin:8px;text-align:center}</style></head><body>")
				.append("<button onclick=\"window.print()\">Print labels</button>");
		for (Long id : ids) {
			Product product = retail.getProduct(id);
			if (product.getBarcode() == null || product.getBarcode().isBlank()) {
				throw com.example.retail.service.ApiException.badRequest("Product " + id + " has no barcode.");
			}
			html.append("<div class=\"label\"><strong>").append(escape(product.getName()))
					.append("</strong><br><span>").append(escape(product.getBarcode()))
					.append("</span><br>").append(product.getSellingPrice()).append("</div>");
		}
		return html.append("</body></html>").toString();
	}

	@PostMapping("/offline-queue")
	public OfflineScan queue(@Valid @RequestBody OfflineScanRequest request) {
		return offlineScans.queue(request);
	}

	@GetMapping("/offline-queue")
	public List<OfflineScan> pending() {
		return offlineScans.pending();
	}

	@PostMapping("/offline-sync")
	public OfflineSyncResponse sync(@RequestBody OfflineSyncRequest request) {
		return offlineScans.sync(request);
	}

	private String escape(String value) {
		return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
				.replace("\"", "&quot;").replace("'", "&#39;");
	}
}
