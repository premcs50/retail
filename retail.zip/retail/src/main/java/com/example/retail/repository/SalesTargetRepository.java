package com.example.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.SalesTarget;

public interface SalesTargetRepository extends JpaRepository<SalesTarget, Long> {
	List<SalesTarget> findByPeriod(String period);
}
