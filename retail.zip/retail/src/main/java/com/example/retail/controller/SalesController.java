package com.example.retail.controller;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.retail.controller.ApiModels.InvoiceDetails;
import com.example.retail.controller.ApiModels.InvoiceRequest;
import com.example.retail.controller.ApiModels.PaymentRequest;
import com.example.retail.controller.ApiModels.ReturnRequest;
import com.example.retail.controller.ApiModels.VoidInvoiceRequest;
import com.example.retail.entity.BusinessEvent;
import com.example.retail.entity.Invoice;
import com.example.retail.service.SalesService;
import com.example.retail.service.OperationsService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class SalesController {
	private final SalesService sales;
	private final OperationsService operations;

	@GetMapping("/invoices")
	public List<Invoice> invoices(
			@RequestParam(required = false) LocalDateTime start,
			@RequestParam(required = false) LocalDateTime end,
			@RequestParam(required = false) Long customerId,
			@RequestParam(required = false) String staffName,
			@RequestParam(required = false) String q,
			@RequestParam(required = false) String paymentMode) {
		return sales.searchInvoices(start, end, customerId, staffName, q, paymentMode);
	}

	@PostMapping("/invoices")
	public ResponseEntity<InvoiceDetails> createInvoice(@Valid @RequestBody InvoiceRequest request) {
		Invoice invoice = sales.createInvoice(request);
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(new InvoiceDetails(invoice, sales.getInvoiceLines(invoice.getId())));
	}

	@GetMapping("/invoices/{id}")
	public InvoiceDetails invoice(@PathVariable long id) {
		return new InvoiceDetails(sales.getInvoice(id), sales.getInvoiceLines(id));
	}

	@GetMapping(value = "/invoices/{id}/print", produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String> printInvoice(@PathVariable long id) {
		Invoice invoice = sales.getInvoice(id);
		StringBuilder output = new StringBuilder();
		Map<String, String> store = operations.allSettings();
		for (String key : List.of("store.name", "store.address", "store.phone")) {
			if (store.containsKey(key)) {
				output.append(store.get(key)).append('\n');
			}
		}
		output.append("Invoice: ").append(invoice.getInvoiceNumber()).append('\n')
				.append("Date: ").append(invoice.getCreatedAt()).append('\n')
				.append("Status: ").append(invoice.getStatus()).append('\n')
				.append("Item | Quantity | Unit price | Total\n");
		sales.getInvoiceLines(id).forEach(item -> output.append(item.getProductName()).append(" | ")
				.append(item.getQuantity()).append(" | ").append(item.getUnitPrice()).append(" | ")
				.append(item.getLineTotal()).append('\n'));
		output.append("Subtotal: ").append(invoice.getSubtotal()).append('\n')
				.append("Tax: ").append(invoice.getTaxTotal()).append('\n')
				.append("Discount: ").append(invoice.getDiscountTotal()).append('\n')
				.append("Total: ").append(invoice.getTotal()).append('\n');
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
				"inline; filename=\"" + invoice.getInvoiceNumber() + ".txt\"").body(output.toString());
	}

	@PostMapping("/invoices/{id}/payments")
	public ResponseEntity<BusinessEvent> payment(
			@PathVariable long id,
			@Valid @RequestBody PaymentRequest request) {
		return ResponseEntity.status(HttpStatus.CREATED).body(sales.recordPayment(id, request));
	}

	@PostMapping("/invoices/{id}/returns")
	public ResponseEntity<BusinessEvent> returnProduct(
			@PathVariable long id,
			@Valid @RequestBody ReturnRequest request) {
		return ResponseEntity.status(HttpStatus.CREATED).body(sales.processReturn(id, request));
	}

	@PutMapping("/invoices/{id}/void")
	public Invoice voidInvoice(@PathVariable long id, @Valid @RequestBody VoidInvoiceRequest request) {
		return sales.voidInvoice(id, request.reason());
	}

	@GetMapping("/payments")
	public List<BusinessEvent> payments(
			@RequestParam(required = false) LocalDateTime start,
			@RequestParam(required = false) LocalDateTime end,
			@RequestParam(required = false) String paymentMode) {
		return sales.listPayments(start, end, paymentMode);
	}
}
