package com.example.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.Purchase;

public interface PurchaseRepository extends JpaRepository<Purchase, Long> {
	List<Purchase> findBySupplierIdOrderByCreatedAtDesc(Long supplierId);
}
