package com.example.retail.controller;

import java.math.BigDecimal;
import java.util.List;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import com.example.retail.entity.Invoice;
import com.example.retail.entity.InvoiceLine;
import com.example.retail.entity.Purchase;
import com.example.retail.entity.PurchaseLine;

public final class ApiModels {
	private ApiModels() {
	}

	public record CategoryRequest(
			@NotBlank String name,
			String description,
			Boolean active) {
	}

	public record ProductRequest(
			@NotBlank String name,
			@NotBlank String sku,
			String barcode,
			@NotNull @DecimalMin("0.0") BigDecimal sellingPrice,
			@DecimalMin("0.0") BigDecimal costPrice,
			@DecimalMin("0.0") @DecimalMax("100.0") BigDecimal taxRate,
			Boolean taxable,
			Long categoryId,
			String unit,
			@DecimalMin("0.0") BigDecimal initialStock,
			@DecimalMin("0.0") BigDecimal reorderLevel,
			Boolean active) {
	}

	public record StockAdjustmentRequest(
			@NotNull BigDecimal quantityChange,
			@NotBlank String reason) {
	}

	public record StockCount(
			@NotNull Long productId,
			@NotNull @DecimalMin("0.0") BigDecimal physicalCount) {
	}

	public record BulkStockRequest(@NotEmpty List<@Valid StockCount> counts) {
	}

	public record InvoiceItemRequest(
			@NotNull Long productId,
			@NotNull @Positive BigDecimal quantity,
			@DecimalMin("0.0") BigDecimal discount) {
	}

	public record InvoiceRequest(
			Long customerId,
			String staffName,
			@NotEmpty List<@Valid InvoiceItemRequest> items,
			@DecimalMin("0.0") BigDecimal discount,
			String paymentMode,
			@DecimalMin("0.0") BigDecimal amountPaid) {
	}

	public record PaymentRequest(
			@NotNull @Positive BigDecimal amount,
			@NotBlank String paymentMode,
			String reference) {
	}

	public record ReturnRequest(
			@NotNull Long productId,
			@NotNull @Positive BigDecimal quantity,
			@NotBlank String reason,
			BigDecimal refundAmount,
			String paymentMode) {
	}

	public record CustomerRequest(
			@NotBlank String name,
			@Email
			String email,
			String phone,
			String address,
			String segment,
			Boolean active) {
	}

	public record SupplierRequest(
			@NotBlank String name,
			@Email
			String email,
			String phone,
			String address,
			String contractNotes,
			Boolean active) {
	}

	public record PurchaseItemRequest(
			@NotNull Long productId,
			@NotNull @Positive BigDecimal quantity,
			@NotNull @DecimalMin("0.0") BigDecimal unitCost,
			String barcode) {
	}

	public record PurchaseRequest(
			@NotNull Long supplierId,
			@NotEmpty List<@Valid PurchaseItemRequest> items) {
	}

	public record BusinessEventRequest(
			@NotNull @DecimalMin("0.0") BigDecimal amount,
			String paymentMode,
			String reference,
			@NotBlank String description,
			String staffName) {
	}

	public record SalesTargetRequest(
			@NotBlank String period,
			String staffName,
			@NotNull @DecimalMin("0.0") BigDecimal targetAmount) {
	}

	public record VoidInvoiceRequest(@NotBlank String reason) {
	}

	public record SupplierProductRequest(@DecimalMin("0.0") BigDecimal unitCost, Boolean preferred) {
	}

	public record CashReconciliationRequest(
			@DecimalMin("0.0") BigDecimal expectedCash,
			@NotNull @DecimalMin("0.0") BigDecimal actualCash,
			String staffName,
			String description) {
	}

	public record ShiftRequest(
			@NotNull @DecimalMin("0.0") BigDecimal openingCash,
			String staffName,
			String description) {
	}

	public record OfflineScanRequest(
			@NotBlank String barcode,
			@NotNull @Positive BigDecimal quantity) {
	}

	public record OfflineSyncRequest(Long customerId, String staffName, String paymentMode) {
	}

	public record NotificationRequest(
			@NotBlank String type,
			@NotBlank String message,
			String channel) {
	}

	public record SettingValueRequest(@NotNull String value) {
	}

	public record OfflineSyncResponse(long invoiceId, int syncedScans) {
	}

	public record InvoiceDetails(Invoice invoice, List<InvoiceLine> items) {
	}

	public record PurchaseDetails(Purchase purchase, List<PurchaseLine> items) {
	}
}
