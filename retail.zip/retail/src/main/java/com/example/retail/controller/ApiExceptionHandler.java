package com.example.retail.controller;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.retail.service.ApiException;

@RestControllerAdvice
public class ApiExceptionHandler {
	@ExceptionHandler(ApiException.class)
	public ResponseEntity<Map<String, Object>> handleApiException(ApiException exception) {
		return ResponseEntity.status(exception.getStatus()).body(Map.of(
				"timestamp", LocalDateTime.now(),
				"status", exception.getStatus().value(),
				"error", exception.getStatus().getReasonPhrase(),
				"message", exception.getMessage()));
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, Object>> handleValidation(MethodArgumentNotValidException exception) {
		Map<String, String> errors = exception.getBindingResult().getFieldErrors().stream()
				.collect(Collectors.toMap(FieldError::getField, error -> error.getDefaultMessage() == null
						? "Invalid value" : error.getDefaultMessage(), (first, ignored) -> first));
		return ResponseEntity.badRequest().body(Map.of(
				"timestamp", LocalDateTime.now(),
				"status", HttpStatus.BAD_REQUEST.value(),
				"error", "Validation failed",
				"fields", errors));
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<Map<String, Object>> handleConstraintViolation(
			DataIntegrityViolationException exception) {
		return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of(
				"timestamp", LocalDateTime.now(),
				"status", HttpStatus.CONFLICT.value(),
				"error", HttpStatus.CONFLICT.getReasonPhrase(),
				"message", "The request conflicts with an existing record or database constraint."));
	}
}
