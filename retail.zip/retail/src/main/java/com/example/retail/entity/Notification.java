package com.example.retail.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "notifications")
@Getter
@Setter
@NoArgsConstructor
public class Notification {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false, length = 40)
	private String type;

	@Column(nullable = false, length = 500)
	private String message;

	@Column(nullable = false)
	private boolean acknowledged;

	@Column(nullable = false, length = 40)
	private String channel = "IN_APP";

	@Column(nullable = false)
	private LocalDateTime createdAt = LocalDateTime.now();
}
