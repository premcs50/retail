package com.example.retail.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.StoreSetting;

public interface StoreSettingRepository extends JpaRepository<StoreSetting, Long> {
	Optional<StoreSetting> findBySettingKey(String settingKey);
}
