package com.example.retail.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.retail.controller.ApiModels.CategoryRequest;
import com.example.retail.controller.ApiModels.ProductRequest;
import com.example.retail.controller.ApiModels.StockCount;
import com.example.retail.entity.AuditLog;
import com.example.retail.entity.Category;
import com.example.retail.entity.Notification;
import com.example.retail.entity.Product;
import com.example.retail.entity.StockMovement;
import com.example.retail.repository.AuditLogRepository;
import com.example.retail.repository.CategoryRepository;
import com.example.retail.repository.NotificationRepository;
import com.example.retail.repository.ProductRepository;
import com.example.retail.repository.StockMovementRepository;
import com.example.retail.repository.StoreSettingRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RetailService {
	private final CategoryRepository categories;
	private final ProductRepository products;
	private final StockMovementRepository movements;
	private final NotificationRepository notifications;
	private final AuditLogRepository auditLogs;
	private final StoreSettingRepository settings;

	@Transactional(readOnly = true)
	public List<Category> listCategories(boolean includeInactive) {
		return categories.findAll().stream()
				.filter(category -> includeInactive || category.isActive())
				.toList();
	}

	@Transactional
	public Category createCategory(CategoryRequest request) {
		String name = request.name().trim();
		if (categories.findByNameIgnoreCase(name).isPresent()) {
			throw ApiException.conflict("A category with this name already exists.");
		}
		Category category = new Category();
		category.setName(name);
		category.setDescription(request.description());
		category.setActive(request.active() == null || request.active());
		Category saved = categories.save(category);
		audit("CATEGORY_CREATED", "Category", saved.getId(), name);
		return saved;
	}

	@Transactional
	public Category updateCategory(long id, CategoryRequest request) {
		Category category = getCategory(id);
		String name = request.name().trim();
		categories.findByNameIgnoreCase(name)
				.filter(existing -> !existing.getId().equals(id))
				.ifPresent(existing -> {
					throw ApiException.conflict("A category with this name already exists.");
				});
		category.setName(name);
		category.setDescription(request.description());
		if (request.active() != null) {
			category.setActive(request.active());
		}
		Category saved = categories.save(category);
		audit("CATEGORY_UPDATED", "Category", id, name);
		return saved;
	}

	@Transactional
	public void deleteCategory(long id) {
		Category category = getCategory(id);
		if (products.countByCategoryId(id) > 0) {
			throw ApiException.conflict("Category has products assigned; deactivate it instead.");
		}
		categories.delete(category);
		audit("CATEGORY_DELETED", "Category", id, category.getName());
	}

	@Transactional(readOnly = true)
	public List<Product> listProducts(String query, Long categoryId, String stockStatus, boolean includeInactive) {
		List<Product> result;
		if (query != null && !query.isBlank()) {
			String term = query.trim();
			result = products.findByNameContainingIgnoreCaseOrSkuContainingIgnoreCase(term, term);
		} else if (categoryId != null) {
			result = products.findByCategoryId(categoryId);
		} else {
			result = products.findAll();
		}

		String normalizedStockStatus = stockStatus == null ? "" : stockStatus.toLowerCase(Locale.ROOT);
		return result.stream()
				.filter(product -> includeInactive || product.isActive())
				.filter(product -> categoryId == null || categoryId.equals(product.getCategoryId()))
				.filter(product -> matchesStockStatus(product, normalizedStockStatus))
				.toList();
	}

	@Transactional(readOnly = true)
	public Product getProduct(long id) {
		return products.findById(id).orElseThrow(() -> ApiException.notFound("Product not found."));
	}

	@Transactional
	public Product createProduct(ProductRequest request) {
		validateProduct(request, null);
		Product product = new Product();
		applyProductRequest(product, request, true);
		product.setStockQuantity(valueOrZero(request.initialStock()));
		Product saved = products.save(product);
		if (saved.getStockQuantity().signum() > 0) {
			recordMovement(saved, saved.getStockQuantity(), "INITIAL_STOCK", "Initial stock", null);
		}
		audit("PRODUCT_CREATED", "Product", saved.getId(), saved.getSku());
		if (saved.getStockQuantity().compareTo(saved.getReorderLevel()) <= 0) {
			Notification notification = new Notification();
			notification.setType("LOW_STOCK");
			notification.setMessage(saved.getName() + " (" + saved.getSku() + ") is at "
					+ saved.getStockQuantity() + " " + saved.getUnit() + ".");
			notifications.save(notification);
		}
		return saved;
	}

	@Transactional
	public Product updateProduct(long id, ProductRequest request) {
		Product product = getProductForUpdate(id);
		validateProduct(request, id);
		applyProductRequest(product, request, false);
		Product saved = products.save(product);
		audit("PRODUCT_UPDATED", "Product", id, saved.getSku());
		return saved;
	}

	@Transactional
	public void deactivateProduct(long id) {
		Product product = getProductForUpdate(id);
		product.setActive(false);
		products.save(product);
		audit("PRODUCT_DEACTIVATED", "Product", id, product.getSku());
	}

	@Transactional(readOnly = true)
	public Product findByBarcode(String barcode) {
		return products.findByBarcodeIgnoreCase(barcode.trim())
				.orElseThrow(() -> ApiException.notFound("No product was found for this barcode."));
	}

	@Transactional(readOnly = true)
	public List<Product> lowStockProducts() {
		return products.findAll().stream()
				.filter(Product::isActive)
				.filter(product -> product.getStockQuantity().compareTo(product.getReorderLevel()) <= 0)
				.toList();
	}

	@Transactional
	public StockMovement adjustStock(long productId, BigDecimal quantityChange, String reason, String reference) {
		Product product = getProductForUpdate(productId);
		BigDecimal before = product.getStockQuantity();
		BigDecimal after = before.add(quantityChange);
		if (after.signum() < 0) {
			throw ApiException.conflict("Stock adjustment would make inventory negative.");
		}
		product.setStockQuantity(after);
		products.save(product);
		StockMovement movement = recordMovement(product, quantityChange, "ADJUSTMENT", reason, reference);
		audit("STOCK_ADJUSTED", "Product", productId,
				quantityChange.stripTrailingZeros().toPlainString() + ": " + reason);
		alertIfLow(product, before);
		return movement;
	}

	@Transactional
	public List<StockMovement> applyStockCount(List<StockCount> counts) {
		List<StockMovement> result = new ArrayList<>();
		Set<Long> seenProducts = new HashSet<>();
		for (StockCount count : counts) {
			if (!seenProducts.add(count.productId())) {
				throw ApiException.badRequest("Each product may appear only once in a stock count.");
			}
			Product product = getProductForUpdate(count.productId());
			BigDecimal delta = count.physicalCount().subtract(product.getStockQuantity());
			if (delta.signum() != 0) {
				result.add(adjustStock(product.getId(), delta, "Physical stock count", "STOCKTAKE"));
			}
		}
		return result;
	}

	@Transactional(readOnly = true)
	public List<StockMovement> stockHistory(Long productId, LocalDateTime start, LocalDateTime end) {
		if (productId != null) {
			getProduct(productId);
			return movements.findByProductIdOrderByOccurredAtDesc(productId);
		}
		if (start == null && end == null) {
			return movements.findAllByOrderByOccurredAtDesc();
		}
		if (start == null || end == null || end.isBefore(start)) {
			throw ApiException.badRequest("Provide a valid start and end date range.");
		}
		return movements.findByOccurredAtBetweenOrderByOccurredAtDesc(start, end);
	}

	public Category getCategory(long id) {
		return categories.findById(id).orElseThrow(() -> ApiException.notFound("Category not found."));
	}

	@Transactional
	public Product getProductForUpdate(long id) {
		return products.findByIdForUpdate(id).orElseThrow(() -> ApiException.notFound("Product not found."));
	}

	void decrementStock(Product product, BigDecimal quantity, String type, String reference) {
		Product lockedProduct = getProductForUpdate(product.getId());
		BigDecimal before = lockedProduct.getStockQuantity();
		BigDecimal after = before.subtract(quantity);
		if (after.signum() < 0) {
			throw ApiException.conflict("Insufficient stock for product " + lockedProduct.getSku() + ".");
		}
		lockedProduct.setStockQuantity(after);
		products.save(lockedProduct);
		recordMovement(lockedProduct, quantity.negate(), type, type, reference);
		alertIfLow(lockedProduct, before);
	}

	void incrementStock(Product product, BigDecimal quantity, String type, String reference) {
		Product lockedProduct = getProductForUpdate(product.getId());
		BigDecimal before = lockedProduct.getStockQuantity();
		lockedProduct.setStockQuantity(before.add(quantity));
		products.save(lockedProduct);
		recordMovement(lockedProduct, quantity, type, type, reference);
		alertIfLow(lockedProduct, before);
	}

	void audit(String action, String entityType, Long entityId, String details) {
		AuditLog log = new AuditLog();
		log.setAction(action);
		log.setEntityType(entityType);
		log.setEntityId(entityId);
		log.setActor("system");
		log.setDetails(details);
		auditLogs.save(log);
	}

	private void validateProduct(ProductRequest request, Long existingId) {
		validateNonNegative(request.sellingPrice(), "sellingPrice");
		validateNonNegative(request.costPrice(), "costPrice");
		validateNonNegative(request.initialStock(), "initialStock");
		validateNonNegative(request.reorderLevel(), "reorderLevel");
		if (request.taxRate() != null && (request.taxRate().signum() < 0
				|| request.taxRate().compareTo(BigDecimal.valueOf(100)) > 0)) {
			throw ApiException.badRequest("taxRate must be between 0 and 100.");
		}
		products.findBySkuIgnoreCase(request.sku().trim())
				.filter(existing -> !Objects.equals(existing.getId(), existingId))
				.ifPresent(existing -> {
					throw ApiException.conflict("SKU already exists.");
				});
		if (request.barcode() != null && !request.barcode().isBlank()) {
			products.findByBarcodeIgnoreCase(request.barcode().trim())
					.filter(existing -> !Objects.equals(existing.getId(), existingId))
					.ifPresent(existing -> {
						throw ApiException.conflict("Barcode is already assigned to another product.");
					});
		}
		if (request.categoryId() != null) {
			Category category = getCategory(request.categoryId());
			if (!category.isActive()) {
				throw ApiException.badRequest("Inactive categories cannot be assigned to products.");
			}
		}
	}

	private void applyProductRequest(Product product, ProductRequest request, boolean creating) {
		product.setName(request.name().trim());
		product.setSku(request.sku().trim());
		product.setBarcode(blankToNull(request.barcode()));
		product.setSellingPrice(request.sellingPrice());
		if (request.costPrice() != null || creating) {
			product.setCostPrice(valueOrZero(request.costPrice()));
		}
		if (request.taxRate() != null || creating) {
			product.setTaxRate(request.taxRate() == null
					? settingDecimal("tax.defaultRate", BigDecimal.ZERO) : request.taxRate());
		}
		if (request.taxable() != null || creating) {
			product.setTaxable(request.taxable() == null
					? Boolean.parseBoolean(settingValue("tax.defaultTaxable", "true")) : request.taxable());
		}
		product.setCategoryId(request.categoryId());
		if (request.unit() != null && !request.unit().isBlank()) {
			product.setUnit(request.unit().trim());
		} else if (creating) {
			product.setUnit(settingValue("inventory.defaultUnit", "each"));
		}
		if (request.reorderLevel() != null || creating) {
			product.setReorderLevel(request.reorderLevel() == null
					? settingDecimal("inventory.defaultReorderLevel", BigDecimal.ZERO) : request.reorderLevel());
		}
		if (request.active() != null) {
			product.setActive(request.active());
		}
	}

	private StockMovement recordMovement(
			Product product, BigDecimal delta, String type, String reason, String reference) {
		StockMovement movement = new StockMovement();
		movement.setProductId(product.getId());
		movement.setQuantityChange(delta);
		movement.setQuantityAfter(product.getStockQuantity());
		movement.setMovementType(type);
		movement.setReason(reason);
		movement.setReference(reference);
		return movements.save(movement);
	}

	private void alertIfLow(Product product, BigDecimal previousQuantity) {
		if (product.getStockQuantity().compareTo(product.getReorderLevel()) <= 0
				&& previousQuantity.compareTo(product.getReorderLevel()) > 0) {
			Notification notification = new Notification();
			notification.setType("LOW_STOCK");
			notification.setMessage(product.getName() + " (" + product.getSku() + ") is at "
					+ product.getStockQuantity() + " " + product.getUnit() + ".");
			notifications.save(notification);
		}
	}

	private boolean matchesStockStatus(Product product, String status) {
		return switch (status) {
			case "", "all" -> true;
			case "out", "out-of-stock" -> product.getStockQuantity().signum() == 0;
			case "low", "low-stock" -> product.getStockQuantity().signum() > 0
					&& product.getStockQuantity().compareTo(product.getReorderLevel()) <= 0;
			case "in", "in-stock" -> product.getStockQuantity().compareTo(product.getReorderLevel()) > 0;
			default -> throw new ApiException(HttpStatus.BAD_REQUEST,
					"stockStatus must be one of all, out, low, or in.");
		};
	}

	private BigDecimal valueOrZero(BigDecimal value) {
		return value == null ? BigDecimal.ZERO : value;
	}

	private String blankToNull(String value) {
		return value == null || value.isBlank() ? null : value.trim();
	}

	private void validateNonNegative(BigDecimal value, String field) {
		if (value != null && value.signum() < 0) {
			throw ApiException.badRequest(field + " must be a non-negative number.");
		}
	}

	private String settingValue(String key, String fallback) {
		return settings.findBySettingKey(key).map(setting -> setting.getSettingValue()).orElse(fallback);
	}

	private BigDecimal settingDecimal(String key, BigDecimal fallback) {
		try {
			return new BigDecimal(settingValue(key, fallback.toPlainString()));
		} catch (NumberFormatException exception) {
			throw ApiException.badRequest("Invalid numeric value configured for " + key + ".");
		}
	}
}
