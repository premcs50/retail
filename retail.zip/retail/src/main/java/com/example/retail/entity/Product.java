package com.example.retail.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "products", uniqueConstraints = {
		@UniqueConstraint(columnNames = "sku"),
		@UniqueConstraint(columnNames = "barcode")
})
@Getter
@Setter
@NoArgsConstructor
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false, length = 180)
	private String name;

	@Column(nullable = false, length = 80)
	private String sku;

	@Column(length = 100)
	private String barcode;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal sellingPrice;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal costPrice = BigDecimal.ZERO;

	@Column(nullable = false, precision = 7, scale = 4)
	private BigDecimal taxRate = BigDecimal.ZERO;

	@Column(nullable = false)
	private boolean taxable = true;

	private Long categoryId;

	@Column(nullable = false, length = 40)
	private String unit = "each";

	@Column(nullable = false, precision = 12, scale = 3)
	private BigDecimal stockQuantity = BigDecimal.ZERO;

	@Column(nullable = false, precision = 12, scale = 3)
	private BigDecimal reorderLevel = BigDecimal.ZERO;

	@Column(nullable = false)
	private boolean active = true;
}
