package com.example.retail.service;

import java.io.IOException;
import java.time.Instant;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

@Service
public class LiveUpdateService {
	private static final Logger log = LoggerFactory.getLogger(LiveUpdateService.class);
	private final Set<SseEmitter> clients = ConcurrentHashMap.newKeySet();

	public SseEmitter subscribe() {
		SseEmitter emitter = new SseEmitter(0L);
		clients.add(emitter);
		emitter.onCompletion(() -> clients.remove(emitter));
		emitter.onTimeout(() -> clients.remove(emitter));
		emitter.onError(error -> clients.remove(emitter));
		try {
			emitter.send(SseEmitter.event().name("connected").data("connected"));
		} catch (IOException exception) {
			clients.remove(emitter);
			emitter.completeWithError(exception);
			log.debug("Could not initialize live update stream", exception);
		}
		return emitter;
	}

	public void publish(String method, String path) {
		Map<String, String> change = Map.of(
				"method", method,
				"path", path,
				"changedAt", Instant.now().toString());
		for (SseEmitter client : clients) {
			try {
				client.send(SseEmitter.event().name("data-changed").data(change));
			} catch (IOException | IllegalStateException exception) {
				clients.remove(client);
				client.completeWithError(exception);
				log.debug("Removed disconnected live update client", exception);
			}
		}
	}
}
