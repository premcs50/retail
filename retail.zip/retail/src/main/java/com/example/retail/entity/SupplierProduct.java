package com.example.retail.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "supplier_products", uniqueConstraints = @UniqueConstraint(columnNames = {"supplierId", "productId"}))
@Getter
@Setter
@NoArgsConstructor
public class SupplierProduct {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private Long supplierId;

	@Column(nullable = false)
	private Long productId;

	@Column(precision = 12, scale = 2)
	private BigDecimal unitCost;

	@Column(nullable = false)
	private boolean preferred;
}
