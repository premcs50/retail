package com.example.retail.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.retail.controller.ApiModels.BusinessEventRequest;
import com.example.retail.controller.ApiModels.CashReconciliationRequest;
import com.example.retail.controller.ApiModels.SalesTargetRequest;
import com.example.retail.controller.ApiModels.ShiftRequest;
import com.example.retail.entity.BusinessEvent;
import com.example.retail.entity.Product;
import com.example.retail.entity.SalesTarget;
import com.example.retail.service.OperationsService;
import com.example.retail.service.RetailService;
import com.example.retail.service.SalesService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class OperationsController {
	private final OperationsService operations;
	private final RetailService retail;
	private final SalesService sales;

	@GetMapping("/dashboard")
	public Map<String, Object> dashboard() {
		return operations.dashboard();
	}

	@GetMapping("/reports/sales")
	public Map<String, ?> salesSummary(
			@RequestParam LocalDateTime start,
			@RequestParam LocalDateTime end,
			@RequestParam(defaultValue = "day") String groupBy) {
		return operations.salesSummary(start, end, groupBy);
	}

	@GetMapping("/reports/inventory")
	public Map<String, Object> inventorySummary() {
		return operations.inventorySummary();
	}

	@GetMapping("/reports/profit")
	public Map<String, ?> profit(
			@RequestParam LocalDateTime start,
			@RequestParam LocalDateTime end) {
		return operations.profitSummary(start, end);
	}

	@GetMapping("/reports/trends")
	public Map<String, ?> salesTrends(
			@RequestParam LocalDateTime start,
			@RequestParam LocalDateTime end,
			@RequestParam(defaultValue = "day") String period) {
		return operations.salesTrends(start, end, period);
	}

	@GetMapping("/reports/peak-sales")
	public Map<String, Object> peakSales(
			@RequestParam LocalDateTime start,
			@RequestParam LocalDateTime end) {
		return operations.peakSales(start, end);
	}

	@GetMapping("/reports/categories")
	public Map<String, ?> categoryPerformance(
			@RequestParam LocalDateTime start,
			@RequestParam LocalDateTime end) {
		return operations.categoryPerformance(start, end);
	}

	@GetMapping("/reports/products")
	public Map<String, ?> productPerformance(
			@RequestParam LocalDateTime start,
			@RequestParam LocalDateTime end) {
		return operations.productPerformance(start, end);
	}

	@GetMapping("/reports/customer-segments")
	public Map<String, ?> customerSegments(
			@RequestParam LocalDateTime start,
			@RequestParam LocalDateTime end) {
		return operations.customerSegmentSales(start, end);
	}

	@GetMapping("/reports/suppliers")
	public Map<String, ?> supplierPerformance() {
		return operations.supplierPerformance();
	}

	@GetMapping("/reports/payment-modes")
	public Map<String, ?> paymentModeSummary(
			@RequestParam LocalDateTime start,
			@RequestParam LocalDateTime end) {
		return operations.paymentModeSummary(start, end);
	}

	@PostMapping("/reports/sales-targets")
	public SalesTarget setSalesTarget(@Valid @RequestBody SalesTargetRequest request) {
		return operations.setSalesTarget(request);
	}

	@GetMapping("/reports/sales-targets")
	public List<Map<String, Object>> targetPerformance(@RequestParam String period) {
		return operations.targetPerformance(period);
	}

	@GetMapping("/reports/custom")
	public Object customReport(
			@RequestParam String report,
			@RequestParam(required = false) LocalDateTime start,
			@RequestParam(required = false) LocalDateTime end) {
		return switch (report.toLowerCase()) {
			case "dashboard" -> operations.dashboard();
			case "inventory" -> operations.inventorySummary();
			case "sales" -> operations.salesSummary(start, end, "day");
			case "profit" -> operations.profitSummary(start, end);
			case "suppliers" -> operations.supplierPerformance();
			case "customers" -> operations.customerSegmentSales(start, end);
			default -> throw com.example.retail.service.ApiException.badRequest(
					"report must be dashboard, inventory, sales, profit, suppliers, or customers.");
		};
	}

	@GetMapping(value = "/reports/sales/export", produces = "text/csv")
	public ResponseEntity<String> exportSales(
			@RequestParam LocalDateTime start,
			@RequestParam LocalDateTime end) {
		StringBuilder csv = new StringBuilder(
				"invoiceNumber,createdAt,customerId,staffName,status,grossTotal,netTotal\n");
		sales.listInvoices(start, end, null, null).stream()
				.filter(invoice -> !"VOID".equals(invoice.getStatus())).forEach(invoice -> csv.append(csv(invoice.getInvoiceNumber()))
				.append(',').append(csv(String.valueOf(invoice.getCreatedAt())))
				.append(',').append(csv(String.valueOf(invoice.getCustomerId())))
				.append(',').append(csv(invoice.getStaffName()))
				.append(',').append(csv(invoice.getStatus()))
				.append(',').append(invoice.getTotal())
				.append(',').append(sales.netInvoiceTotal(invoice)).append('\n'));
		return download("sales-report.csv", csv.toString());
	}

	@GetMapping(value = "/reports/inventory/export", produces = "text/csv")
	public ResponseEntity<String> exportInventory() {
		StringBuilder csv = new StringBuilder("id,name,sku,barcode,categoryId,stockQuantity,reorderLevel,costPrice,sellingPrice\n");
		retail.listProducts(null, null, null, true).forEach(product -> appendProduct(csv, product));
		return download("inventory-report.csv", csv.toString());
	}

	@GetMapping(value = "/dashboard/export", produces = "text/csv")
	public ResponseEntity<String> exportDashboard() {
		Map<String, Object> snapshot = operations.dashboard();
		StringBuilder csv = new StringBuilder("metric,value\n");
		snapshot.forEach((key, value) -> {
			if (!(value instanceof List<?>)) {
				csv.append(csv(key)).append(',').append(csv(String.valueOf(value))).append('\n');
			}
		});
		return download("dashboard-snapshot.csv", csv.toString());
	}

	@PostMapping("/cash/expenses")
	public ResponseEntity<BusinessEvent> expense(@Valid @RequestBody BusinessEventRequest request) {
		return ResponseEntity.status(201).body(operations.recordExpense(request));
	}

	@PostMapping("/cash/deposits")
	public ResponseEntity<BusinessEvent> bankDeposit(@Valid @RequestBody BusinessEventRequest request) {
		return ResponseEntity.status(201).body(operations.recordBankDeposit(request));
	}

	@GetMapping("/cash/summary")
	public Map<String, Object> cashSummary(@RequestParam(required = false) LocalDate date) {
		return operations.cashSummary(date);
	}

	@PostMapping("/cash/reconciliation")
	public ResponseEntity<BusinessEvent> reconcileCash(@Valid @RequestBody CashReconciliationRequest request) {
		return ResponseEntity.status(201).body(operations.reconcileCash(request));
	}

	@PostMapping("/shifts")
	public ResponseEntity<BusinessEvent> openShift(@Valid @RequestBody ShiftRequest request) {
		return ResponseEntity.status(201).body(operations.openShift(request));
	}

	@PostMapping("/shifts/{id}/close")
	public BusinessEvent closeShift(
			@PathVariable long id,
			@Valid @RequestBody BusinessEventRequest request) {
		return operations.closeShift(id, request);
	}

	@GetMapping("/shifts")
	public List<BusinessEvent> shifts() {
		return operations.listEvents("SHIFT_OPEN", null, null);
	}

	private void appendProduct(StringBuilder csv, Product product) {
		csv.append(product.getId()).append(',').append(csv(product.getName())).append(',')
				.append(csv(product.getSku())).append(',').append(csv(product.getBarcode())).append(',')
				.append(csv(String.valueOf(product.getCategoryId()))).append(',')
				.append(product.getStockQuantity()).append(',').append(product.getReorderLevel()).append(',')
				.append(product.getCostPrice()).append(',').append(product.getSellingPrice()).append('\n');
	}

	private ResponseEntity<String> download(String filename, String content) {
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
				"attachment; filename=\"" + filename + "\"")
				.contentType(MediaType.parseMediaType("text/csv")).body(content);
	}

	private String csv(String value) {
		if (value == null) {
			return "";
		}
		String safeValue = value.matches("^[=+\\-@\\t].*") ? "'" + value : value;
		return "\"" + safeValue.replace("\"", "\"\"") + "\"";
	}
}
