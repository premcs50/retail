package com.example.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
	List<Customer> findByNameContainingIgnoreCaseOrPhoneContainingIgnoreCaseOrEmailContainingIgnoreCase(
			String name, String phone, String email);
}
