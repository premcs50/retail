package com.example.retail.controller;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.retail.controller.ApiModels.NotificationRequest;
import com.example.retail.controller.ApiModels.SettingValueRequest;
import com.example.retail.entity.AuditLog;
import com.example.retail.entity.Notification;
import com.example.retail.service.OperationsService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AdminController {
	private final OperationsService operations;

	@GetMapping("/settings")
	public Map<String, String> settings() {
		return operations.allSettings();
	}

	@PutMapping("/settings")
	public Map<String, String> updateSettings(@RequestBody Map<String, String> updates) {
		return operations.updateSettings(updates);
	}

	@PutMapping("/settings/{key}")
	public Map<String, String> updateSetting(
			@PathVariable String key,
			@Valid @RequestBody SettingValueRequest request) {
		return operations.updateSettings(Map.of(key, request.value()));
	}

	@GetMapping("/settings/backup")
	public Map<String, Object> backupSettings() {
		Map<String, Object> backup = new LinkedHashMap<>();
		backup.put("createdAt", LocalDateTime.now());
		backup.put("settings", operations.allSettings());
		return backup;
	}

	@PostMapping("/settings/backup/restore")
	public Map<String, String> restoreSettings(@RequestBody Map<String, String> settings) {
		return operations.restoreSettings(settings);
	}

	@GetMapping("/notifications")
	public List<Notification> notifications(@RequestParam(defaultValue = "false") boolean unreadOnly) {
		return operations.listNotifications(unreadOnly);
	}

	@PostMapping("/notifications")
	public Notification createNotification(@Valid @RequestBody NotificationRequest request) {
		return operations.createNotification(request);
	}

	@PutMapping("/notifications/{id}/acknowledge")
	public Notification acknowledgeNotification(@PathVariable long id) {
		return operations.acknowledgeNotification(id);
	}

	@GetMapping("/notification-preferences")
	public Map<String, String> preferences(@RequestParam String userId) {
		return operations.notificationPreferences(userId);
	}

	@PutMapping("/notification-preferences")
	public Map<String, String> updatePreferences(
			@RequestParam String userId,
			@RequestBody Map<String, Boolean> preferences) {
		return operations.updateNotificationPreferences(userId, preferences);
	}

	@GetMapping("/audit-logs")
	public List<AuditLog> auditLogs() {
		return operations.auditLogs();
	}

	@GetMapping("/audit-logs/{entityType}/{entityId}")
	public List<AuditLog> auditFor(@PathVariable String entityType, @PathVariable long entityId) {
		return operations.auditFor(entityType, entityId);
	}

	@GetMapping(value = "/audit-logs/export", produces = "text/csv")
	public ResponseEntity<String> exportAuditLogs() {
		StringBuilder csv = new StringBuilder("id,occurredAt,action,entityType,entityId,actor,details\n");
		operations.auditLogs().forEach(log -> csv.append(log.getId()).append(',')
				.append(csv(log.getOccurredAt().toString())).append(',')
				.append(csv(log.getAction())).append(',')
				.append(csv(log.getEntityType())).append(',')
				.append(csv(String.valueOf(log.getEntityId()))).append(',')
				.append(csv(log.getActor())).append(',')
				.append(csv(log.getDetails())).append('\n'));
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
				"attachment; filename=\"audit-logs.csv\"")
				.contentType(MediaType.parseMediaType("text/csv")).body(csv.toString());
	}

	@GetMapping("/audit-logs/compliance-report")
	public Map<String, Object> complianceReport() {
		List<AuditLog> logs = operations.auditLogs();
		return Map.of("generatedAt", LocalDateTime.now(), "recordCount", logs.size(), "auditLogs", logs);
	}

	private String csv(String value) {
		if (value == null) {
			return "";
		}
		String safeValue = value.matches("^[=+\\-@\\t].*") ? "'" + value : value;
		return "\"" + safeValue.replace("\"", "\"\"") + "\"";
	}
}
