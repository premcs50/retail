package com.example.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.InvoiceLine;

public interface InvoiceLineRepository extends JpaRepository<InvoiceLine, Long> {
	List<InvoiceLine> findByInvoiceId(Long invoiceId);
	List<InvoiceLine> findByProductId(Long productId);
}
