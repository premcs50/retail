package com.example.retail.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.retail.controller.ApiModels.InvoiceItemRequest;
import com.example.retail.controller.ApiModels.InvoiceRequest;
import com.example.retail.controller.ApiModels.PaymentRequest;
import com.example.retail.controller.ApiModels.ReturnRequest;
import com.example.retail.entity.BusinessEvent;
import com.example.retail.entity.Invoice;
import com.example.retail.entity.InvoiceLine;
import com.example.retail.entity.Product;
import com.example.retail.repository.BusinessEventRepository;
import com.example.retail.repository.CustomerRepository;
import com.example.retail.repository.InvoiceLineRepository;
import com.example.retail.repository.InvoiceRepository;
import com.example.retail.repository.StoreSettingRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SalesService {
	private static final BigDecimal ZERO = BigDecimal.ZERO;
	private static final DateTimeFormatter INVOICE_DATE = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

	private final RetailService retail;
	private final CustomerRepository customers;
	private final InvoiceRepository invoices;
	private final InvoiceLineRepository invoiceLines;
	private final BusinessEventRepository events;
	private final StoreSettingRepository settings;

	@Transactional
	public Invoice createInvoice(InvoiceRequest request) {
		if (request.customerId() != null && !customers.existsById(request.customerId())) {
			throw ApiException.notFound("Customer not found.");
		}
		TreeSet<Long> productIds = new TreeSet<>();
		for (InvoiceItemRequest item : request.items()) {
			if (!productIds.add(item.productId())) {
				throw ApiException.badRequest("Each product may appear only once on an invoice.");
			}
		}
		Map<Long, Product> lockedProducts = new HashMap<>();
		for (Long productId : productIds) {
			lockedProducts.put(productId, retail.getProductForUpdate(productId));
		}

		Invoice invoice = new Invoice();
		invoice.setInvoiceNumber("INV-" + LocalDateTime.now().format(INVOICE_DATE) + "-"
				+ UUID.randomUUID().toString().substring(0, 6).toUpperCase());
		invoice.setCustomerId(request.customerId());
		invoice.setStaffName(blankToNull(request.staffName()));

		List<InvoiceLine> lines = new ArrayList<>();
		BigDecimal subtotal = ZERO;
		BigDecimal taxTotal = ZERO;
		for (InvoiceItemRequest requestedLine : request.items()) {
			Product product = lockedProducts.get(requestedLine.productId());
			if (!product.isActive()) {
				throw ApiException.conflict("Inactive products cannot be invoiced: " + product.getSku() + ".");
			}
			BigDecimal quantity = requestedLine.quantity();
			if (product.getStockQuantity().compareTo(quantity) < 0) {
				throw ApiException.conflict("Insufficient stock for product " + product.getSku() + ".");
			}
			BigDecimal gross = money(product.getSellingPrice().multiply(quantity));
			BigDecimal lineDiscount = valueOrZero(requestedLine.discount());
			if (lineDiscount.compareTo(gross) > 0) {
				throw ApiException.badRequest("Line discount cannot exceed the line amount.");
			}
			BigDecimal taxableAmount = gross.subtract(lineDiscount);
			BigDecimal lineTax = product.isTaxable()
					? money(taxableAmount.multiply(product.getTaxRate()).movePointLeft(2))
					: ZERO;
			InvoiceLine line = new InvoiceLine();
			line.setProductId(product.getId());
			line.setProductName(product.getName());
			line.setQuantity(quantity);
			line.setUnitPrice(product.getSellingPrice());
			line.setUnitCost(product.getCostPrice());
			line.setTaxRate(product.isTaxable() ? product.getTaxRate() : ZERO);
			line.setDiscount(lineDiscount);
			line.setLineTotal(taxableAmount.add(lineTax));
			lines.add(line);
			subtotal = subtotal.add(gross);
			taxTotal = taxTotal.add(lineTax);
		}

		BigDecimal discount = valueOrZero(request.discount());
		BigDecimal lineDiscounts = lines.stream().map(InvoiceLine::getDiscount).reduce(ZERO, BigDecimal::add);
		BigDecimal maximumDiscountPercent = settingDecimal("billing.maxDiscountPercent", BigDecimal.valueOf(100));
		if (maximumDiscountPercent.signum() < 0
				|| maximumDiscountPercent.compareTo(BigDecimal.valueOf(100)) > 0) {
			throw ApiException.badRequest("billing.maxDiscountPercent must be between 0 and 100.");
		}
		BigDecimal maximumDiscount = subtotal.multiply(maximumDiscountPercent).movePointLeft(2);
		if (discount.add(lineDiscounts).compareTo(maximumDiscount) > 0) {
			throw ApiException.badRequest("Invoice discount exceeds the configured discount limit.");
		}
		BigDecimal grossTotal = subtotal.add(taxTotal);
		if (discount.compareTo(grossTotal) > 0) {
			throw ApiException.badRequest("Invoice discount cannot exceed the invoice total.");
		}
		BigDecimal total = money(grossTotal.subtract(discount));
		BigDecimal paid = valueOrZero(request.amountPaid());
		if (paid.compareTo(total) > 0) {
			throw ApiException.badRequest("Amount paid cannot exceed the invoice total.");
		}
		if (paid.signum() > 0 && (request.paymentMode() == null || request.paymentMode().isBlank())) {
			throw ApiException.badRequest("paymentMode is required when recording an invoice payment.");
		}

		invoice.setSubtotal(money(subtotal));
		invoice.setTaxTotal(money(taxTotal));
		invoice.setDiscountTotal(money(discount.add(lineDiscounts)));
		invoice.setTotal(total);
		invoice.setStatus(paid.compareTo(total) >= 0 ? "PAID" : paid.signum() > 0 ? "PARTIAL" : "UNPAID");
		Invoice saved = invoices.save(invoice);
		for (InvoiceLine line : lines) {
			line.setInvoiceId(saved.getId());
			invoiceLines.save(line);
			Product product = lockedProducts.get(line.getProductId());
			retail.decrementStock(product, line.getQuantity(), "SALE", saved.getInvoiceNumber());
		}
		if (paid.signum() > 0) {
			recordEvent("PAYMENT", paid, request.paymentMode(), saved.getInvoiceNumber(),
					"Payment for invoice " + saved.getInvoiceNumber(), saved.getStaffName(), saved.getId());
		}
		retail.audit("INVOICE_CREATED", "Invoice", saved.getId(), saved.getInvoiceNumber());
		return saved;
	}

	@Transactional(readOnly = true)
	public Invoice getInvoice(long id) {
		return invoices.findById(id).orElseThrow(() -> ApiException.notFound("Invoice not found."));
	}

	@Transactional
	public Invoice getInvoiceForUpdate(long id) {
		return invoices.findByIdForUpdate(id).orElseThrow(() -> ApiException.notFound("Invoice not found."));
	}

	@Transactional(readOnly = true)
	public List<Invoice> listInvoices(LocalDateTime start, LocalDateTime end, Long customerId, String staffName) {
		List<Invoice> result;
		if (start != null || end != null) {
			if (start == null || end == null || end.isBefore(start)) {
				throw ApiException.badRequest("Provide a valid start and end date range.");
			}
			result = invoices.findByCreatedAtBetweenOrderByCreatedAtDesc(start, end);
		} else if (customerId != null) {
			result = invoices.findByCustomerIdOrderByCreatedAtDesc(customerId);
		} else if (staffName != null && !staffName.isBlank()) {
			result = invoices.findByStaffNameIgnoreCase(staffName);
		} else {
			result = invoices.findAll();
		}
		return result.stream()
				.filter(invoice -> customerId == null || customerId.equals(invoice.getCustomerId()))
				.filter(invoice -> staffName == null || staffName.isBlank()
						|| staffName.equalsIgnoreCase(invoice.getStaffName()))
				.sorted((first, second) -> second.getCreatedAt().compareTo(first.getCreatedAt()))
				.toList();
	}

	@Transactional(readOnly = true)
	public List<Invoice> searchInvoices(
			LocalDateTime start, LocalDateTime end, Long customerId, String staffName,
			String query, String paymentMode) {
		List<Invoice> result = listInvoices(start, end, customerId, staffName);
		if (query != null && !query.isBlank()) {
			String term = query.trim().toLowerCase(Locale.ROOT);
			Set<Long> matchingCustomerIds = customers
					.findByNameContainingIgnoreCaseOrPhoneContainingIgnoreCaseOrEmailContainingIgnoreCase(
							query.trim(), query.trim(), query.trim())
					.stream().map(com.example.retail.entity.Customer::getId)
					.collect(java.util.stream.Collectors.toSet());
			result = result.stream().filter(invoice -> invoice.getInvoiceNumber().toLowerCase(Locale.ROOT).contains(term)
					|| matchingCustomerIds.contains(invoice.getCustomerId())).toList();
		}
		if (paymentMode != null && !paymentMode.isBlank()) {
			result = result.stream().filter(invoice -> events.findByInvoiceIdAndType(invoice.getId(), "PAYMENT").stream()
					.anyMatch(event -> paymentMode.equalsIgnoreCase(event.getPaymentMode()))).toList();
		}
		return result;
	}

	@Transactional(readOnly = true)
	public List<InvoiceLine> getInvoiceLines(long id) {
		getInvoice(id);
		return invoiceLines.findByInvoiceId(id);
	}

	@Transactional(readOnly = true)
	public BigDecimal netInvoiceTotal(Invoice invoice) {
		if ("VOID".equals(invoice.getStatus())) {
			return ZERO;
		}
		List<InvoiceLine> lines = invoiceLines.findByInvoiceId(invoice.getId());
		List<BusinessEvent> returns = events.findByInvoiceIdAndType(invoice.getId(), "RETURN");
		BigDecimal lineDiscounts = lines.stream().map(InvoiceLine::getDiscount).reduce(ZERO, BigDecimal::add);
		return lines.stream().map(line -> {
			BigDecimal returnedQuantity = returns.stream()
					.filter(event -> String.valueOf(line.getProductId()).equals(event.getReference()))
					.map(BusinessEvent::getQuantity).filter(quantity -> quantity != null)
					.reduce(ZERO, BigDecimal::add);
			return netLineAmount(invoice, line, returnedQuantity, lineDiscounts);
		}).reduce(ZERO, BigDecimal::add).max(ZERO);
	}

	@Transactional
	public BusinessEvent recordPayment(long invoiceId, PaymentRequest request) {
		Invoice invoice = getInvoiceForUpdate(invoiceId);
		if ("VOID".equals(invoice.getStatus()) || "RETURNED".equals(invoice.getStatus())
				|| "PARTIALLY_RETURNED".equals(invoice.getStatus())) {
			throw ApiException.conflict("Payments cannot be added to a void or returned invoice.");
		}
		BigDecimal alreadyPaid = events.findByInvoiceIdAndType(invoiceId, "PAYMENT").stream()
				.map(BusinessEvent::getAmount).reduce(ZERO, BigDecimal::add);
		BigDecimal refunded = events.findByInvoiceIdAndType(invoiceId, "REFUND").stream()
				.map(BusinessEvent::getAmount).reduce(ZERO, BigDecimal::add);
		if (alreadyPaid.subtract(refunded).add(request.amount()).compareTo(invoice.getTotal()) > 0) {
			throw ApiException.badRequest("Payment exceeds the outstanding invoice balance.");
		}
		BusinessEvent payment = recordEvent("PAYMENT", request.amount(), request.paymentMode(),
				request.reference(), "Payment for invoice " + invoice.getInvoiceNumber(),
				invoice.getStaffName(), invoiceId);
		updatePaymentStatus(invoice, alreadyPaid.add(request.amount()).subtract(refunded));
		retail.audit("PAYMENT_RECORDED", "Invoice", invoiceId, request.amount() + " " + request.paymentMode());
		return payment;
	}

	@Transactional
	public BusinessEvent processReturn(long invoiceId, ReturnRequest request) {
		Invoice invoice = getInvoiceForUpdate(invoiceId);
		if ("VOID".equals(invoice.getStatus())) {
			throw ApiException.conflict("A void invoice cannot be returned.");
		}
		InvoiceLine soldLine = invoiceLines.findByInvoiceId(invoiceId).stream()
				.filter(line -> line.getProductId().equals(request.productId()))
				.findFirst()
				.orElseThrow(() -> ApiException.badRequest("Product is not on this invoice."));
		BigDecimal returned = events.findByInvoiceIdAndType(invoiceId, "RETURN").stream()
				.filter(event -> String.valueOf(request.productId()).equals(event.getReference()))
				.map(BusinessEvent::getQuantity).filter(quantity -> quantity != null)
				.reduce(ZERO, BigDecimal::add);
		if (returned.add(request.quantity()).compareTo(soldLine.getQuantity()) > 0) {
			throw ApiException.conflict("Return quantity exceeds the quantity sold.");
		}

		BigDecimal globalDiscount = invoice.getDiscountTotal().subtract(invoiceLines.findByInvoiceId(invoiceId).stream()
				.map(InvoiceLine::getDiscount).reduce(ZERO, BigDecimal::add));
		BigDecimal lineGross = soldLine.getUnitPrice().multiply(soldLine.getQuantity());
		BigDecimal allocatedInvoiceDiscount = invoice.getSubtotal().signum() == 0 ? ZERO
				: globalDiscount.multiply(lineGross).divide(invoice.getSubtotal(), 2, RoundingMode.HALF_UP);
		BigDecimal maxLineRefund = soldLine.getLineTotal().subtract(allocatedInvoiceDiscount);
		BigDecimal maxRefund = money(maxLineRefund.multiply(request.quantity())
				.divide(soldLine.getQuantity(), 2, RoundingMode.HALF_UP));
		List<BusinessEvent> payments = events.findByInvoiceIdAndType(invoiceId, "PAYMENT");
		BigDecimal paid = payments.stream()
				.map(BusinessEvent::getAmount).reduce(ZERO, BigDecimal::add);
		BigDecimal previousRefunds = events.findByInvoiceIdAndType(invoiceId, "REFUND").stream()
				.map(BusinessEvent::getAmount).reduce(ZERO, BigDecimal::add);
		BigDecimal refundCapacity = paid.subtract(previousRefunds).max(ZERO);
		BigDecimal refund = request.refundAmount() == null ? maxRefund.min(refundCapacity) : request.refundAmount();
		if (refund.signum() < 0) {
			throw ApiException.badRequest("Refund amount must not be negative.");
		}
		if (refund.compareTo(maxRefund) > 0) {
			throw ApiException.badRequest("Refund amount exceeds the value of the returned items.");
		}
		if (previousRefunds.add(refund).compareTo(paid) > 0) {
			throw ApiException.conflict("Refund amount exceeds the amount paid on this invoice.");
		}
		String refundMode = request.paymentMode();
		if ((refundMode == null || refundMode.isBlank()) && !payments.isEmpty()) {
			refundMode = payments.get(0).getPaymentMode();
		}
		Product product = retail.getProduct(request.productId());
		retail.incrementStock(product, request.quantity(), "RETURN", invoice.getInvoiceNumber());
		BusinessEvent returnedEvent = recordEvent("RETURN", refund, refundMode,
				String.valueOf(request.productId()), request.reason(), invoice.getStaffName(), invoiceId);
		returnedEvent.setQuantity(request.quantity());
		events.save(returnedEvent);
		if (refund.signum() > 0) {
			recordEvent("REFUND", refund, refundMode, invoice.getInvoiceNumber(),
					"Refund for return on invoice " + invoice.getInvoiceNumber(), invoice.getStaffName(), invoiceId);
		}
		List<InvoiceLine> invoiceItems = invoiceLines.findByInvoiceId(invoiceId);
		boolean fullyReturned = invoiceItems.stream().allMatch(line -> {
			BigDecimal totalReturned = events.findByInvoiceIdAndType(invoiceId, "RETURN").stream()
					.filter(event -> String.valueOf(line.getProductId()).equals(event.getReference()))
					.map(BusinessEvent::getQuantity).filter(quantity -> quantity != null)
					.reduce(ZERO, BigDecimal::add);
			return totalReturned.compareTo(line.getQuantity()) >= 0;
		});
		invoice.setStatus(fullyReturned ? "RETURNED" : "PARTIALLY_RETURNED");
		invoices.save(invoice);
		retail.audit("PRODUCT_RETURNED", "Invoice", invoiceId,
				request.quantity() + " units of product " + request.productId());
		return returnedEvent;
	}

	@Transactional
	public Invoice voidInvoice(long invoiceId, String reason) {
		if (reason == null || reason.isBlank()) {
			throw ApiException.badRequest("A reason is required to void an invoice.");
		}
		Invoice invoice = getInvoiceForUpdate(invoiceId);
		if ("VOID".equals(invoice.getStatus())) {
			throw ApiException.conflict("Invoice is already void.");
		}
		if (!events.findByInvoiceIdAndType(invoiceId, "RETURN").isEmpty()) {
			throw ApiException.conflict("An invoice with processed returns cannot be voided.");
		}
		List<BusinessEvent> payments = events.findByInvoiceIdAndType(invoiceId, "PAYMENT");
		for (InvoiceLine line : invoiceLines.findByInvoiceId(invoiceId)) {
			Product product = retail.getProduct(line.getProductId());
			retail.incrementStock(product, line.getQuantity(), "VOID_REVERSAL", invoice.getInvoiceNumber());
		}
		invoice.setStatus("VOID");
		Invoice saved = invoices.save(invoice);
		for (BusinessEvent payment : payments) {
			if (payment.getAmount().signum() > 0) {
				recordEvent("REFUND", payment.getAmount(), payment.getPaymentMode(), invoice.getInvoiceNumber(),
						"Automatic refund for void invoice " + invoice.getInvoiceNumber(),
						invoice.getStaffName(), invoiceId);
			}
		}
		BusinessEvent event = new BusinessEvent();
		event.setType("INVOICE_VOID");
		event.setAmount(invoice.getTotal());
		event.setInvoiceId(invoiceId);
		event.setReference(invoice.getInvoiceNumber());
		event.setDescription(reason.trim());
		events.save(event);
		retail.audit("INVOICE_VOIDED", "Invoice", invoiceId, reason.trim());
		return saved;
	}

	@Transactional(readOnly = true)
	public List<BusinessEvent> listPayments(LocalDateTime start, LocalDateTime end, String paymentMode) {
		List<BusinessEvent> result;
		if (start != null || end != null) {
			if (start == null || end == null || end.isBefore(start)) {
				throw ApiException.badRequest("Provide a valid start and end date range.");
			}
			result = events.findByOccurredAtBetweenOrderByOccurredAtDesc(start, end).stream()
					.filter(event -> "PAYMENT".equals(event.getType())).toList();
		} else {
			result = events.findByTypeOrderByOccurredAtDesc("PAYMENT");
		}
		return result.stream().filter(event -> paymentMode == null
				|| paymentMode.equalsIgnoreCase(event.getPaymentMode())).toList();
	}

	private BusinessEvent recordEvent(
			String type, BigDecimal amount, String mode, String reference, String description, String staffName,
			Long invoiceId) {
		if ("PAYMENT".equals(type)) {
			validatePaymentMode(mode);
		}
		BusinessEvent event = new BusinessEvent();
		event.setType(type);
		event.setAmount(amount);
		event.setPaymentMode(blankToNull(mode));
		event.setReference(blankToNull(reference));
		event.setDescription(description);
		event.setStaffName(staffName);
		event.setInvoiceId(invoiceId);
		return events.save(event);
	}

	private void updatePaymentStatus(Invoice invoice, BigDecimal paid) {
		invoice.setStatus(paid.compareTo(invoice.getTotal()) >= 0 ? "PAID" : paid.signum() > 0 ? "PARTIAL" : "UNPAID");
		invoices.save(invoice);
	}

	private BigDecimal valueOrZero(BigDecimal value) {
		return value == null ? ZERO : value;
	}

	private BigDecimal money(BigDecimal value) {
		return value.setScale(2, RoundingMode.HALF_UP);
	}

	private String blankToNull(String value) {
		return value == null || value.isBlank() ? null : value.trim();
	}

	private BigDecimal settingDecimal(String key, BigDecimal fallback) {
		try {
			return settings.findBySettingKey(key).map(setting -> new BigDecimal(setting.getSettingValue()))
					.orElse(fallback);
		} catch (NumberFormatException exception) {
			throw ApiException.badRequest("Invalid numeric value configured for " + key + ".");
		}
	}

	private void validatePaymentMode(String mode) {
		if (mode == null || mode.isBlank()) {
			throw ApiException.badRequest("paymentMode is required.");
		}
		String enabledModes = settings.findBySettingKey("payment.enabledModes")
				.map(setting -> setting.getSettingValue()).orElse(null);
		if (enabledModes != null && java.util.Arrays.stream(enabledModes.split(","))
				.map(String::trim).noneMatch(enabled -> enabled.equalsIgnoreCase(mode.trim()))) {
			throw ApiException.badRequest("This payment mode is disabled by store settings.");
		}
	}

	private BigDecimal netLineAmount(
			Invoice invoice, InvoiceLine line, BigDecimal returnedQuantity, BigDecimal lineDiscounts) {
		if (line.getQuantity().signum() == 0) {
			return ZERO;
		}
		BigDecimal remainingQuantity = line.getQuantity().subtract(returnedQuantity).max(ZERO);
		BigDecimal invoiceDiscount = invoice.getDiscountTotal().subtract(lineDiscounts);
		BigDecimal lineGross = line.getUnitPrice().multiply(line.getQuantity());
		BigDecimal allocatedDiscount = invoice.getSubtotal().signum() == 0 ? ZERO
				: invoiceDiscount.multiply(lineGross).divide(invoice.getSubtotal(), 2, RoundingMode.HALF_UP);
		return line.getLineTotal().subtract(allocatedDiscount).multiply(remainingQuantity)
				.divide(line.getQuantity(), 2, RoundingMode.HALF_UP).max(ZERO);
	}
}
