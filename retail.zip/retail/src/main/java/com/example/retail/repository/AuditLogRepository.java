package com.example.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.AuditLog;

public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
	List<AuditLog> findByEntityTypeAndEntityIdOrderByOccurredAtDesc(String entityType, Long entityId);
	List<AuditLog> findAllByOrderByOccurredAtDesc();
}
