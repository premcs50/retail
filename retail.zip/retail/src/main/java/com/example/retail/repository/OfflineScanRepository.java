package com.example.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.OfflineScan;

public interface OfflineScanRepository extends JpaRepository<OfflineScan, Long> {
	List<OfflineScan> findByStatusOrderByQueuedAtAsc(String status);
}
