package com.example.retail.controller;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfiguration implements WebMvcConfigurer {
	private final ApiChangeInterceptor apiChangeInterceptor;

	public WebConfiguration(ApiChangeInterceptor apiChangeInterceptor) {
		this.apiChangeInterceptor = apiChangeInterceptor;
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(apiChangeInterceptor).addPathPatterns("/api/**");
	}
}
