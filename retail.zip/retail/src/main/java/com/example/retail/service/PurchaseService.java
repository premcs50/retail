package com.example.retail.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.retail.controller.ApiModels.PurchaseItemRequest;
import com.example.retail.controller.ApiModels.PurchaseRequest;
import com.example.retail.entity.Product;
import com.example.retail.entity.Purchase;
import com.example.retail.entity.PurchaseLine;
import com.example.retail.repository.PurchaseLineRepository;
import com.example.retail.repository.PurchaseRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PurchaseService {
	private final PartyService parties;
	private final RetailService retail;
	private final PurchaseRepository purchases;
	private final PurchaseLineRepository lines;

	@Transactional
	public Purchase createPurchase(PurchaseRequest request) {
		if (!parties.getSupplier(request.supplierId()).isActive()) {
			throw ApiException.conflict("Purchases cannot be created for an inactive supplier.");
		}
		List<PurchaseLine> purchaseLines = new ArrayList<>();
		BigDecimal total = BigDecimal.ZERO;
		for (PurchaseItemRequest item : request.items()) {
			Product product = retail.getProduct(item.productId());
			PurchaseLine line = new PurchaseLine();
			line.setProductId(product.getId());
			line.setProductName(product.getName());
			line.setReceiptBarcode(item.barcode() == null || item.barcode().isBlank() ? null : item.barcode().trim());
			line.setQuantity(item.quantity());
			line.setUnitCost(item.unitCost());
			purchaseLines.add(line);
			total = total.add(item.quantity().multiply(item.unitCost()));
		}
		Purchase purchase = new Purchase();
		purchase.setSupplierId(request.supplierId());
		purchase.setTotal(total.setScale(2, RoundingMode.HALF_UP));
		Purchase saved = purchases.save(purchase);
		for (PurchaseLine line : purchaseLines) {
			line.setPurchaseId(saved.getId());
			lines.save(line);
		}
		retail.audit("PURCHASE_CREATED", "Purchase", saved.getId(), "Supplier " + saved.getSupplierId());
		return saved;
	}

	@Transactional
	public Purchase receivePurchase(long id) {
		Purchase purchase = getPurchase(id);
		if ("RECEIVED".equals(purchase.getStatus())) {
			throw ApiException.conflict("Purchase has already been received.");
		}
		for (PurchaseLine line : lines.findByPurchaseId(id)) {
			Product product = retail.getProduct(line.getProductId());
			if (line.getReceiptBarcode() != null
					&& !line.getReceiptBarcode().equalsIgnoreCase(product.getBarcode() == null ? "" : product.getBarcode())) {
				throw ApiException.conflict("Received barcode does not match product " + product.getSku() + ".");
			}
			retail.incrementStock(product, line.getQuantity(), "PURCHASE_RECEIPT", String.valueOf(id));
			product.setCostPrice(line.getUnitCost());
		}
		purchase.setStatus("RECEIVED");
		purchase.setReceivedAt(LocalDateTime.now());
		Purchase saved = purchases.save(purchase);
		retail.audit("PURCHASE_RECEIVED", "Purchase", id, "Stock received from supplier " + purchase.getSupplierId());
		return saved;
	}

	@Transactional(readOnly = true)
	public Purchase getPurchase(long id) {
		return purchases.findById(id).orElseThrow(() -> ApiException.notFound("Purchase not found."));
	}

	@Transactional(readOnly = true)
	public List<Purchase> listPurchases(Long supplierId) {
		return supplierId == null ? purchases.findAll() : purchases.findBySupplierIdOrderByCreatedAtDesc(supplierId);
	}

	@Transactional(readOnly = true)
	public List<PurchaseLine> getPurchaseLines(long id) {
		getPurchase(id);
		return lines.findByPurchaseId(id);
	}
}
