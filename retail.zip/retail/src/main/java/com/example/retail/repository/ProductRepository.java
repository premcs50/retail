package com.example.retail.repository;

import java.util.List;
import java.util.Optional;

import jakarta.persistence.LockModeType;

import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.retail.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
	Optional<Product> findBySkuIgnoreCase(String sku);
	Optional<Product> findByBarcodeIgnoreCase(String barcode);
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	@Query("select product from Product product where product.id = :id")
	Optional<Product> findByIdForUpdate(@Param("id") Long id);
	List<Product> findByNameContainingIgnoreCaseOrSkuContainingIgnoreCase(String name, String sku);
	List<Product> findByCategoryId(Long categoryId);
	List<Product> findByActiveTrue();
	List<Product> findByCategoryIdAndActiveTrue(Long categoryId);
	long countByCategoryId(Long categoryId);
}
