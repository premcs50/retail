package com.example.retail.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "business_events")
@Getter
@Setter
@NoArgsConstructor
public class BusinessEvent {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false, length = 40)
	private String type;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal amount = BigDecimal.ZERO;

	@Column(precision = 12, scale = 3)
	private BigDecimal quantity;

	@Column(length = 40)
	private String paymentMode;

	@Column(length = 80)
	private String reference;

	@Column(length = 500)
	private String description;

	@Column(length = 120)
	private String staffName;

	@Column(length = 40)
	private String status = "RECORDED";

	private Long invoiceId;

	@Column(nullable = false)
	private LocalDateTime occurredAt = LocalDateTime.now();
}
