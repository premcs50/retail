package com.example.retail.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.transaction.annotation.Transactional;

import com.example.retail.controller.ApiModels.BulkStockRequest;
import com.example.retail.controller.ApiModels.CategoryRequest;
import com.example.retail.controller.ApiModels.ProductRequest;
import com.example.retail.controller.ApiModels.StockAdjustmentRequest;
import com.example.retail.entity.Category;
import com.example.retail.entity.Product;
import com.example.retail.entity.StockMovement;
import com.example.retail.service.ApiException;
import com.example.retail.service.RetailService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class CatalogController {
	private final RetailService retail;

	@GetMapping("/categories")
	public List<Category> categories(@RequestParam(defaultValue = "false") boolean includeInactive) {
		return retail.listCategories(includeInactive);
	}

	@PostMapping("/categories")
	public ResponseEntity<Category> createCategory(@Valid @RequestBody CategoryRequest request) {
		return ResponseEntity.status(HttpStatus.CREATED).body(retail.createCategory(request));
	}

	@PutMapping("/categories/{id}")
	public Category updateCategory(@PathVariable long id, @Valid @RequestBody CategoryRequest request) {
		return retail.updateCategory(id, request);
	}

	@DeleteMapping("/categories/{id}")
	public ResponseEntity<Void> deleteCategory(@PathVariable long id) {
		retail.deleteCategory(id);
		return ResponseEntity.noContent().build();
	}

	@GetMapping("/products")
	public List<Product> products(
			@RequestParam(required = false) String q,
			@RequestParam(required = false) Long categoryId,
			@RequestParam(required = false) String stockStatus,
			@RequestParam(defaultValue = "false") boolean includeInactive) {
		return retail.listProducts(q, categoryId, stockStatus, includeInactive);
	}

	@GetMapping("/products/{id}")
	public Product product(@PathVariable long id) {
		return retail.getProduct(id);
	}

	@GetMapping("/products/barcode/{barcode}")
	public Product productByBarcode(@PathVariable String barcode) {
		return retail.findByBarcode(barcode);
	}

	@PostMapping("/products")
	public ResponseEntity<Product> createProduct(@Valid @RequestBody ProductRequest request) {
		return ResponseEntity.status(HttpStatus.CREATED).body(retail.createProduct(request));
	}

	@PutMapping("/products/{id}")
	public Product updateProduct(@PathVariable long id, @Valid @RequestBody ProductRequest request) {
		return retail.updateProduct(id, request);
	}

	@DeleteMapping("/products/{id}")
	public ResponseEntity<Void> deactivateProduct(@PathVariable long id) {
		retail.deactivateProduct(id);
		return ResponseEntity.noContent().build();
	}

	@PostMapping(value = "/products/import", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@Transactional
	public ResponseEntity<List<Product>> importProducts(@RequestParam("file") MultipartFile file) {
		if (file.isEmpty()) {
			throw ApiException.badRequest("CSV file must not be empty.");
		}
		try (BufferedReader reader = new BufferedReader(
				new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
			String header = reader.readLine();
			if (header == null) {
				throw ApiException.badRequest("CSV file must include a header row.");
			}
			List<String> columns = parseCsv(header).stream()
					.map(value -> value.trim().toLowerCase(Locale.ROOT)).toList();
			List<Product> imported = new ArrayList<>();
			String row;
			int lineNumber = 1;
			while ((row = reader.readLine()) != null) {
				lineNumber++;
				if (row.isBlank()) {
					continue;
				}
				try {
					Map<String, String> values = valuesByColumn(columns, parseCsv(row));
					ProductRequest request = new ProductRequest(
							required(values, "name"),
							required(values, "sku"),
							values.get("barcode"),
							decimal(values, "sellingprice", true),
							decimal(values, "costprice", false),
							decimal(values, "taxrate", false),
							bool(values, "taxable"),
							longValue(values.get("categoryid")),
							values.get("unit"),
							decimal(values, "initialstock", false),
							decimal(values, "reorderlevel", false),
							bool(values, "active"));
					imported.add(retail.createProduct(request));
				} catch (ApiException exception) {
					throw ApiException.badRequest("CSV line " + lineNumber + ": " + exception.getMessage());
				}
			}
			return ResponseEntity.status(HttpStatus.CREATED).body(imported);
		} catch (IOException exception) {
			throw new ApiException(HttpStatus.BAD_REQUEST, "Could not read the uploaded CSV file.");
		}
	}

	@GetMapping("/inventory/stock")
	public List<Product> stock(
			@RequestParam(required = false) Long categoryId,
			@RequestParam(required = false) String stockStatus) {
		return retail.listProducts(null, categoryId, stockStatus, false);
	}

	@GetMapping("/inventory/low-stock")
	public List<Product> lowStock() {
		return retail.lowStockProducts();
	}

	@PostMapping("/inventory/{productId}/adjustments")
	public ResponseEntity<StockMovement> adjustStock(
			@PathVariable long productId,
			@Valid @RequestBody StockAdjustmentRequest request) {
		if (request.quantityChange().signum() == 0) {
			throw ApiException.badRequest("quantityChange must not be zero.");
		}
		return ResponseEntity.status(HttpStatus.CREATED).body(
				retail.adjustStock(productId, request.quantityChange(), request.reason(), null));
	}

	@PostMapping("/inventory/stock-counts")
	public List<StockMovement> applyStockCount(@Valid @RequestBody BulkStockRequest request) {
		return retail.applyStockCount(request.counts());
	}

	@GetMapping("/inventory/movements")
	public List<StockMovement> stockHistory(
			@RequestParam(required = false) Long productId,
			@RequestParam(required = false) LocalDateTime start,
			@RequestParam(required = false) LocalDateTime end) {
		return retail.stockHistory(productId, start, end);
	}

	private List<String> parseCsv(String row) {
		List<String> fields = new ArrayList<>();
		StringBuilder value = new StringBuilder();
		boolean quoted = false;
		for (int index = 0; index < row.length(); index++) {
			char character = row.charAt(index);
			if (character == '"' && quoted && index + 1 < row.length() && row.charAt(index + 1) == '"') {
				value.append('"');
				index++;
			} else if (character == '"') {
				quoted = !quoted;
			} else if (character == ',' && !quoted) {
				fields.add(value.toString());
				value.setLength(0);
			} else {
				value.append(character);
			}
		}
		if (quoted) {
			throw ApiException.badRequest("CSV contains an unclosed quoted field.");
		}
		fields.add(value.toString());
		return fields;
	}

	private Map<String, String> valuesByColumn(List<String> columns, List<String> row) {
		if (columns.size() != row.size()) {
			throw ApiException.badRequest("CSV row has a different number of values than the header.");
		}
		Map<String, String> values = new HashMap<>();
		for (int index = 0; index < columns.size(); index++) {
			values.put(columns.get(index), row.get(index).trim());
		}
		return values;
	}

	private String required(Map<String, String> values, String name) {
		String value = values.get(name);
		if (value == null || value.isBlank()) {
			throw ApiException.badRequest("Missing required CSV column value: " + name + ".");
		}
		return value;
	}

	private BigDecimal decimal(Map<String, String> values, String name, boolean required) {
		String value = values.get(name);
		if (value == null || value.isBlank()) {
			if (required) {
				throw ApiException.badRequest("Missing required CSV column value: " + name + ".");
			}
			return null;
		}
		try {
			return new BigDecimal(value);
		} catch (NumberFormatException exception) {
			throw ApiException.badRequest("Invalid number in CSV column: " + name + ".");
		}
	}

	private Long longValue(String value) {
		if (value == null || value.isBlank()) {
			return null;
		}
		try {
			return Long.valueOf(value);
		} catch (NumberFormatException exception) {
			throw ApiException.badRequest("Invalid categoryId in CSV.");
		}
	}

	private Boolean bool(Map<String, String> values, String name) {
		String value = values.get(name);
		if (value == null || value.isBlank()) {
			return null;
		}
		if (!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false")) {
			throw ApiException.badRequest("CSV column " + name + " must be true or false.");
		}
		return Boolean.valueOf(value);
	}
}
