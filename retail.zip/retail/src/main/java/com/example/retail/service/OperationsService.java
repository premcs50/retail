package com.example.retail.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.retail.controller.ApiModels.BusinessEventRequest;
import com.example.retail.controller.ApiModels.CashReconciliationRequest;
import com.example.retail.controller.ApiModels.NotificationRequest;
import com.example.retail.controller.ApiModels.SalesTargetRequest;
import com.example.retail.controller.ApiModels.ShiftRequest;
import com.example.retail.entity.AuditLog;
import com.example.retail.entity.BusinessEvent;
import com.example.retail.entity.Customer;
import com.example.retail.entity.Invoice;
import com.example.retail.entity.InvoiceLine;
import com.example.retail.entity.Notification;
import com.example.retail.entity.Product;
import com.example.retail.entity.SalesTarget;
import com.example.retail.entity.StoreSetting;
import com.example.retail.entity.Supplier;
import com.example.retail.entity.Purchase;
import com.example.retail.repository.AuditLogRepository;
import com.example.retail.repository.BusinessEventRepository;
import com.example.retail.repository.CustomerRepository;
import com.example.retail.repository.InvoiceLineRepository;
import com.example.retail.repository.InvoiceRepository;
import com.example.retail.repository.NotificationRepository;
import com.example.retail.repository.ProductRepository;
import com.example.retail.repository.PurchaseRepository;
import com.example.retail.repository.SalesTargetRepository;
import com.example.retail.repository.StoreSettingRepository;
import com.example.retail.repository.SupplierRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OperationsService {
	private final BusinessEventRepository events;
	private final InvoiceRepository invoices;
	private final InvoiceLineRepository invoiceLines;
	private final ProductRepository products;
	private final CustomerRepository customers;
	private final SupplierRepository suppliers;
	private final PurchaseRepository purchases;
	private final NotificationRepository notifications;
	private final AuditLogRepository auditLogs;
	private final StoreSettingRepository settings;
	private final SalesTargetRepository targets;
	private final RetailService retail;

	@Transactional(readOnly = true)
	public Map<String, Object> dashboard() {
		LocalDate today = LocalDate.now();
		LocalDateTime start = today.atStartOfDay();
		LocalDateTime end = today.plusDays(1).atStartOfDay().minusNanos(1);
		List<Invoice> todayInvoices = invoices.findByCreatedAtBetweenOrderByCreatedAtDesc(start, end).stream()
				.filter(invoice -> !"VOID".equals(invoice.getStatus())).toList();
		BigDecimal salesToday = todayInvoices.stream().map(this::netSale).reduce(BigDecimal.ZERO, BigDecimal::add);
		Map<String, Object> result = new LinkedHashMap<>();
		result.put("date", today);
		result.put("salesToday", salesToday);
		result.put("invoiceCount", todayInvoices.size());
		result.put("productCount", products.count());
		result.put("customerCount", customers.count());
		result.put("supplierCount", suppliers.count());
		result.put("lowStockCount", retail.lowStockProducts().size());
		result.put("lowStockProducts", retail.lowStockProducts());
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, BigDecimal> salesSummary(LocalDateTime start, LocalDateTime end, String groupBy) {
		List<Invoice> sales = salesInRange(start, end);
		Map<String, BigDecimal> result = new LinkedHashMap<>();
		for (Invoice invoice : sales) {
			String key = switch (groupBy == null ? "day" : groupBy.toLowerCase(Locale.ROOT)) {
				case "staff" -> invoice.getStaffName() == null ? "Unknown" : invoice.getStaffName();
				case "customer" -> invoice.getCustomerId() == null ? "Walk-in" : "customer-" + invoice.getCustomerId();
				case "day" -> invoice.getCreatedAt().toLocalDate().toString();
				default -> throw ApiException.badRequest("groupBy must be day, staff, or customer.");
			};
			result.merge(key, netSale(invoice), BigDecimal::add);
		}
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, Object> inventorySummary() {
		List<Product> allProducts = products.findAll();
		BigDecimal retailValue = allProducts.stream()
				.map(product -> product.getSellingPrice().multiply(product.getStockQuantity()))
				.reduce(BigDecimal.ZERO, BigDecimal::add);
		BigDecimal costValue = allProducts.stream()
				.map(product -> product.getCostPrice().multiply(product.getStockQuantity()))
				.reduce(BigDecimal.ZERO, BigDecimal::add);
		Map<String, Object> result = new LinkedHashMap<>();
		result.put("productCount", allProducts.size());
		result.put("totalUnits", allProducts.stream().map(Product::getStockQuantity)
				.reduce(BigDecimal.ZERO, BigDecimal::add));
		result.put("retailValue", retailValue.setScale(2, RoundingMode.HALF_UP));
		result.put("costValue", costValue.setScale(2, RoundingMode.HALF_UP));
		result.put("lowStockProducts", retail.lowStockProducts());
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, BigDecimal> supplierPerformance() {
		Map<String, BigDecimal> result = new LinkedHashMap<>();
		for (Purchase purchase : purchases.findAll()) {
			Supplier supplier = suppliers.findById(purchase.getSupplierId()).orElse(null);
			String name = supplier == null ? "Supplier " + purchase.getSupplierId() : supplier.getName();
			result.merge(name, purchase.getTotal(), BigDecimal::add);
		}
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, BigDecimal> paymentModeSummary(LocalDateTime start, LocalDateTime end) {
		if (start == null || end == null || end.isBefore(start)) {
			throw ApiException.badRequest("Provide a valid start and end date range.");
		}
		Map<String, BigDecimal> result = new LinkedHashMap<>();
		for (BusinessEvent event : events.findByOccurredAtBetweenOrderByOccurredAtDesc(start, end)) {
			if (!"PAYMENT".equals(event.getType()) && !"REFUND".equals(event.getType())) {
				continue;
			}
			String mode = event.getPaymentMode() == null ? "Unknown" : event.getPaymentMode();
			BigDecimal signedAmount = "REFUND".equals(event.getType())
					? event.getAmount().negate() : event.getAmount();
			result.merge(mode, signedAmount, BigDecimal::add);
		}
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, BigDecimal> profitSummary(LocalDateTime start, LocalDateTime end) {
		BigDecimal revenue = BigDecimal.ZERO;
		BigDecimal cost = BigDecimal.ZERO;
		for (Invoice invoice : salesInRange(start, end)) {
			List<InvoiceLine> lines = invoiceLines.findByInvoiceId(invoice.getId());
			BigDecimal lineDiscounts = lines.stream().map(InvoiceLine::getDiscount)
					.reduce(BigDecimal.ZERO, BigDecimal::add);
			BigDecimal invoiceDiscount = invoice.getDiscountTotal().subtract(lineDiscounts);
			List<BusinessEvent> returns = events.findByInvoiceIdAndType(invoice.getId(), "RETURN");
			for (InvoiceLine line : invoiceLines.findByInvoiceId(invoice.getId())) {
				BigDecimal returnedQuantity = returns.stream()
						.filter(event -> String.valueOf(line.getProductId()).equals(event.getReference()))
						.map(BusinessEvent::getQuantity).filter(Objects::nonNull)
						.reduce(BigDecimal.ZERO, BigDecimal::add);
				BigDecimal netQuantity = line.getQuantity().subtract(returnedQuantity).max(BigDecimal.ZERO);
				BigDecimal soldAmount = line.getUnitPrice().multiply(line.getQuantity());
				BigDecimal lineShare = invoice.getSubtotal().signum() == 0 ? BigDecimal.ZERO
						: invoiceDiscount.multiply(soldAmount)
								.divide(invoice.getSubtotal(), 2, RoundingMode.HALF_UP);
				BigDecimal lineDiscount = line.getQuantity().signum() == 0 ? BigDecimal.ZERO
						: line.getDiscount().multiply(netQuantity)
								.divide(line.getQuantity(), 2, RoundingMode.HALF_UP);
				BigDecimal invoiceDiscountShare = line.getQuantity().signum() == 0 ? BigDecimal.ZERO
						: lineShare.multiply(netQuantity)
								.divide(line.getQuantity(), 2, RoundingMode.HALF_UP);
				revenue = revenue.add(line.getUnitPrice().multiply(netQuantity)
						.subtract(lineDiscount).subtract(invoiceDiscountShare));
				cost = cost.add(line.getUnitCost().multiply(netQuantity));
			}
		}
		BigDecimal profit = revenue.subtract(cost);
		return Map.of("revenue", money(revenue), "cost", money(cost), "profit", money(profit),
				"marginPercent", revenue.signum() == 0 ? BigDecimal.ZERO
						: profit.multiply(BigDecimal.valueOf(100)).divide(revenue, 2, RoundingMode.HALF_UP));
	}

	@Transactional(readOnly = true)
	public Map<String, BigDecimal> salesTrends(LocalDateTime start, LocalDateTime end, String period) {
		Map<String, BigDecimal> result = new LinkedHashMap<>();
		for (Invoice invoice : salesInRange(start, end)) {
			LocalDateTime date = invoice.getCreatedAt();
			String key = switch (period == null ? "day" : period.toLowerCase(Locale.ROOT)) {
				case "hour" -> date.toLocalDate() + "T" + String.format("%02d:00", date.getHour());
				case "day" -> date.toLocalDate().toString();
				case "month" -> YearMonth.from(date).toString();
				default -> throw ApiException.badRequest("period must be hour, day, or month.");
			};
			result.merge(key, netSale(invoice), BigDecimal::add);
		}
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, Object> peakSales(LocalDateTime start, LocalDateTime end) {
		Map<Integer, BigDecimal> hours = new LinkedHashMap<>();
		Map<Integer, BigDecimal> days = new LinkedHashMap<>();
		for (Invoice invoice : salesInRange(start, end)) {
			hours.merge(invoice.getCreatedAt().getHour(), netSale(invoice), BigDecimal::add);
			days.merge(invoice.getCreatedAt().getDayOfWeek().getValue(), netSale(invoice), BigDecimal::add);
		}
		return Map.of("salesByHour", hours, "salesByDayOfWeek", days);
	}

	@Transactional(readOnly = true)
	public List<Map<String, Object>> targetPerformance(String period) {
		YearMonth targetMonth = parsePeriod(period);
		List<Map<String, Object>> result = new ArrayList<>();
		for (SalesTarget target : targets.findByPeriod(period)) {
			LocalDateTime start = targetMonth.atDay(1).atStartOfDay();
			LocalDateTime end = targetMonth.plusMonths(1).atDay(1).atStartOfDay().minusNanos(1);
			BigDecimal actual = salesInRange(start, end).stream()
					.filter(invoice -> target.getStaffName() == null || target.getStaffName().isBlank()
							|| target.getStaffName().equalsIgnoreCase(invoice.getStaffName()))
					.map(this::netSale).reduce(BigDecimal.ZERO, BigDecimal::add);
			result.add(Map.of("target", target, "actual", money(actual),
					"variance", money(actual.subtract(target.getTargetAmount()))));
		}
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, BigDecimal> categoryPerformance(LocalDateTime start, LocalDateTime end) {
		Map<String, BigDecimal> result = new LinkedHashMap<>();
		for (Invoice invoice : salesInRange(start, end)) {
			List<InvoiceLine> lines = invoiceLines.findByInvoiceId(invoice.getId());
			BigDecimal lineDiscounts = lines.stream().map(InvoiceLine::getDiscount)
					.reduce(BigDecimal.ZERO, BigDecimal::add);
			List<BusinessEvent> returns = events.findByInvoiceIdAndType(invoice.getId(), "RETURN");
			for (InvoiceLine line : lines) {
				Product product = products.findById(line.getProductId()).orElse(null);
				String key = product == null || product.getCategoryId() == null
						? "Uncategorized" : "category-" + product.getCategoryId();
				result.merge(key, netLineTotal(invoice, line, returnedQuantity(returns, line.getProductId()),
						lineDiscounts),
						BigDecimal::add);
			}
		}
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, BigDecimal> productPerformance(LocalDateTime start, LocalDateTime end) {
		Map<String, BigDecimal> result = new LinkedHashMap<>();
		for (Invoice invoice : salesInRange(start, end)) {
			List<InvoiceLine> lines = invoiceLines.findByInvoiceId(invoice.getId());
			BigDecimal lineDiscounts = lines.stream().map(InvoiceLine::getDiscount)
					.reduce(BigDecimal.ZERO, BigDecimal::add);
			List<BusinessEvent> returns = events.findByInvoiceIdAndType(invoice.getId(), "RETURN");
			for (InvoiceLine line : lines) {
				result.merge(line.getProductName() + " (" + line.getProductId() + ")",
						netLineTotal(invoice, line, returnedQuantity(returns, line.getProductId()), lineDiscounts),
						BigDecimal::add);
			}
		}
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, BigDecimal> customerSegmentSales(LocalDateTime start, LocalDateTime end) {
		Map<String, BigDecimal> result = new LinkedHashMap<>();
		for (Invoice invoice : salesInRange(start, end)) {
			Customer customer = invoice.getCustomerId() == null ? null
					: customers.findById(invoice.getCustomerId()).orElse(null);
			String segment = customer == null || customer.getSegment() == null ? "Unsegmented" : customer.getSegment();
			result.merge(segment, netSale(invoice), BigDecimal::add);
		}
		return result;
	}

	@Transactional
	public BusinessEvent recordExpense(BusinessEventRequest request) {
		return recordEvent("EXPENSE", request.amount(), request.paymentMode(), request.reference(),
				request.description(), request.staffName());
	}

	@Transactional
	public BusinessEvent recordBankDeposit(BusinessEventRequest request) {
		return recordEvent("BANK_DEPOSIT", request.amount(), request.paymentMode(), request.reference(),
				request.description(), request.staffName());
	}

	@Transactional
	public BusinessEvent reconcileCash(CashReconciliationRequest request) {
		BigDecimal expectedCash = request.expectedCash() == null
				? expectedCashFor(LocalDate.now()) : request.expectedCash();
		BusinessEvent event = new BusinessEvent();
		event.setType("CASH_RECONCILIATION");
		event.setAmount(request.actualCash().subtract(expectedCash));
		event.setReference(expectedCash.toPlainString());
		event.setDescription(request.description() == null ? "Daily cash reconciliation" : request.description());
		event.setStaffName(blankToNull(request.staffName()));
		event.setStatus("RECONCILED");
		BusinessEvent saved = events.save(event);
		retail.audit("CASH_RECONCILED", "BusinessEvent", saved.getId(),
				"Expected " + expectedCash + "; actual " + request.actualCash());
		return saved;
	}

	@Transactional(readOnly = true)
	public Map<String, Object> cashSummary(LocalDate date) {
		LocalDate reportDate = date == null ? LocalDate.now() : date;
		BigDecimal expected = expectedCashFor(reportDate);
		List<BusinessEvent> reconciliations = events.findByOccurredAtBetweenOrderByOccurredAtDesc(
				reportDate.atStartOfDay(), reportDate.plusDays(1).atStartOfDay().minusNanos(1)).stream()
				.filter(event -> "CASH_RECONCILIATION".equals(event.getType())).toList();
		Map<String, Object> result = new LinkedHashMap<>();
		result.put("date", reportDate);
		result.put("expectedCash", expected);
		result.put("reconciliations", reconciliations);
		return result;
	}

	@Transactional
	public BusinessEvent openShift(ShiftRequest request) {
		String staff = blankToNull(request.staffName());
		if (staff == null) {
			throw ApiException.badRequest("staffName is required to open a shift.");
		}
		boolean alreadyOpen = events.findByTypeAndStaffNameIgnoreCase("SHIFT_OPEN", staff).stream()
				.anyMatch(event -> "OPEN".equals(event.getStatus()));
		if (alreadyOpen) {
			throw ApiException.conflict("This staff member already has an open shift.");
		}
		BusinessEvent event = new BusinessEvent();
		event.setType("SHIFT_OPEN");
		event.setAmount(request.openingCash());
		event.setStaffName(staff);
		event.setDescription(request.description());
		event.setStatus("OPEN");
		BusinessEvent saved = events.save(event);
		retail.audit("SHIFT_OPENED", "BusinessEvent", saved.getId(), staff);
		return saved;
	}

	@Transactional
	public BusinessEvent closeShift(long shiftId, BusinessEventRequest request) {
		BusinessEvent shift = events.findById(shiftId)
				.orElseThrow(() -> ApiException.notFound("Shift not found."));
		if (!"SHIFT_OPEN".equals(shift.getType()) || !"OPEN".equals(shift.getStatus())) {
			throw ApiException.conflict("Shift is not open.");
		}
		shift.setStatus("CLOSED");
		events.save(shift);
		BusinessEvent close = recordEvent("SHIFT_CLOSE", request.amount(), request.paymentMode(),
				String.valueOf(shiftId), request.description(), shift.getStaffName());
		retail.audit("SHIFT_CLOSED", "BusinessEvent", shiftId, request.description());
		return close;
	}

	@Transactional(readOnly = true)
	public List<BusinessEvent> listEvents(String type, LocalDateTime start, LocalDateTime end) {
		List<BusinessEvent> result;
		if (start != null || end != null) {
			if (start == null || end == null || end.isBefore(start)) {
				throw ApiException.badRequest("Provide a valid start and end date range.");
			}
			result = events.findByOccurredAtBetweenOrderByOccurredAtDesc(start, end);
		} else if (type != null && !type.isBlank()) {
			result = events.findByTypeOrderByOccurredAtDesc(type.toUpperCase(Locale.ROOT));
		} else {
			result = events.findAll();
		}
		return result.stream().filter(event -> type == null || type.isBlank()
				|| type.equalsIgnoreCase(event.getType())).toList();
	}

	@Transactional
	public Notification acknowledgeNotification(long id) {
		Notification notification = notifications.findById(id)
				.orElseThrow(() -> ApiException.notFound("Notification not found."));
		notification.setAcknowledged(true);
		Notification saved = notifications.save(notification);
		retail.audit("NOTIFICATION_ACKNOWLEDGED", "Notification", id, saved.getType());
		return saved;
	}

	@Transactional
	public Notification createNotification(NotificationRequest request) {
		String channel = request.channel() == null || request.channel().isBlank()
				? "IN_APP" : request.channel().trim().toUpperCase(Locale.ROOT);
		if (!List.of("IN_APP", "EMAIL", "SMS").contains(channel)) {
			throw ApiException.badRequest("channel must be IN_APP, EMAIL, or SMS.");
		}
		Notification notification = new Notification();
		notification.setType(request.type().trim());
		notification.setMessage(request.message().trim());
		notification.setChannel(channel);
		Notification saved = notifications.save(notification);
		retail.audit("NOTIFICATION_CREATED", "Notification", saved.getId(), saved.getType());
		return saved;
	}

	@Transactional(readOnly = true)
	public List<Notification> listNotifications(boolean unreadOnly) {
		return unreadOnly ? notifications.findByAcknowledgedFalseOrderByCreatedAtDesc() : notifications.findAll();
	}

	@Transactional
	public Map<String, String> updateNotificationPreferences(String userId, Map<String, Boolean> preferences) {
		if (userId == null || userId.isBlank()) {
			throw ApiException.badRequest("userId is required.");
		}
		preferences.forEach((key, enabled) -> saveSetting("notification.preferences." + userId + "." + key,
				String.valueOf(enabled)));
		retail.audit("NOTIFICATION_PREFERENCES_UPDATED", "NotificationPreference", null, userId);
		return notificationPreferences(userId);
	}

	@Transactional(readOnly = true)
	public Map<String, String> notificationPreferences(String userId) {
		if (userId == null || userId.isBlank()) {
			throw ApiException.badRequest("userId is required.");
		}
		String prefix = "notification.preferences." + userId + ".";
		Map<String, String> result = new LinkedHashMap<>();
		for (StoreSetting setting : settings.findAll()) {
			if (setting.getSettingKey().startsWith(prefix)) {
				result.put(setting.getSettingKey().substring(prefix.length()), setting.getSettingValue());
			}
		}
		return result;
	}

	@Transactional(readOnly = true)
	public Map<String, String> allSettings() {
		Map<String, String> result = new LinkedHashMap<>();
		settings.findAll().stream().sorted(Comparator.comparing(StoreSetting::getSettingKey))
				.forEach(setting -> result.put(setting.getSettingKey(), setting.getSettingValue()));
		return result;
	}

	@Transactional
	public Map<String, String> updateSettings(Map<String, String> updates) {
		updates.forEach(this::saveSetting);
		retail.audit("SETTINGS_UPDATED", "StoreSetting", null, String.join(", ", updates.keySet()));
		return allSettings();
	}

	@Transactional
	public Map<String, String> restoreSettings(Map<String, String> backup) {
		return updateSettings(backup);
	}

	@Transactional
	public SalesTarget setSalesTarget(SalesTargetRequest request) {
		parsePeriod(request.period());
		String staffName = request.staffName() == null ? "" : request.staffName().trim();
		SalesTarget target = targets.findByPeriod(request.period()).stream()
				.filter(existing -> Objects.equals(existing.getStaffName(), staffName))
				.findFirst().orElseGet(SalesTarget::new);
		target.setPeriod(request.period());
		target.setStaffName(staffName);
		target.setTargetAmount(request.targetAmount());
		SalesTarget saved = targets.save(target);
		retail.audit("SALES_TARGET_SET", "SalesTarget", saved.getId(), request.period());
		return saved;
	}

	@Transactional(readOnly = true)
	public List<AuditLog> auditLogs() {
		return auditLogs.findAllByOrderByOccurredAtDesc();
	}

	@Transactional(readOnly = true)
	public List<AuditLog> auditFor(String entityType, long entityId) {
		return auditLogs.findByEntityTypeAndEntityIdOrderByOccurredAtDesc(entityType, entityId);
	}

	private List<Invoice> salesInRange(LocalDateTime start, LocalDateTime end) {
		if (start == null || end == null || end.isBefore(start)) {
			throw ApiException.badRequest("Provide a valid start and end date range.");
		}
		return invoices.findByCreatedAtBetweenOrderByCreatedAtDesc(start, end).stream()
				.filter(invoice -> !"VOID".equals(invoice.getStatus())).toList();
	}

	private BigDecimal expectedCashFor(LocalDate date) {
		LocalDateTime start = date.atStartOfDay();
		LocalDateTime end = date.plusDays(1).atStartOfDay().minusNanos(1);
		List<BusinessEvent> dailyEvents = events.findByOccurredAtBetweenOrderByOccurredAtDesc(start, end);
		BigDecimal cashReceived = dailyEvents.stream()
				.filter(event -> "PAYMENT".equals(event.getType()))
				.filter(event -> "CASH".equalsIgnoreCase(event.getPaymentMode()))
				.map(BusinessEvent::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
		BigDecimal cashRefunds = dailyEvents.stream()
				.filter(event -> "REFUND".equals(event.getType()))
				.filter(event -> "CASH".equalsIgnoreCase(event.getPaymentMode()))
				.map(BusinessEvent::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
		BigDecimal cashExpenses = dailyEvents.stream()
				.filter(event -> "EXPENSE".equals(event.getType())
						&& "CASH".equalsIgnoreCase(event.getPaymentMode()))
				.map(BusinessEvent::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
		BigDecimal cashDeposits = dailyEvents.stream()
				.filter(event -> "BANK_DEPOSIT".equals(event.getType())
						&& "CASH".equalsIgnoreCase(event.getPaymentMode()))
				.map(BusinessEvent::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
		return money(cashReceived.subtract(cashRefunds).subtract(cashExpenses).subtract(cashDeposits));
	}

	private BigDecimal netSale(Invoice invoice) {
		List<InvoiceLine> lines = invoiceLines.findByInvoiceId(invoice.getId());
		List<BusinessEvent> returns = events.findByInvoiceIdAndType(invoice.getId(), "RETURN");
		BigDecimal lineDiscounts = lines.stream().map(InvoiceLine::getDiscount)
				.reduce(BigDecimal.ZERO, BigDecimal::add);
		return lines.stream().map(line -> netLineTotal(invoice, line,
				returnedQuantity(returns, line.getProductId()), lineDiscounts))
				.reduce(BigDecimal.ZERO, BigDecimal::add).max(BigDecimal.ZERO);
	}

	private BigDecimal returnedQuantity(List<BusinessEvent> returns, Long productId) {
		return returns.stream().filter(event -> String.valueOf(productId).equals(event.getReference()))
				.map(BusinessEvent::getQuantity).filter(Objects::nonNull)
				.reduce(BigDecimal.ZERO, BigDecimal::add);
	}

	private BigDecimal netLineTotal(
			Invoice invoice, InvoiceLine line, BigDecimal returnedQuantity, BigDecimal lineDiscounts) {
		BigDecimal remainingQuantity = line.getQuantity().subtract(returnedQuantity).max(BigDecimal.ZERO);
		if (line.getQuantity().signum() == 0) {
			return BigDecimal.ZERO;
		}
		BigDecimal invoiceDiscount = invoice.getDiscountTotal().subtract(lineDiscounts);
		BigDecimal lineGross = line.getUnitPrice().multiply(line.getQuantity());
		BigDecimal allocatedDiscount = invoice.getSubtotal().signum() == 0 ? BigDecimal.ZERO
				: invoiceDiscount.multiply(lineGross).divide(invoice.getSubtotal(), 2, RoundingMode.HALF_UP);
		BigDecimal remainingValue = line.getLineTotal().subtract(allocatedDiscount)
				.multiply(remainingQuantity).divide(line.getQuantity(), 2, RoundingMode.HALF_UP);
		return remainingValue.max(BigDecimal.ZERO);
	}

	private BusinessEvent recordEvent(
			String type, BigDecimal amount, String paymentMode, String reference, String description, String staffName) {
		BusinessEvent event = new BusinessEvent();
		event.setType(type);
		event.setAmount(amount);
		event.setPaymentMode(blankToNull(paymentMode));
		event.setReference(blankToNull(reference));
		event.setDescription(description);
		event.setStaffName(blankToNull(staffName));
		BusinessEvent saved = events.save(event);
		retail.audit(type + "_RECORDED", "BusinessEvent", saved.getId(), description);
		return saved;
	}

	private void saveSetting(String key, String value) {
		if (key == null || key.isBlank() || key.length() > 100) {
			throw ApiException.badRequest("Setting keys must contain between 1 and 100 characters.");
		}
		if (value == null || value.length() > 4000) {
			throw ApiException.badRequest("Setting values must contain at most 4000 characters.");
		}
		StoreSetting setting = settings.findBySettingKey(key)
				.orElseGet(StoreSetting::new);
		setting.setSettingKey(key);
		setting.setSettingValue(value);
		settings.save(setting);
	}

	private BigDecimal money(BigDecimal value) {
		return value.setScale(2, RoundingMode.HALF_UP);
	}

	private String blankToNull(String value) {
		return value == null || value.isBlank() ? null : value.trim();
	}

	private YearMonth parsePeriod(String period) {
		try {
			return YearMonth.parse(period);
		} catch (DateTimeParseException exception) {
			throw ApiException.badRequest("period must use yyyy-MM format.");
		}
	}
}
