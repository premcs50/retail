package com.example.retail.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "stock_movements")
@Getter
@Setter
@NoArgsConstructor
public class StockMovement {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private Long productId;

	@Column(nullable = false, precision = 12, scale = 3)
	private BigDecimal quantityChange;

	@Column(nullable = false, precision = 12, scale = 3)
	private BigDecimal quantityAfter;

	@Column(nullable = false, length = 40)
	private String movementType;

	@Column(length = 500)
	private String reason;

	@Column(length = 100)
	private String reference;

	@Column(nullable = false)
	private LocalDateTime occurredAt = LocalDateTime.now();
}
