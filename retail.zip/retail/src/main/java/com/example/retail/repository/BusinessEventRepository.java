package com.example.retail.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.BusinessEvent;

public interface BusinessEventRepository extends JpaRepository<BusinessEvent, Long> {
	List<BusinessEvent> findByTypeOrderByOccurredAtDesc(String type);
	List<BusinessEvent> findByOccurredAtBetweenOrderByOccurredAtDesc(LocalDateTime start, LocalDateTime end);
	List<BusinessEvent> findByInvoiceId(Long invoiceId);
	List<BusinessEvent> findByInvoiceIdAndType(Long invoiceId, String type);
	List<BusinessEvent> findByTypeAndStaffNameIgnoreCase(String type, String staffName);
}
