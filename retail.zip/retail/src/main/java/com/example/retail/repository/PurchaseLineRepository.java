package com.example.retail.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.PurchaseLine;

public interface PurchaseLineRepository extends JpaRepository<PurchaseLine, Long> {
	List<PurchaseLine> findByPurchaseId(Long purchaseId);
}
