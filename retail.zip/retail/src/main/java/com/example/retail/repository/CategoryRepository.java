package com.example.retail.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> {
	Optional<Category> findByNameIgnoreCase(String name);
}
