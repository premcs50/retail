package com.example.retail.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "purchase_lines")
@Getter
@Setter
@NoArgsConstructor
public class PurchaseLine {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private Long purchaseId;

	@Column(nullable = false)
	private Long productId;

	@Column(nullable = false, length = 180)
	private String productName;

	@Column(length = 100)
	private String receiptBarcode;

	@Column(nullable = false, precision = 12, scale = 3)
	private BigDecimal quantity;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal unitCost;
}
