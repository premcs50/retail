package com.example.retail.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.example.retail.service.LiveUpdateService;

@RestController
public class LiveUpdateController {
	private final LiveUpdateService liveUpdateService;

	public LiveUpdateController(LiveUpdateService liveUpdateService) {
		this.liveUpdateService = liveUpdateService;
	}

	@GetMapping(path = "/api/events/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	public SseEmitter stream() {
		return liveUpdateService.subscribe();
	}
}
