package com.example.retail.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.retail.controller.ApiModels.PurchaseDetails;
import com.example.retail.controller.ApiModels.PurchaseRequest;
import com.example.retail.entity.Purchase;
import com.example.retail.service.PurchaseService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/purchases")
@RequiredArgsConstructor
public class PurchaseController {
	private final PurchaseService purchaseService;

	@GetMapping
	public List<Purchase> list(@RequestParam(required = false) Long supplierId) {
		return purchaseService.listPurchases(supplierId);
	}

	@PostMapping
	public ResponseEntity<PurchaseDetails> create(@Valid @RequestBody PurchaseRequest request) {
		Purchase purchase = purchaseService.createPurchase(request);
		return ResponseEntity.status(HttpStatus.CREATED).body(new PurchaseDetails(
				purchase, purchaseService.getPurchaseLines(purchase.getId())));
	}

	@GetMapping("/{id}")
	public PurchaseDetails get(@PathVariable long id) {
		return new PurchaseDetails(purchaseService.getPurchase(id), purchaseService.getPurchaseLines(id));
	}

	@PutMapping("/{id}/receive")
	public Purchase receive(@PathVariable long id) {
		return purchaseService.receivePurchase(id);
	}
}
