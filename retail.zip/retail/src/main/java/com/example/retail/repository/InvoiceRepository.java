package com.example.retail.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import jakarta.persistence.LockModeType;

import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.retail.entity.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
	Optional<Invoice> findByInvoiceNumberIgnoreCase(String invoiceNumber);
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	@Query("select invoice from Invoice invoice where invoice.id = :id")
	Optional<Invoice> findByIdForUpdate(@Param("id") Long id);
	List<Invoice> findByCreatedAtBetweenOrderByCreatedAtDesc(LocalDateTime start, LocalDateTime end);
	List<Invoice> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
	List<Invoice> findByStaffNameIgnoreCase(String staffName);
}
