package com.example.retail.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "invoices", uniqueConstraints = @UniqueConstraint(columnNames = "invoiceNumber"))
@Getter
@Setter
@NoArgsConstructor
public class Invoice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false, length = 40)
	private String invoiceNumber;

	private Long customerId;

	@Column(length = 120)
	private String staffName;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal subtotal;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal taxTotal;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal discountTotal;

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal total;

	@Column(nullable = false, length = 30)
	private String status = "COMPLETED";

	@Column(nullable = false)
	private LocalDateTime createdAt = LocalDateTime.now();
}
