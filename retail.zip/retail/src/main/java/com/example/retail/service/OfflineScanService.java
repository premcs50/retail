package com.example.retail.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.retail.controller.ApiModels.InvoiceItemRequest;
import com.example.retail.controller.ApiModels.InvoiceRequest;
import com.example.retail.controller.ApiModels.OfflineScanRequest;
import com.example.retail.controller.ApiModels.OfflineSyncRequest;
import com.example.retail.controller.ApiModels.OfflineSyncResponse;
import com.example.retail.entity.Invoice;
import com.example.retail.entity.OfflineScan;
import com.example.retail.entity.Product;
import com.example.retail.repository.OfflineScanRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OfflineScanService {
	private final OfflineScanRepository scans;
	private final RetailService retail;
	private final SalesService sales;

	@Transactional
	public OfflineScan queue(OfflineScanRequest request) {
		OfflineScan scan = new OfflineScan();
		scan.setBarcode(request.barcode().trim());
		scan.setQuantity(request.quantity());
		OfflineScan saved = scans.save(scan);
		retail.audit("OFFLINE_SCAN_QUEUED", "OfflineScan", saved.getId(), saved.getBarcode());
		return saved;
	}

	@Transactional(readOnly = true)
	public List<OfflineScan> pending() {
		return scans.findByStatusOrderByQueuedAtAsc("PENDING");
	}

	@Transactional
	public OfflineSyncResponse sync(OfflineSyncRequest request) {
		List<OfflineScan> pending = scans.findByStatusOrderByQueuedAtAsc("PENDING");
		if (pending.isEmpty()) {
			throw ApiException.conflict("There are no pending barcode scans to sync.");
		}
		List<InvoiceItemRequest> items = pending.stream().map(scan -> {
			Product product = retail.findByBarcode(scan.getBarcode());
			if (!product.isActive()) {
				throw ApiException.conflict("Inactive products cannot be synced: " + product.getSku() + ".");
			}
			return new InvoiceItemRequest(product.getId(), scan.getQuantity(), null);
		}).toList();
		Invoice invoice = sales.createInvoice(new InvoiceRequest(
				request.customerId(), request.staffName(), items, null, request.paymentMode(), null));
		LocalDateTime syncedAt = LocalDateTime.now();
		for (OfflineScan scan : pending) {
			scan.setStatus("SYNCED");
			scan.setInvoiceId(invoice.getId());
			scan.setSyncedAt(syncedAt);
			scans.save(scan);
		}
		retail.audit("OFFLINE_SCANS_SYNCED", "Invoice", invoice.getId(), pending.size() + " scans");
		return new OfflineSyncResponse(invoice.getId(), pending.size());
	}
}
