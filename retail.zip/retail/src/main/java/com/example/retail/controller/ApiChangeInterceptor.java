package com.example.retail.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.example.retail.service.LiveUpdateService;

@Component
public class ApiChangeInterceptor implements HandlerInterceptor {
	private final LiveUpdateService liveUpdateService;

	public ApiChangeInterceptor(LiveUpdateService liveUpdateService) {
		this.liveUpdateService = liveUpdateService;
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception exception) {
		String method = request.getMethod();
		String path = request.getRequestURI();
		if (exception == null && response.getStatus() >= 200 && response.getStatus() < 300
				&& path.startsWith("/api/") && isMutation(method)) {
			liveUpdateService.publish(method, path);
		}
	}

	private boolean isMutation(String method) {
		return "POST".equals(method) || "PUT".equals(method) || "PATCH".equals(method) || "DELETE".equals(method);
	}
}
