package com.example.retail.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.retail.entity.SupplierProduct;

public interface SupplierProductRepository extends JpaRepository<SupplierProduct, Long> {
	List<SupplierProduct> findBySupplierId(Long supplierId);
	List<SupplierProduct> findByProductId(Long productId);
	Optional<SupplierProduct> findBySupplierIdAndProductId(Long supplierId, Long productId);
}
