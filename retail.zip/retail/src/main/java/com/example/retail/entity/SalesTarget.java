package com.example.retail.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "sales_targets", uniqueConstraints = @UniqueConstraint(columnNames = {"period", "staffName"}))
@Getter
@Setter
@NoArgsConstructor
public class SalesTarget {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false, length = 20)
	private String period;

	@Column(length = 120)
	private String staffName = "";

	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal targetAmount;
}
