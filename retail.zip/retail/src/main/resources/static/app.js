const API = "/api";
const state = {
  page: "overview",
  dashboard: null,
  products: [],
  categories: [],
  customers: [],
  suppliers: [],
  purchases: [],
  invoices: [],
  report: null,
  cart: new Map(),
  pending: false,
  liveRefreshPending: false,
  liveRefreshTimer: null
};

const pageLabels = {
  overview: "Overview",
  products: "Products",
  inventory: "Inventory",
  sales: "Sales",
  customers: "Customers",
  suppliers: "Suppliers",
  reports: "Reports",
  settings: "Store settings",
  purchases: "Purchases"
};
const pageContent = document.getElementById("pageContent");
const dialog = document.getElementById("appDialog");
const dialogTitle = document.getElementById("dialogTitle");
const dialogContent = document.getElementById("dialogContent");

document.getElementById("todayLabel").textContent = new Intl.DateTimeFormat("en", {
  month: "short", day: "numeric", year: "numeric"
}).format(new Date());
document.getElementById("dialogClose").addEventListener("click", closeDialog);
dialog.addEventListener("click", event => {
  if (event.target === dialog) closeDialog();
});
document.querySelectorAll("[data-page]").forEach(button => button.addEventListener("click", () => {
  navigate(button.dataset.page);
}));
document.getElementById("notificationButton").addEventListener("click", showNotifications);
const liveUpdates = new EventSource(`${API}/events/stream`);
liveUpdates.addEventListener("connected", scheduleLiveRefresh);
liveUpdates.addEventListener("data-changed", scheduleLiveRefresh);
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible" && state.liveRefreshPending) scheduleLiveRefresh();
});
pageContent.addEventListener("focusout", () => {
  if (state.liveRefreshPending) window.setTimeout(scheduleLiveRefresh, 0);
});

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
  })[character]);
}

function money(value) {
  const currency = state.currency || "INR";
  try {
    return new Intl.NumberFormat("en-IN", { style: "currency", currency, maximumFractionDigits: 2 }).format(Number(value || 0));
  } catch {
    return `${currency} ${number(value, 2)}`;
  }
}

function number(value, digits = 0) {
  return new Intl.NumberFormat("en", { maximumFractionDigits: digits }).format(Number(value || 0));
}

function startOfToday() {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return localDateTime(date);
}

function endOfToday() {
  const date = new Date();
  date.setHours(23, 59, 59, 0);
  return localDateTime(date);
}

function localDateTime(date) {
  const pad = value => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

function queryString(params) {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") query.set(key, value);
  });
  return query.toString();
}

async function api(path, options = {}) {
  const init = { ...options, headers: { ...(options.headers || {}) } };
  if (init.body && !(init.body instanceof FormData)) {
    init.headers["Content-Type"] = "application/json";
  }
  const response = await fetch(`${API}${path}`, init);
  const contentType = response.headers.get("content-type") || "";
  const payload = contentType.includes("application/json")
    ? await response.json()
    : await response.text();
  if (!response.ok) {
    const message = payload?.message || payload?.error || payload || `Request failed (${response.status})`;
    const details = payload?.fields ? Object.values(payload.fields).join(" ") : "";
    throw new Error(`${message}${details ? ` ${details}` : ""}`);
  }
  return payload;
}

function toast(message, type = "success") {
  const item = document.createElement("div");
  item.className = `toast ${type === "error" ? "error" : type === "warning" ? "warning" : ""}`;
  item.textContent = message;
  document.getElementById("toastRegion").append(item);
  window.setTimeout(() => item.remove(), 3900);
}

function setConnection(connected) {
  const light = document.querySelector(".connection-light");
  light.classList.toggle("online", connected);
  light.classList.toggle("offline", !connected);
  document.getElementById("connectionLabel").textContent = connected ? "Store connected" : "API unavailable";
}

function setLoading() {
  pageContent.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><span>Loading store data…</span></div>';
}

function renderError(error, retry) {
  pageContent.innerHTML = `<div class="error-panel"><strong>Could not load ${escapeHtml(pageLabels[state.page].toLowerCase())}</strong><span>${escapeHtml(error.message)}</span><div style="margin-top:14px"><button class="button button-secondary" id="retryButton">Try again</button></div></div>`;
  document.getElementById("retryButton").addEventListener("click", retry);
}

function scheduleLiveRefresh() {
  state.liveRefreshPending = true;
  if (document.visibilityState !== "visible" || dialog.open) return;
  const activeElement = document.activeElement;
  if (pageContent.contains(activeElement) && ["INPUT", "SELECT", "TEXTAREA"].includes(activeElement.tagName)) return;
  window.clearTimeout(state.liveRefreshTimer);
  state.liveRefreshTimer = window.setTimeout(async () => {
    if (dialog.open || document.visibilityState !== "visible") return;
    state.liveRefreshPending = false;
    await loadPage();
  }, 100);
}

async function navigate(page) {
  if (!pageLabels[page]) return;
  state.page = page;
  document.querySelectorAll(".nav-link").forEach(button => button.classList.toggle("active", button.dataset.page === page));
  document.getElementById("pageCrumb").textContent = pageLabels[page];
  if (dialog.open) closeDialog();
  await loadPage();
}

async function loadPage() {
  setLoading();
  try {
    switch (state.page) {
      case "overview": await renderOverview(); break;
      case "products": await renderProducts(); break;
      case "inventory": await renderInventory(); break;
      case "sales": await renderSales(); break;
      case "customers": await renderCustomers(); break;
      case "suppliers": await renderSuppliers(); break;
      case "purchases": await renderPurchases(); break;
      case "reports": await renderReports(); break;
      case "settings": await renderSettings(); break;
      default: await renderOverview();
    }
    setConnection(true);
  } catch (error) {
    setConnection(false);
    renderError(error, loadPage);
  }
}

function heading(title, subtitle, actions = "") {
  return `<div class="page-heading"><div><p class="eyebrow">MARKET STREET · MAIN STORE</p><h1>${escapeHtml(title)}</h1><p>${escapeHtml(subtitle)}</p></div><div class="heading-actions">${actions}</div></div>`;
}

function statCard(label, value, icon, foot, iconClass = "") {
  return `<article class="stat-card"><div class="stat-top"><span>${escapeHtml(label)}</span><span class="stat-icon ${iconClass}">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-foot">${foot}</div></article>`;
}

function tableEmpty(message, colspan = 4) {
  return `<tr><td colspan="${colspan}"><div class="empty-state"><strong>${escapeHtml(message)}</strong>Data will appear here as you use your store.</div></td></tr>`;
}

function stockStatus(product) {
  const qty = Number(product.stockQuantity || 0);
  if (qty <= 0) return '<span class="status-pill danger">Out of stock</span>';
  if (qty <= Number(product.reorderLevel || 0)) return '<span class="status-pill warning">Low stock</span>';
  return '<span class="status-pill">In stock</span>';
}

function statusPill(status) {
  const safe = String(status || "UNKNOWN");
  const kind = ["PAID", "COMPLETED", "RECEIVED"].includes(safe) ? "" :
    ["PARTIAL", "PARTIALLY_RETURNED"].includes(safe) ? "warning" :
      ["VOID", "RETURNED"].includes(safe) ? "danger" : "neutral";
  return `<span class="status-pill ${kind}">${escapeHtml(safe.toLowerCase().replaceAll("_", " "))}</span>`;
}

function shortDate(value) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? escapeHtml(value) : new Intl.DateTimeFormat("en", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(date);
}

async function renderOverview() {
  const [dashboard, invoices, trends, products] = await Promise.all([
    api("/dashboard"),
    api(`/invoices?start=${encodeURIComponent(startOfToday())}&end=${encodeURIComponent(endOfToday())}`),
    api(`/reports/trends?start=${encodeURIComponent(startOfToday())}&end=${encodeURIComponent(endOfToday())}&period=hour`),
    api("/products")
  ]);
  state.dashboard = dashboard;
  state.invoices = invoices;
  state.products = products;
  document.getElementById("productCountNav").textContent = number(dashboard.productCount);
  const lowProducts = (dashboard.lowStockProducts || []).slice(0, 5);
  const recent = [...invoices].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);
  const invoiceTotal = invoices.filter(invoice => invoice.status !== "VOID").reduce((sum, invoice) => sum + Number(invoice.total || 0), 0);
  pageContent.innerHTML = `
    ${heading("Good morning, Store admin", "Here’s what’s happening with your store today.", '<button class="button button-secondary" id="refreshButton">↻ &nbsp;Refresh</button><button class="button button-primary" id="newSaleButton"><span class="button-plus">＋</span>New sale</button>')}
    <div class="stats-grid">
      ${statCard("Sales today", money(invoiceTotal), "↗", `<span class="positive">●</span> ${invoices.length} invoices recorded`)}
      ${statCard("Products", number(dashboard.productCount), "▦", `<span class="positive">●</span> Active catalogue`, "blue")}
      ${statCard("Low stock items", number(dashboard.lowStockCount), "▤", `<span class="attention">●</span> Needs attention`, "orange")}
      ${statCard("Customers", number(dashboard.customerCount), "♙", `<span>In your customer book</span>`, "purple")}
    </div>
    <div class="dashboard-grid">
      <section class="panel">
        <div class="panel-header"><div><h2 class="panel-title">Sales overview</h2><p class="panel-subtitle">Sales recorded today by hour</p></div><select class="select-small" id="chartPeriod"><option value="hour">Today</option><option value="day">By day</option><option value="month">By month</option></select></div>
        <div id="salesChart">${renderChart(trends)}</div>
      </section>
      <section class="panel">
        <div class="panel-header"><div><h2 class="panel-title">Quick actions</h2><p class="panel-subtitle">Your everyday shortcuts</p></div></div>
        <div class="quick-actions">
          <button class="quick-action" data-action="sale"><span class="quick-action-icon">＋</span>Start a new sale<span>→</span></button>
          <button class="quick-action" data-action="product"><span class="quick-action-icon">▦</span>Add a product<span>→</span></button>
          <button class="quick-action" data-action="stock"><span class="quick-action-icon">↕</span>Adjust stock<span>→</span></button>
          <button class="quick-action" data-action="customer"><span class="quick-action-icon">♙</span>Add a customer<span>→</span></button>
        </div>
        <div class="target-card"><div class="target-head"><span>Today's sales</span><span>LIVE</span></div><div class="target-amount">${money(invoiceTotal)} <span>in sales</span></div><div class="progress-track"><div class="progress-fill" style="width:${Math.min(invoiceTotal / 1000 * 100, 100)}%"></div></div><div class="target-foot"><span>Daily progress</span><strong>${Math.min(Math.round(invoiceTotal / 1000 * 100), 100)}% of ${money(1000)}</strong></div></div>
      </section>
    </div>
    <div class="dashboard-grid">
      <section class="panel table-panel"><div class="panel-header"><div><h2 class="panel-title">Recent sales</h2><p class="panel-subtitle">The latest transactions from your store</p></div><button class="button button-secondary button-small" data-go="sales">View all →</button></div>
        <div class="table-wrap"><table><thead><tr><th>Invoice</th><th>Customer</th><th>Date</th><th>Amount</th><th>Status</th></tr></thead><tbody>${recent.length ? recent.map(invoice => `<tr><td class="cell-primary">${escapeHtml(invoice.invoiceNumber)}</td><td>${invoice.customerId ? `Customer #${escapeHtml(invoice.customerId)}` : "Walk-in"}</td><td>${shortDate(invoice.createdAt)}</td><td class="cell-primary">${money(invoice.total)}</td><td>${statusPill(invoice.status)}</td></tr>`).join("") : tableEmpty("No sales yet", 5)}</tbody></table></div>
      </section>
      <section class="panel table-panel"><div class="panel-header"><div><h2 class="panel-title">Stock to watch</h2><p class="panel-subtitle">Products at or below reorder level</p></div><button class="button button-secondary button-small" data-go="inventory">Inventory →</button></div>
        <div class="mini-list">${lowProducts.length ? lowProducts.map(product => `<div class="mini-list-row"><strong>${escapeHtml(product.name)}</strong><span>${number(product.stockQuantity, 2)} left</span></div>`).join("") : '<div class="empty-state"><strong>All stocked up</strong>No products are below their reorder level.</div>'}</div>
      </section>
    </div>`;
  document.getElementById("refreshButton").addEventListener("click", loadPage);
  document.getElementById("newSaleButton").addEventListener("click", openSaleDialog);
  document.querySelectorAll("[data-action]").forEach(button => button.addEventListener("click", () => quickAction(button.dataset.action)));
  document.querySelectorAll("[data-go]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.go)));
  document.getElementById("chartPeriod").addEventListener("change", async event => {
    try {
      const period = event.target.value;
      const dates = period === "hour"
        ? { start: startOfToday(), end: endOfToday() }
        : period === "day"
          ? { start: localDateTime(new Date(new Date().setDate(new Date().getDate() - 6))).slice(0, 10) + "T00:00:00", end: endOfToday() }
          : { start: `${new Date().getFullYear()}-01-01T00:00:00`, end: endOfToday() };
      const data = await api(`/reports/trends?${queryString({ ...dates, period })}`);
      document.getElementById("salesChart").innerHTML = renderChart(data);
    } catch (error) {
      toast(error.message, "error");
    }
  });
}

function renderChart(data) {
  const entries = Object.entries(data || {}).sort(([a], [b]) => a.localeCompare(b));
  const shown = entries.length ? entries.slice(-8) : [];
  const max = Math.max(...shown.map(([, value]) => Number(value)), 1);
  const columns = shown.length ? shown : [["—", 0]];
  return `<div class="chart-area"><div class="chart"><div class="chart-axis"><span>${money(max)}</span><span>${money(max * .66)}</span><span>${money(max * .33)}</span><span>${money(0)}</span></div><div class="chart-main"><div class="chart-grid">${columns.map(([, value], index) => {
    const height = Math.max(Number(value) / max * 100, Number(value) > 0 ? 5 : 1);
    return `<div class="chart-column"><span class="chart-bar ${index === columns.length - 1 ? "primary" : ""}" style="height:${height}%"></span></div>`;
  }).join("")}</div><div class="chart-labels">${columns.map(([label]) => `<span>${escapeHtml(String(label).slice(-5))}</span>`).join("")}</div></div></div><div class="chart-legend"><span class="legend-key"><i class="legend-dot"></i>Sales</span><span class="legend-key"><i class="legend-dot light"></i>Earlier periods</span></div></div>`;
}

async function renderProducts(search = "") {
  const [products, categories] = await Promise.all([
    api(`/products?${queryString({ q: search || undefined, includeInactive: true })}`),
    api("/categories?includeInactive=true")
  ]);
  state.products = products;
  state.categories = categories;
  document.getElementById("productCountNav").textContent = number(products.length);
  pageContent.innerHTML = `
    ${heading("Products", "Manage your catalogue, pricing, and product details.", '<button class="button button-secondary" id="newCategoryButton">＋ Category</button><button class="button button-primary" id="addProductButton"><span class="button-plus">＋</span>Add product</button>')}
    <section class="panel table-panel">
      <div class="panel-header"><div><h2 class="panel-title">Product catalogue</h2><p class="panel-subtitle">${number(products.length)} products in your catalogue</p></div>
        <div class="table-toolbar"><div class="search-box"><input id="productSearch" value="${escapeHtml(search)}" placeholder="Search name or SKU…" aria-label="Search products"></div><select class="toolbar-select" id="productStatusFilter"><option value="all">All stock</option><option value="in">In stock</option><option value="low">Low stock</option><option value="out">Out of stock</option></select></div>
      </div>
      <div class="table-wrap"><table><thead><tr><th>Product</th><th>SKU / Barcode</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead><tbody id="productsBody">${productRows(products)}</tbody></table></div>
      <div class="pagination-note">Showing ${number(products.length)} products · Prices in ${escapeHtml(state.currency || "INR")}</div>
    </section>`;
  document.getElementById("addProductButton").addEventListener("click", () => openProductDialog());
  document.getElementById("newCategoryButton").addEventListener("click", openCategoryDialog);
  const searchInput = document.getElementById("productSearch");
  let timer;
  searchInput.addEventListener("input", () => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => renderProducts(searchInput.value).catch(error => toast(error.message, "error")), 250);
  });
  document.getElementById("productStatusFilter").addEventListener("change", async event => {
    try {
      const filtered = await api(`/products?${queryString({ q: searchInput.value || undefined, stockStatus: event.target.value, includeInactive: true })}`);
      document.getElementById("productsBody").innerHTML = productRows(filtered);
      bindProductActions();
    } catch (error) { toast(error.message, "error"); }
  });
  bindProductActions();
}

function productRows(products) {
  if (!products.length) return tableEmpty("No products found", 7);
  return products.map(product => {
    const category = state.categories.find(item => item.id === product.categoryId);
    return `<tr>
      <td><div class="cell-primary">${escapeHtml(product.name)}</div><div class="cell-sub">${escapeHtml(product.unit || "each")}</div></td>
      <td><div>${escapeHtml(product.sku)}</div><div class="cell-sub">${escapeHtml(product.barcode || "No barcode")}</div></td>
      <td>${escapeHtml(category?.name || "Uncategorized")}</td>
      <td class="cell-primary">${money(product.sellingPrice)}</td>
      <td>${number(product.stockQuantity, 2)} <span class="cell-sub">/ ${number(product.reorderLevel, 2)} min</span></td>
      <td>${product.active ? stockStatus(product) : '<span class="status-pill neutral">Inactive</span>'}</td>
      <td><div class="action-cell"><button class="button button-secondary button-small" data-edit-product="${product.id}">Edit</button><button class="button button-secondary button-small" data-adjust-product="${product.id}">Adjust</button></div></td>
    </tr>`;
  }).join("");
}

function bindProductActions() {
  document.querySelectorAll("[data-edit-product]").forEach(button => button.addEventListener("click", () => {
    const product = state.products.find(item => item.id === Number(button.dataset.editProduct));
    if (product) openProductDialog(product);
  }));
  document.querySelectorAll("[data-adjust-product]").forEach(button => button.addEventListener("click", () => {
    const product = state.products.find(item => item.id === Number(button.dataset.adjustProduct));
    if (product) openAdjustmentDialog(product);
  }));
}

async function renderInventory() {
  const [products, movements] = await Promise.all([api("/inventory/stock?stockStatus=all"), api("/inventory/movements")]);
  state.products = products;
  const totalUnits = products.reduce((sum, product) => sum + Number(product.stockQuantity || 0), 0);
  const low = products.filter(product => Number(product.stockQuantity) <= Number(product.reorderLevel));
  const out = products.filter(product => Number(product.stockQuantity) <= 0);
  pageContent.innerHTML = `
    ${heading("Inventory", "Keep stock accurate and catch low-stock items before they run out.", '<button class="button button-secondary" id="stockCountButton">▤ &nbsp;Stock count</button><button class="button button-primary" id="inventoryAdjustButton">＋ Adjust stock</button>')}
    <div class="stats-grid">
      ${statCard("Total units on hand", number(totalUnits, 2), "▤", "Across active products")}
      ${statCard("Low stock", number(low.length), "↘", "At or below reorder point", "orange")}
      ${statCard("Out of stock", number(out.length), "!", "Items unavailable to sell", "purple")}
      ${statCard("Inventory retail value", money(products.reduce((sum, product) => sum + Number(product.stockQuantity) * Number(product.sellingPrice), 0)), "$", "At current selling price", "blue")}
    </div>
    <section class="panel table-panel"><div class="panel-header"><div><h2 class="panel-title">Current stock</h2><p class="panel-subtitle">Live quantities and reorder thresholds</p></div><div class="search-box"><input id="inventorySearch" placeholder="Search name or SKU…" aria-label="Search stock"></div></div>
      <div class="table-wrap"><table><thead><tr><th>Product</th><th>SKU</th><th>On hand</th><th>Reorder level</th><th>Stock status</th><th>Action</th></tr></thead><tbody>${products.length ? products.map(product => `<tr><td class="cell-primary">${escapeHtml(product.name)}</td><td>${escapeHtml(product.sku)}</td><td class="cell-primary">${number(product.stockQuantity, 2)} ${escapeHtml(product.unit || "")}</td><td>${number(product.reorderLevel, 2)}</td><td>${stockStatus(product)}</td><td><button class="button button-secondary button-small" data-adjust-product="${product.id}">Adjust</button></td></tr>`).join("") : tableEmpty("No inventory found", 6)}</tbody></table></div></section>
    <section class="panel table-panel section-spacer"><div class="panel-header"><div><h2 class="panel-title">Recent stock movements</h2><p class="panel-subtitle">A traceable history of stock changes</p></div></div>
      <div class="table-wrap"><table><thead><tr><th>Time</th><th>Product</th><th>Movement</th><th>Change</th><th>After</th><th>Reason</th></tr></thead><tbody>${movements.slice(0, 12).length ? movements.slice(0, 12).map(movement => {
        const product = products.find(item => item.id === movement.productId);
        const change = Number(movement.quantityChange);
        return `<tr><td>${shortDate(movement.occurredAt)}</td><td class="cell-primary">${escapeHtml(product?.name || `Product #${movement.productId}`)}</td><td>${statusPill(movement.movementType)}</td><td class="${change < 0 ? "" : "cell-primary"}">${change > 0 ? "+" : ""}${number(change, 2)}</td><td>${number(movement.quantityAfter, 2)}</td><td>${escapeHtml(movement.reason || "—")}</td></tr>`;
      }).join("") : tableEmpty("No stock movements yet", 6)}</tbody></table></div></section>`;
  document.getElementById("stockCountButton").addEventListener("click", openStockCountDialog);
  document.getElementById("inventoryAdjustButton").addEventListener("click", () => openAdjustmentDialog());
  bindProductActions();
  document.getElementById("inventorySearch").addEventListener("input", event => {
    const term = event.target.value.toLowerCase();
    document.querySelectorAll(".table-panel tbody tr").forEach(row => row.hidden = !row.textContent.toLowerCase().includes(term));
  });
}

async function renderSales() {
  const invoices = await api(`/invoices?start=${encodeURIComponent(startOfToday())}&end=${encodeURIComponent(endOfToday())}`);
  state.invoices = invoices;
  const nonVoid = invoices.filter(invoice => invoice.status !== "VOID");
  const total = nonVoid.reduce((sum, invoice) => sum + Number(invoice.total || 0), 0);
  const paid = invoices.filter(invoice => ["PAID", "COMPLETED"].includes(invoice.status)).length;
  pageContent.innerHTML = `
    ${heading("Sales", "Review today's transactions and manage customer invoices.", '<button class="button button-primary" id="salesNewButton"><span class="button-plus">＋</span>New sale</button>')}
    <div class="report-kpis">
      <div class="report-kpi"><span>Today's sales</span><strong>${money(total)}</strong></div>
      <div class="report-kpi"><span>Invoices</span><strong>${number(nonVoid.length)}</strong></div>
      <div class="report-kpi"><span>Paid invoices</span><strong>${number(paid)}</strong></div>
    </div>
    <section class="panel table-panel"><div class="panel-header"><div><h2 class="panel-title">Invoice history</h2><p class="panel-subtitle">Search and review invoices for today</p></div><div class="table-toolbar"><div class="search-box"><input id="invoiceSearch" placeholder="Search invoice…" aria-label="Search invoices"></div><select class="toolbar-select" id="invoiceMode"><option value="">All payment modes</option><option>CASH</option><option>CARD</option><option>UPI</option></select></div></div>
      <div class="table-wrap"><table><thead><tr><th>Invoice</th><th>Customer</th><th>Cashier</th><th>Date</th><th>Total</th><th>Status</th><th>Action</th></tr></thead><tbody id="invoiceRows">${invoiceRows(invoices)}</tbody></table></div>
    </section>`;
  document.getElementById("salesNewButton").addEventListener("click", openSaleDialog);
  let timer;
  const search = document.getElementById("invoiceSearch");
  const mode = document.getElementById("invoiceMode");
  const reload = async () => {
    try {
      const data = await api(`/invoices?${queryString({ q: search.value, paymentMode: mode.value, start: startOfToday(), end: endOfToday() })}`);
      state.invoices = data;
      document.getElementById("invoiceRows").innerHTML = invoiceRows(data);
      bindInvoiceActions();
    } catch (error) { toast(error.message, "error"); }
  };
  search.addEventListener("input", () => { window.clearTimeout(timer); timer = window.setTimeout(reload, 250); });
  mode.addEventListener("change", reload);
  bindInvoiceActions();
}

function invoiceRows(invoices) {
  if (!invoices.length) return tableEmpty("No invoices for this date", 7);
  return [...invoices].sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt)).map(invoice => `
    <tr><td class="cell-primary">${escapeHtml(invoice.invoiceNumber)}</td><td>${invoice.customerId ? `Customer #${escapeHtml(invoice.customerId)}` : "Walk-in"}</td><td>${escapeHtml(invoice.staffName || "—")}</td><td>${shortDate(invoice.createdAt)}</td><td class="cell-primary">${money(invoice.total)}</td><td>${statusPill(invoice.status)}</td><td><button class="button button-secondary button-small" data-view-invoice="${invoice.id}">View</button></td></tr>`).join("");
}

function bindInvoiceActions() {
  document.querySelectorAll("[data-view-invoice]").forEach(button => button.addEventListener("click", () => viewInvoice(button.dataset.viewInvoice)));
}

async function renderCustomers(search = "") {
  const customers = await api(`/customers?${queryString({ q: search || undefined })}`);
  state.customers = customers;
  pageContent.innerHTML = `
    ${heading("Customers", "Build stronger relationships with a clear view of customer history.", '<button class="button button-primary" id="addCustomerButton"><span class="button-plus">＋</span>Add customer</button>')}
    <section class="panel table-panel"><div class="panel-header"><div><h2 class="panel-title">Customer book</h2><p class="panel-subtitle">${number(customers.length)} customers</p></div><div class="search-box"><input id="customerSearch" value="${escapeHtml(search)}" placeholder="Search name, phone, email…" aria-label="Search customers"></div></div>
      <div class="table-wrap"><table><thead><tr><th>Customer</th><th>Phone</th><th>Email</th><th>Segment</th><th>Status</th><th>History</th></tr></thead><tbody>${customers.length ? customers.map(customer => `<tr><td><div class="cell-primary">${escapeHtml(customer.name)}</div><div class="cell-sub">${escapeHtml(customer.address || "")}</div></td><td>${escapeHtml(customer.phone || "—")}</td><td>${escapeHtml(customer.email || "—")}</td><td>${escapeHtml(customer.segment || "Unsegmented")}</td><td>${customer.active ? '<span class="status-pill">Active</span>' : '<span class="status-pill neutral">Inactive</span>'}</td><td><button class="button button-secondary button-small" data-customer-history="${customer.id}">Invoices</button></td></tr>`).join("") : tableEmpty("No customers found", 6)}</tbody></table></div></section>`;
  document.getElementById("addCustomerButton").addEventListener("click", openCustomerDialog);
  let timer;
  document.getElementById("customerSearch").addEventListener("input", event => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => renderCustomers(event.target.value).catch(error => toast(error.message, "error")), 250);
  });
  document.querySelectorAll("[data-customer-history]").forEach(button => button.addEventListener("click", () => customerHistory(button.dataset.customerHistory)));
}

async function renderSuppliers(search = "") {
  const suppliers = await api(`/suppliers?${queryString({ q: search || undefined, includeInactive: true })}`);
  state.suppliers = suppliers;
  pageContent.innerHTML = `
    ${heading("Suppliers", "Keep supplier contacts, agreements, and preferred product links up to date.", '<button class="button button-primary" id="addSupplierButton"><span class="button-plus">＋</span>Add supplier</button>')}
    <section class="panel table-panel"><div class="panel-header"><div><h2 class="panel-title">Supplier directory</h2><p class="panel-subtitle">${number(suppliers.length)} supplier records</p></div><div class="search-box"><input id="supplierSearch" value="${escapeHtml(search)}" placeholder="Search suppliers…" aria-label="Search suppliers"></div></div>
      <div class="table-wrap"><table><thead><tr><th>Supplier</th><th>Contact</th><th>Address</th><th>Contract notes</th><th>Status</th><th>Actions</th></tr></thead><tbody>${suppliers.length ? suppliers.map(supplier => `<tr><td class="cell-primary">${escapeHtml(supplier.name)}</td><td><div>${escapeHtml(supplier.phone || "—")}</div><div class="cell-sub">${escapeHtml(supplier.email || "")}</div></td><td>${escapeHtml(supplier.address || "—")}</td><td>${escapeHtml(supplier.contractNotes || "—")}</td><td>${supplier.active ? '<span class="status-pill">Active</span>' : '<span class="status-pill neutral">Inactive</span>'}</td><td><div class="action-cell"><button class="button button-secondary button-small" data-edit-supplier="${supplier.id}">Edit</button>${supplier.active ? `<button class="button button-secondary button-small" data-deactivate-supplier="${supplier.id}">Archive</button>` : ""}</div></td></tr>`).join("") : tableEmpty("No suppliers found", 6)}</tbody></table></div></section>`;
  document.getElementById("addSupplierButton").addEventListener("click", () => openSupplierDialog());
  let timer;
  document.getElementById("supplierSearch").addEventListener("input", event => {
    window.clearTimeout(timer);
    timer = window.setTimeout(() => renderSuppliers(event.target.value).catch(error => toast(error.message, "error")), 250);
  });
  document.querySelectorAll("[data-edit-supplier]").forEach(button => button.addEventListener("click", () => {
    const supplier = suppliers.find(item => item.id === Number(button.dataset.editSupplier));
    if (supplier) openSupplierDialog(supplier);
  }));
  document.querySelectorAll("[data-deactivate-supplier]").forEach(button => button.addEventListener("click", async () => {
    try {
      await api(`/suppliers/${button.dataset.deactivateSupplier}/deactivate`, { method: "PUT" });
      toast("Supplier archived");
      await renderSuppliers(search);
    } catch (error) { toast(error.message, "error"); }
  }));
}

async function renderPurchases() {
  const [purchases, suppliers] = await Promise.all([api("/purchases"), api("/suppliers")]);
  state.purchases = purchases;
  state.suppliers = suppliers;
  pageContent.innerHTML = `
    ${heading("Purchases", "Record supplier orders and receive goods into your stock.", '<button class="button button-primary" id="newPurchaseButton"><span class="button-plus">＋</span>New purchase</button>')}
    <div class="report-kpis"><div class="report-kpi"><span>Purchase orders</span><strong>${number(purchases.length)}</strong></div><div class="report-kpi"><span>Awaiting receipt</span><strong>${number(purchases.filter(item => item.status !== "RECEIVED").length)}</strong></div><div class="report-kpi"><span>Suppliers</span><strong>${number(suppliers.length)}</strong></div></div>
    <section class="panel table-panel"><div class="panel-header"><div><h2 class="panel-title">Purchase history</h2><p class="panel-subtitle">Stock increases only after goods are received</p></div></div>
      <div class="table-wrap"><table><thead><tr><th>Purchase</th><th>Supplier</th><th>Created</th><th>Received</th><th>Total cost</th><th>Status</th><th>Action</th></tr></thead><tbody>${purchases.length ? [...purchases].sort((a,b) => b.id-a.id).map(purchase => {
        const supplier = suppliers.find(item => item.id === purchase.supplierId);
        return `<tr><td class="cell-primary">PO-${purchase.id}</td><td>${escapeHtml(supplier?.name || `Supplier #${purchase.supplierId}`)}</td><td>${shortDate(purchase.createdAt)}</td><td>${purchase.receivedAt ? shortDate(purchase.receivedAt) : "—"}</td><td class="cell-primary">${money(purchase.total)}</td><td>${statusPill(purchase.status)}</td><td><div class="action-cell"><button class="button button-secondary button-small" data-purchase-view="${purchase.id}">View</button>${purchase.status !== "RECEIVED" ? `<button class="button button-primary button-small" data-purchase-receive="${purchase.id}">Receive</button>` : ""}</div></td></tr>`;
      }).join("") : tableEmpty("No purchase records yet", 7)}</tbody></table></div></section>`;
  document.getElementById("newPurchaseButton").addEventListener("click", openPurchaseDialog);
  document.querySelectorAll("[data-purchase-view]").forEach(button => button.addEventListener("click", () => viewPurchase(button.dataset.purchaseView)));
  document.querySelectorAll("[data-purchase-receive]").forEach(button => button.addEventListener("click", async () => {
    try {
      await api(`/purchases/${button.dataset.purchaseReceive}/receive`, { method: "PUT" });
      toast("Goods received and stock updated");
      await loadPage();
    } catch (error) { toast(error.message, "error"); }
  }));
}

async function renderReports() {
  const [dashboard, inventory, sales, profit, paymentModes] = await Promise.all([
    api("/dashboard"),
    api("/reports/inventory"),
    api(`/reports/sales?${queryString({ start: startOfToday(), end: endOfToday(), groupBy: "day" })}`),
    api(`/reports/profit?${queryString({ start: startOfToday(), end: endOfToday() })}`),
    api(`/reports/payment-modes?${queryString({ start: startOfToday(), end: endOfToday() })}`)
  ]);
  state.dashboard = dashboard;
  state.report = { inventory, sales, profit, paymentModes };
  const saleRows = Object.entries(sales);
  const modeRows = Object.entries(paymentModes);
  pageContent.innerHTML = `
    ${heading("Reports & insights", "A clear picture of sales, stock health, and profitability.", '<button class="button button-secondary" id="exportSales">↓ &nbsp;Export sales</button><button class="button button-primary" id="exportInventory">↓ &nbsp;Export stock</button>')}
    <div class="report-kpis"><div class="report-kpi"><span>Today's net sales</span><strong>${money(Object.values(sales).reduce((sum, value) => sum + Number(value), 0))}</strong></div><div class="report-kpi"><span>Inventory at cost</span><strong>${money(inventory.costValue)}</strong></div><div class="report-kpi"><span>Estimated gross profit</span><strong>${money(profit.profit)}</strong></div></div>
    <div class="dashboard-grid"><section class="panel table-panel"><div class="panel-header"><div><h2 class="panel-title">Sales summary</h2><p class="panel-subtitle">Today's sales by day</p></div></div><div class="table-wrap"><table><thead><tr><th>Period</th><th>Sales</th></tr></thead><tbody>${saleRows.length ? saleRows.map(([period, amount]) => `<tr><td>${escapeHtml(period)}</td><td class="cell-primary">${money(amount)}</td></tr>`).join("") : tableEmpty("No sales recorded today", 2)}</tbody></table></div></section>
    <section class="panel table-panel"><div class="panel-header"><div><h2 class="panel-title">Collection by payment mode</h2><p class="panel-subtitle">Payments less refunds, today</p></div></div><div class="table-wrap"><table><thead><tr><th>Payment mode</th><th>Net collected</th></tr></thead><tbody>${modeRows.length ? modeRows.map(([mode, amount]) => `<tr><td>${escapeHtml(mode)}</td><td class="cell-primary">${money(amount)}</td></tr>`).join("") : tableEmpty("No payments recorded today", 2)}</tbody></table></div></section></div>
    <div class="dashboard-grid section-spacer"><section class="panel stock-summary"><h2 class="panel-title">Inventory summary</h2><div class="stock-summary-row"><span>Products in catalogue</span><strong>${number(inventory.productCount)}</strong></div><div class="stock-summary-row"><span>Units available</span><strong>${number(inventory.totalUnits, 2)}</strong></div><div class="stock-summary-row"><span>Retail value</span><strong>${money(inventory.retailValue)}</strong></div><div class="stock-summary-row"><span>Cost value</span><strong>${money(inventory.costValue)}</strong></div><div class="stock-summary-row"><span>Low-stock items</span><strong>${number((inventory.lowStockProducts || []).length)}</strong></div></section>
    <section class="panel stock-summary"><h2 class="panel-title">Profit & margin</h2><div class="stock-summary-row"><span>Sales revenue</span><strong>${money(profit.revenue)}</strong></div><div class="stock-summary-row"><span>Cost of goods</span><strong>${money(profit.cost)}</strong></div><div class="stock-summary-row"><span>Gross profit</span><strong>${money(profit.profit)}</strong></div><div class="stock-summary-row"><span>Gross margin</span><strong>${number(profit.marginPercent, 2)}%</strong></div></section></div>`;
  document.getElementById("exportSales").addEventListener("click", () => downloadFile(`/reports/sales/export?${queryString({ start: startOfToday(), end: endOfToday() })}`, "sales-report.csv"));
  document.getElementById("exportInventory").addEventListener("click", () => downloadFile("/reports/inventory/export", "inventory-report.csv"));
}

async function renderSettings() {
  const settings = await api("/settings");
  state.currency = settings["store.currency"] || state.currency || "INR";
  const fields = [
    ["store.name", "Store name", "Displayed on customer invoices."],
    ["store.address", "Store address", "Your shop's postal address."],
    ["store.phone", "Store phone", "Customer contact number."],
    ["store.currency", "Currency code", "Three-letter ISO code such as INR, USD, EUR, or GBP."],
    ["tax.defaultRate", "Default tax rate (%)", "Used when adding products without a tax rate."],
    ["inventory.defaultUnit", "Default unit", "Unit of measure for new products."],
    ["inventory.defaultReorderLevel", "Default reorder level", "Default low-stock threshold."],
    ["billing.maxDiscountPercent", "Maximum discount (%)", "Discount ceiling for invoices."],
    ["payment.enabledModes", "Enabled payment modes", "Comma-separated list, e.g. CASH,CARD,UPI."]
  ];
  pageContent.innerHTML = `
    ${heading("Store settings", "Set business defaults for products, invoices, and checkout.", '<button class="button button-primary" id="saveSettings">Save changes</button>')}
    <section class="panel"><div class="panel-header"><div><h2 class="panel-title">Business configuration</h2><p class="panel-subtitle">Values are stored with the application database</p></div></div><div class="settings-list" style="padding:0 17px 17px">${fields.map(([key,label,help]) => `<div class="settings-row"><label for="setting-${escapeHtml(key)}">${escapeHtml(label)}<small>${escapeHtml(help)}</small></label><input class="form-control setting-input" id="setting-${escapeHtml(key)}" data-setting="${escapeHtml(key)}" value="${escapeHtml(settings[key] || "")}" placeholder="Not configured"></div>`).join("")}</div></section>
    <section class="panel section-spacer"><div class="panel-header"><div><h2 class="panel-title">Database backup</h2><p class="panel-subtitle">Download your settings configuration for safekeeping</p></div><button class="button button-secondary" id="backupSettings">↓ &nbsp;Download backup</button></div></section>
    <p class="form-note" style="margin-top:12px">Authentication and role permissions are not enforced by this development scaffold. Do not expose it to untrusted clients.</p>`;
  document.getElementById("saveSettings").addEventListener("click", async () => {
    const updates = {};
    document.querySelectorAll(".setting-input").forEach(input => {
      if (input.value.trim()) updates[input.dataset.setting] = input.value.trim();
    });
    try {
      await api("/settings", { method: "PUT", body: JSON.stringify(updates) });
      toast("Store settings saved");
    } catch (error) { toast(error.message, "error"); }
  });
  document.getElementById("backupSettings").addEventListener("click", async () => {
    try {
      const data = await api("/settings/backup");
      downloadText(JSON.stringify(data, null, 2), "retail-settings-backup.json", "application/json");
      toast("Settings backup downloaded");
    } catch (error) { toast(error.message, "error"); }
  });
}

function openDialog(title, body, eyebrow = "STORE WORKSPACE") {
  if (dialog.open) dialog.close();
  dialogTitle.textContent = title;
  document.getElementById("dialogEyebrow").textContent = eyebrow;
  dialogContent.innerHTML = body;
  dialog.showModal();
}

function closeDialog() {
  dialog.close();
  dialogContent.innerHTML = "";
  if (state.liveRefreshPending) scheduleLiveRefresh();
}

async function openProductDialog(product = null) {
  if (!state.categories.length) {
    try { state.categories = await api("/categories"); } catch (error) { toast(error.message, "error"); return; }
  }
  const editing = Boolean(product);
  const categoryOptions = state.categories.filter(category => category.active || category.id === product?.categoryId)
    .map(category => `<option value="${category.id}" ${product?.categoryId === category.id ? "selected" : ""}>${escapeHtml(category.name)}</option>`).join("");
  openDialog(editing ? "Edit product" : "Add a product", `
    <form id="productForm"><div class="form-grid">
      ${field("name","Product name",product?.name || "",true)}
      ${field("sku","SKU",product?.sku || "",true)}
      ${field("barcode","Barcode",product?.barcode || "")}
      ${field("sellingPrice","Selling price",product?.sellingPrice ?? "",true,"number")}
      ${field("costPrice","Cost price",product?.costPrice ?? "",false,"number")}
      ${field("taxRate","Tax rate (%)",product?.taxRate ?? 0,false,"number")}
      <div class="form-field"><label for="productCategory">Category</label><select class="form-control" id="productCategory"><option value="">Uncategorized</option>${categoryOptions}</select></div>
      ${field("unit","Unit of measure",product?.unit || "each")}
      ${field("reorderLevel","Reorder level",product?.reorderLevel ?? 0,false,"number")}
      ${editing ? "" : field("initialStock","Opening stock",0,false,"number")}
      <div class="form-field"><label class="checkbox-field"><input type="checkbox" id="productTaxable" ${product?.taxable === false ? "" : "checked"}> Taxable product</label></div>
      ${editing ? `<div class="form-field"><label class="checkbox-field"><input type="checkbox" id="productActive" ${product.active ? "checked" : ""}> Active in catalogue</label></div>` : ""}
    </div><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button class="button button-primary" type="submit">${editing ? "Save product" : "Create product"}</button></div></form>`);
  dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
  dialogContent.querySelector("#productForm").addEventListener("submit", async event => {
    event.preventDefault();
    const value = id => dialogContent.querySelector(`#${id}`).value.trim();
    const optionalNumber = id => value(id) === "" ? null : Number(value(id));
    const payload = {
      name: value("name"),
      sku: value("sku"),
      barcode: value("barcode") || null,
      sellingPrice: Number(value("sellingPrice")),
      costPrice: optionalNumber("costPrice"),
      taxRate: optionalNumber("taxRate"),
      taxable: dialogContent.querySelector("#productTaxable").checked,
      categoryId: value("productCategory") ? Number(value("productCategory")) : null,
      unit: value("unit") || "each",
      reorderLevel: optionalNumber("reorderLevel")
    };
    if (!editing) payload.initialStock = optionalNumber("initialStock") ?? 0;
    if (editing) payload.active = dialogContent.querySelector("#productActive").checked;
    await submitDialog(event.submitter, async () => {
      await api(editing ? `/products/${product.id}` : "/products", {
        method: editing ? "PUT" : "POST", body: JSON.stringify(payload)
      });
      closeDialog();
      toast(editing ? "Product updated" : "Product added to catalogue");
      await loadPage();
    });
  });
}

function field(id, label, value = "", required = false, type = "text") {
  const step = type === "number" ? 'step="any" min="0"' : "";
  return `<div class="form-field"><label for="${id}">${escapeHtml(label)}${required ? " *" : ""}</label><input class="form-control" id="${id}" name="${id}" type="${type}" value="${escapeHtml(value)}" ${required ? "required" : ""} ${step} autocomplete="off"></div>`;
}

function openCategoryDialog() {
  openDialog("Create a category", `<form id="categoryForm"><div class="form-grid">${field("categoryName","Category name","",true)}${field("categoryDescription","Description")}</div><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button class="button button-primary" type="submit">Create category</button></div></form>`);
  dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
  dialogContent.querySelector("#categoryForm").addEventListener("submit", async event => {
    event.preventDefault();
    await submitDialog(event.submitter, async () => {
      await api("/categories", { method: "POST", body: JSON.stringify({
        name: dialogContent.querySelector("#categoryName").value.trim(),
        description: dialogContent.querySelector("#categoryDescription").value.trim(),
        active: true
      }) });
      closeDialog();
      toast("Category created");
      await loadPage();
    });
  });
}

function openAdjustmentDialog(product = null) {
  const options = state.products.map(item => `<option value="${item.id}" ${product?.id === item.id ? "selected" : ""}>${escapeHtml(item.name)} · ${escapeHtml(item.sku)} (${number(item.stockQuantity, 2)} on hand)</option>`).join("");
  openDialog("Adjust inventory", `<form id="adjustForm"><div class="form-grid"><div class="form-field full"><label for="adjustProduct">Product</label><select class="form-control" id="adjustProduct" required>${options}</select></div>${field("quantityChange","Quantity change (+ or −)","",true,"number")}${field("adjustReason","Reason","Cycle count",true)}</div><p class="form-note">Use a positive number to add stock or a negative number to remove it. Inventory cannot become negative.</p><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button class="button button-primary" type="submit">Save adjustment</button></div></form>`);
  dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
  dialogContent.querySelector("#adjustForm").addEventListener("submit", async event => {
    event.preventDefault();
    const id = dialogContent.querySelector("#adjustProduct").value;
    const payload = {
      quantityChange: Number(dialogContent.querySelector("#quantityChange").value),
      reason: dialogContent.querySelector("#adjustReason").value.trim()
    };
    await submitDialog(event.submitter, async () => {
      await api(`/inventory/${id}/adjustments`, { method: "POST", body: JSON.stringify(payload) });
      closeDialog();
      toast("Inventory updated");
      await loadPage();
    });
  });
}

function openStockCountDialog() {
  const products = state.products;
  const rows = products.map(product => `<div class="form-grid stock-count-row" data-product-id="${product.id}" style="padding:8px 0;border-bottom:1px solid #f0f2f0;grid-template-columns:1fr 130px;align-items:center"><div><strong style="font-size:10px">${escapeHtml(product.name)}</strong><div class="cell-sub">Current: ${number(product.stockQuantity, 2)}</div></div><input class="form-control" type="number" min="0" step="any" value="${escapeHtml(product.stockQuantity)}" aria-label="Physical count for ${escapeHtml(product.name)}"></div>`).join("");
  openDialog("Physical stock count", `<form id="stockCountForm"><div style="max-height:390px;overflow:auto">${rows || '<p class="empty-state">No products available for a stock count.</p>'}</div><p class="form-note">Enter the physically counted quantity. The stock movement log records the difference.</p><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button class="button button-primary" type="submit">Apply count</button></div></form>`);
  dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
  dialogContent.querySelector("#stockCountForm").addEventListener("submit", async event => {
    event.preventDefault();
    const counts = [...dialogContent.querySelectorAll(".stock-count-row")].map(row => ({
      productId: Number(row.dataset.productId),
      physicalCount: Number(row.querySelector("input").value)
    }));
    await submitDialog(event.submitter, async () => {
      await api("/inventory/stock-counts", { method: "POST", body: JSON.stringify({ counts }) });
      closeDialog();
      toast("Physical stock count applied");
      await loadPage();
    });
  });
}

async function openSaleDialog() {
  try {
    const [products, customers] = await Promise.all([api("/products?includeInactive=false"), api("/customers")]);
    state.products = products;
    state.customers = customers;
    state.cart = new Map();
    renderSaleDialog();
  } catch (error) { toast(error.message, "error"); }
}

function renderSaleDialog() {
  const products = state.products.filter(product => product.active && Number(product.stockQuantity) > 0);
  const cartItems = [...state.cart.entries()].map(([id, quantity]) => {
    const product = products.find(item => item.id === id);
    return product ? { product, quantity } : null;
  }).filter(Boolean);
  const subtotal = cartItems.reduce((sum, item) => sum + Number(item.product.sellingPrice) * item.quantity, 0);
  const tax = cartItems.reduce((sum, item) => sum + (item.product.taxable ? Number(item.product.sellingPrice) * item.quantity * Number(item.product.taxRate || 0) / 100 : 0), 0);
  const total = subtotal + tax;
  const options = state.customers.filter(customer => customer.active).map(customer => `<option value="${customer.id}">${escapeHtml(customer.name)}</option>`).join("");
  openDialog("Create a sale", `<div class="cart-layout"><div><div class="form-field" style="margin-bottom:10px"><label for="cartSearch">Add a product</label><input class="form-control" id="cartSearch" placeholder="Search products by name or SKU…"></div><div class="cart-products" id="cartProducts">${products.length ? products.map(product => {
    const quantity = state.cart.get(product.id) || 0;
    return `<div class="cart-product"><div class="product-initial">${escapeHtml(product.name.slice(0,1).toUpperCase())}</div><div class="cart-product-copy"><strong>${escapeHtml(product.name)}</strong><span>${money(product.sellingPrice)} · ${number(product.stockQuantity, 2)} available</span></div><div class="quantity-control">${quantity ? `<button data-cart-remove="${product.id}" aria-label="Remove one">−</button><span>${quantity}</span>` : ""}<button data-cart-add="${product.id}" aria-label="Add one" ${quantity >= Number(product.stockQuantity) ? "disabled" : ""}>+</button></div></div>`;
  }).join("") : '<div class="empty-state"><strong>No available products</strong>Add stock to products before creating a sale.</div>'}</div></div>
    <aside class="cart-summary"><h3>Order summary</h3>${cartItems.length ? cartItems.map(item => `<div class="summary-row"><span>${escapeHtml(item.product.name)} × ${item.quantity}</span><span>${money(Number(item.product.sellingPrice) * item.quantity)}</span></div>`).join("") : '<div class="empty-state">Your cart is empty</div>'}<div class="summary-row"><span>Subtotal</span><span>${money(subtotal)}</span></div><div class="summary-row"><span>Estimated tax</span><span>${money(tax)}</span></div><div class="summary-row total"><span>Total</span><span>${money(total)}</span></div>
    <div class="form-field"><label for="saleCustomer">Customer</label><select class="form-control" id="saleCustomer"><option value="">Walk-in customer</option>${options}</select></div>
    <div class="form-field"><label for="salePayment">Payment mode</label><select class="form-control" id="salePayment"><option>CASH</option><option>CARD</option><option>UPI</option><option value="">Unpaid / record later</option></select></div>
    <div class="form-field"><label for="salePaid">Amount paid</label><input class="form-control" id="salePaid" type="number" min="0" step="0.01" value="${total > 0 ? total.toFixed(2) : "0.00"}"></div>
    <div class="summary-actions"><button class="button button-primary" id="completeSale" ${!cartItems.length ? "disabled" : ""}>Complete sale · ${money(total)}</button><button class="button button-secondary" id="saleCancel">Cancel</button></div></aside></div>`, "POINT OF SALE");
  document.getElementById("saleCancel").addEventListener("click", closeDialog);
  dialogContent.querySelectorAll("[data-cart-add]").forEach(button => button.addEventListener("click", () => {
    const id = Number(button.dataset.cartAdd);
    const product = products.find(item => item.id === id);
    if (product && (state.cart.get(id) || 0) < Number(product.stockQuantity)) state.cart.set(id, (state.cart.get(id) || 0) + 1);
    renderSaleDialog();
    dialogContent.querySelector("#cartSearch").focus();
  }));
  dialogContent.querySelectorAll("[data-cart-remove]").forEach(button => button.addEventListener("click", () => {
    const id = Number(button.dataset.cartRemove);
    const count = (state.cart.get(id) || 0) - 1;
    if (count <= 0) state.cart.delete(id); else state.cart.set(id, count);
    renderSaleDialog();
  }));
  const cartSearch = document.getElementById("cartSearch");
  cartSearch.addEventListener("input", () => {
    const term = cartSearch.value.toLowerCase();
    dialogContent.querySelectorAll(".cart-product").forEach(row => row.hidden = !row.textContent.toLowerCase().includes(term));
  });
  dialogContent.querySelector("#completeSale").addEventListener("click", async event => {
    const customerId = dialogContent.querySelector("#saleCustomer").value;
    const paymentMode = dialogContent.querySelector("#salePayment").value;
    const amountPaid = Number(dialogContent.querySelector("#salePaid").value || 0);
    const payload = {
      customerId: customerId ? Number(customerId) : null,
      staffName: "Store admin",
      items: [...state.cart.entries()].map(([productId, quantity]) => ({ productId, quantity })),
      discount: 0,
      paymentMode: paymentMode || null,
      amountPaid
    };
    await submitDialog(event.currentTarget, async () => {
      const invoice = await api("/invoices", { method: "POST", body: JSON.stringify(payload) });
      closeDialog();
      toast(`Sale completed · ${invoice.invoice.invoiceNumber}`);
      if (state.page === "overview" || state.page === "sales") await loadPage();
      viewInvoice(invoice.invoice.id);
    });
  });
}

async function viewInvoice(id) {
  try {
    const data = await api(`/invoices/${id}`);
    const lines = data.items.map(item => `<tr><td>${escapeHtml(item.productName)}</td><td>${number(item.quantity, 2)}</td><td>${money(item.unitPrice)}</td><td>${money(item.lineTotal)}</td></tr>`).join("");
    openDialog(`Invoice ${data.invoice.invoiceNumber}`, `<div class="stock-summary"><div class="stock-summary-row"><span>Date</span><strong>${shortDate(data.invoice.createdAt)}</strong></div><div class="stock-summary-row"><span>Status</span><strong>${escapeHtml(data.invoice.status)}</strong></div><div class="stock-summary-row"><span>Customer</span><strong>${data.invoice.customerId ? `#${data.invoice.customerId}` : "Walk-in"}</strong></div></div><div class="table-wrap" style="margin-top:12px"><table><thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead><tbody>${lines}</tbody></table></div><div class="stock-summary"><div class="stock-summary-row"><span>Subtotal</span><strong>${money(data.invoice.subtotal)}</strong></div><div class="stock-summary-row"><span>Tax</span><strong>${money(data.invoice.taxTotal)}</strong></div><div class="stock-summary-row"><span>Discount</span><strong>${money(data.invoice.discountTotal)}</strong></div><div class="stock-summary-row"><span>Total</span><strong>${money(data.invoice.total)}</strong></div></div><div class="dialog-actions"><button class="button button-secondary" id="invoicePrint">Print invoice</button><button class="button button-primary" data-cancel>Done</button></div>`, "SALES RECEIPT");
    dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
    dialogContent.querySelector("#invoicePrint").addEventListener("click", () => {
      const printWindow = window.open(`/api/invoices/${id}/print`, "_blank", "noopener");
      if (!printWindow) toast("Allow pop-ups to print the invoice.", "warning");
    });
    if (!["VOID", "RETURNED", "PARTIALLY_RETURNED"].includes(data.invoice.status)) {
      const actions = document.createElement("div");
      actions.className = "dialog-actions";
      actions.innerHTML = `<button class="button button-secondary" id="invoicePaymentAction">Record payment</button><button class="button button-secondary" id="invoiceReturnAction">Process return</button><button class="button button-danger" id="invoiceVoidAction">Void invoice</button>`;
      dialogContent.querySelector(".dialog-actions").before(actions);
      dialogContent.querySelector("#invoicePaymentAction").addEventListener("click", () => openInvoicePaymentDialog(data.invoice));
      dialogContent.querySelector("#invoiceReturnAction").addEventListener("click", () => openInvoiceReturnDialog(data.invoice, data.items));
      dialogContent.querySelector("#invoiceVoidAction").addEventListener("click", () => openInvoiceVoidDialog(data.invoice));
    }
  } catch (error) { toast(error.message, "error"); }
}

function openInvoicePaymentDialog(invoice) {
  openDialog("Record invoice payment", `<form id="invoicePaymentForm"><div class="form-grid">${field("paymentAmount","Payment amount","",true,"number")}<div class="form-field"><label for="invoicePaymentMode">Payment mode</label><select class="form-control" id="invoicePaymentMode" required><option>CASH</option><option>CARD</option><option>UPI</option></select></div>${field("paymentReference","Reference")}</div><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button type="submit" class="button button-primary">Record payment</button></div></form>`, `INVOICE ${invoice.invoiceNumber}`);
  dialogContent.querySelector("[data-cancel]").addEventListener("click", () => viewInvoice(invoice.id));
  dialogContent.querySelector("#invoicePaymentForm").addEventListener("submit", async event => {
    event.preventDefault();
    const payload = {
      amount: Number(dialogContent.querySelector("#paymentAmount").value),
      paymentMode: dialogContent.querySelector("#invoicePaymentMode").value,
      reference: dialogContent.querySelector("#paymentReference").value.trim() || null
    };
    await submitDialog(event.submitter, async () => {
      await api(`/invoices/${invoice.id}/payments`, { method: "POST", body: JSON.stringify(payload) });
      toast("Payment recorded");
      await viewInvoice(invoice.id);
      if (state.page === "sales" || state.page === "overview") await loadPage();
    });
  });
}

function openInvoiceReturnDialog(invoice, items) {
  const options = items.map(item => `<option value="${item.productId}">${escapeHtml(item.productName)} · sold ${number(item.quantity, 2)}</option>`).join("");
  openDialog("Process product return", `<form id="invoiceReturnForm"><div class="form-grid"><div class="form-field full"><label for="returnProduct">Product from invoice</label><select class="form-control" id="returnProduct" required>${options}</select></div>${field("returnQuantity","Quantity to return","1",true,"number")}${field("returnAmount","Refund amount (optional)")}${field("returnReason","Reason","Customer return",true)}<div class="form-field"><label for="returnPaymentMode">Refund mode</label><select class="form-control" id="returnPaymentMode"><option value="">Use original payment mode</option><option>CASH</option><option>CARD</option><option>UPI</option></select></div></div><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button type="submit" class="button button-primary">Process return</button></div></form>`, `INVOICE ${invoice.invoiceNumber}`);
  dialogContent.querySelector("[data-cancel]").addEventListener("click", () => viewInvoice(invoice.id));
  dialogContent.querySelector("#invoiceReturnForm").addEventListener("submit", async event => {
    event.preventDefault();
    const amount = dialogContent.querySelector("#returnAmount").value;
    const mode = dialogContent.querySelector("#returnPaymentMode").value;
    const payload = {
      productId: Number(dialogContent.querySelector("#returnProduct").value),
      quantity: Number(dialogContent.querySelector("#returnQuantity").value),
      reason: dialogContent.querySelector("#returnReason").value.trim(),
      refundAmount: amount === "" ? null : Number(amount),
      paymentMode: mode || null
    };
    await submitDialog(event.submitter, async () => {
      await api(`/invoices/${invoice.id}/returns`, { method: "POST", body: JSON.stringify(payload) });
      toast("Return processed and stock restored");
      await viewInvoice(invoice.id);
      if (state.page === "sales" || state.page === "overview") await loadPage();
    });
  });
}

function openInvoiceVoidDialog(invoice) {
  openDialog("Void invoice", `<form id="invoiceVoidForm"><p class="form-note">Voiding reverses the invoice stock and automatically refunds recorded payments. This cannot be undone.</p><div class="form-field"><label for="voidReason">Reason for voiding</label><textarea class="form-control" id="voidReason" required></textarea></div><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button type="submit" class="button button-danger">Void invoice</button></div></form>`, `INVOICE ${invoice.invoiceNumber}`);
  dialogContent.querySelector("[data-cancel]").addEventListener("click", () => viewInvoice(invoice.id));
  dialogContent.querySelector("#invoiceVoidForm").addEventListener("submit", async event => {
    event.preventDefault();
    const reason = dialogContent.querySelector("#voidReason").value.trim();
    await submitDialog(event.submitter, async () => {
      await api(`/invoices/${invoice.id}/void`, { method: "PUT", body: JSON.stringify({ reason }) });
      closeDialog();
      toast("Invoice voided and stock restored");
      await loadPage();
    });
  });
}

function openCustomerDialog() {
  openDialog("Add a customer", `<form id="customerForm"><div class="form-grid">${field("customerName","Full name","",true)}${field("customerEmail","Email","","","email")}${field("customerPhone","Phone")}${field("customerSegment","Customer segment","REGULAR")}<div class="form-field full"><label for="customerAddress">Address</label><textarea class="form-control" id="customerAddress"></textarea></div></div><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button class="button button-primary" type="submit">Create customer</button></div></form>`);
  dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
  dialogContent.querySelector("#customerForm").addEventListener("submit", async event => {
    event.preventDefault();
    const value = id => dialogContent.querySelector(`#${id}`).value.trim();
    await submitDialog(event.submitter, async () => {
      await api("/customers", { method: "POST", body: JSON.stringify({
        name: value("customerName"), email: value("customerEmail") || null, phone: value("customerPhone") || null,
        segment: value("customerSegment") || null, address: value("customerAddress") || null, active: true
      }) });
      closeDialog();
      toast("Customer added");
      await loadPage();
    });
  });
}

function openSupplierDialog(supplier = null) {
  const editing = Boolean(supplier);
  openDialog(editing ? "Edit supplier" : "Add a supplier", `<form id="supplierForm"><div class="form-grid">${field("supplierName","Supplier name",supplier?.name || "",true)}${field("supplierEmail","Email",supplier?.email || "",false,"email")}${field("supplierPhone","Phone",supplier?.phone || "")}${field("supplierAddress","Address",supplier?.address || "")}<div class="form-field full"><label for="supplierNotes">Contract notes</label><textarea class="form-control" id="supplierNotes">${escapeHtml(supplier?.contractNotes || "")}</textarea></div></div><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button class="button button-primary" type="submit">${editing ? "Save changes" : "Create supplier"}</button></div></form>`);
  dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
  dialogContent.querySelector("#supplierForm").addEventListener("submit", async event => {
    event.preventDefault();
    const value = id => dialogContent.querySelector(`#${id}`).value.trim();
    await submitDialog(event.submitter, async () => {
      await api(editing ? `/suppliers/${supplier.id}` : "/suppliers", {
        method: editing ? "PUT" : "POST",
        body: JSON.stringify({ name: value("supplierName"), email: value("supplierEmail") || null,
          phone: value("supplierPhone") || null, address: value("supplierAddress") || null,
          contractNotes: value("supplierNotes") || null, active: supplier?.active ?? true })
      });
      closeDialog();
      toast(editing ? "Supplier updated" : "Supplier added");
      await loadPage();
    });
  });
}

async function openPurchaseDialog() {
  try {
    const [products, suppliers] = await Promise.all([api("/products?includeInactive=false"), api("/suppliers")]);
    state.products = products;
    state.suppliers = suppliers.filter(supplier => supplier.active);
    if (!state.suppliers.length || !products.some(product => product.active)) {
      toast("Add an active supplier and product before creating a purchase.", "warning");
      return;
    }
    const supplierOptions = state.suppliers.map(supplier => `<option value="${supplier.id}">${escapeHtml(supplier.name)}</option>`).join("");
    const productRows = products.filter(product => product.active).map(product => `<div class="form-grid purchase-line" data-product-id="${product.id}" style="grid-template-columns:minmax(0,1.3fr) 75px 95px;align-items:end;gap:8px;padding:8px 0;border-bottom:1px solid #f0f2f0"><div><label class="checkbox-field"><input type="checkbox" class="purchase-selected"> ${escapeHtml(product.name)} <span class="cell-sub">${escapeHtml(product.sku)}</span></label></div><div class="form-field"><label>Qty</label><input class="form-control purchase-quantity" type="number" step="any" min="0.001" value="1"></div><div class="form-field"><label>Unit cost</label><input class="form-control purchase-cost" type="number" step="0.01" min="0" value="${escapeHtml(product.costPrice ?? 0)}"></div></div>`).join("");
    openDialog("Create purchase order", `<form id="purchaseForm"><div class="form-field" style="margin-bottom:13px"><label for="purchaseSupplier">Supplier</label><select class="form-control" id="purchaseSupplier" required>${supplierOptions}</select></div><p class="eyebrow">SELECT PRODUCTS · SET QUANTITY AND COST</p><div style="max-height:340px;overflow:auto">${productRows}</div><div class="dialog-actions"><button type="button" class="button button-secondary" data-cancel>Cancel</button><button type="submit" class="button button-primary">Create purchase</button></div></form>`, "PROCUREMENT");
    dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
    dialogContent.querySelector("#purchaseForm").addEventListener("submit", async event => {
      event.preventDefault();
      const items = [...dialogContent.querySelectorAll(".purchase-line")].filter(row => row.querySelector(".purchase-selected").checked).map(row => ({
        productId: Number(row.dataset.productId),
        quantity: Number(row.querySelector(".purchase-quantity").value),
        unitCost: Number(row.querySelector(".purchase-cost").value)
      }));
      if (!items.length) { toast("Select at least one product.", "warning"); return; }
      await submitDialog(event.submitter, async () => {
        const result = await api("/purchases", { method: "POST", body: JSON.stringify({
          supplierId: Number(dialogContent.querySelector("#purchaseSupplier").value), items
        }) });
        closeDialog();
        toast(`Purchase PO-${result.purchase.id} created. Receive goods to update inventory.`);
        await loadPage();
      });
    });
  } catch (error) { toast(error.message, "error"); }
}

async function viewPurchase(id) {
  try {
    const result = await api(`/purchases/${id}`);
    const supplier = state.suppliers.find(item => item.id === result.purchase.supplierId);
    const rows = result.items.map(item => `<tr><td>${escapeHtml(item.productName)}</td><td>${number(item.quantity, 2)}</td><td>${money(item.unitCost)}</td><td>${money(Number(item.quantity) * Number(item.unitCost))}</td></tr>`).join("");
    openDialog(`Purchase PO-${result.purchase.id}`, `<div class="stock-summary"><div class="stock-summary-row"><span>Supplier</span><strong>${escapeHtml(supplier?.name || `#${result.purchase.supplierId}`)}</strong></div><div class="stock-summary-row"><span>Status</span><strong>${escapeHtml(result.purchase.status)}</strong></div><div class="stock-summary-row"><span>Order total</span><strong>${money(result.purchase.total)}</strong></div></div><div class="table-wrap" style="margin-top:12px"><table><thead><tr><th>Product</th><th>Qty</th><th>Unit cost</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table></div><div class="dialog-actions"><button class="button button-primary" data-cancel>Done</button></div>`, "PURCHASE ORDER");
    dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
  } catch (error) { toast(error.message, "error"); }
}

async function customerHistory(id) {
  try {
    const invoices = await api(`/customers/${id}/invoices`);
    const rows = invoices.map(invoice => `<tr><td>${escapeHtml(invoice.invoiceNumber)}</td><td>${shortDate(invoice.createdAt)}</td><td>${money(invoice.total)}</td><td>${statusPill(invoice.status)}</td></tr>`).join("");
    openDialog(`Customer #${id} · Purchase history`, `<div class="table-wrap"><table><thead><tr><th>Invoice</th><th>Date</th><th>Total</th><th>Status</th></tr></thead><tbody>${rows || tableEmpty("No purchase history", 4)}</tbody></table></div><div class="dialog-actions"><button class="button button-primary" data-cancel>Done</button></div>`, "CUSTOMER PROFILE");
    dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
  } catch (error) { toast(error.message, "error"); }
}

async function showNotifications() {
  try {
    const notifications = await api("/notifications?unreadOnly=true");
    const rows = notifications.map(item => `<div class="mini-list-row"><div><strong>${escapeHtml(item.type)}</strong><div class="cell-sub">${escapeHtml(item.message)}</div></div><button class="button button-secondary button-small" data-ack="${item.id}">Done</button></div>`).join("");
    openDialog("Notifications", `<div class="mini-list">${rows || '<div class="empty-state"><strong>You’re all caught up</strong>New store notifications will appear here.</div>'}</div><div class="dialog-actions"><button class="button button-primary" data-cancel>Close</button></div>`, "STORE ACTIVITY");
    dialogContent.querySelector("[data-cancel]").addEventListener("click", closeDialog);
    dialogContent.querySelectorAll("[data-ack]").forEach(button => button.addEventListener("click", async () => {
      try {
        await api(`/notifications/${button.dataset.ack}/acknowledge`, { method: "PUT" });
        await showNotifications();
      } catch (error) { toast(error.message, "error"); }
    }));
  } catch (error) { toast(error.message, "error"); }
}

async function submitDialog(button, action) {
  if (state.pending) return;
  state.pending = true;
  const original = button?.textContent;
  if (button) { button.disabled = true; button.textContent = "Saving…"; }
  try {
    await action();
  } catch (error) {
    toast(error.message, "error");
  } finally {
    state.pending = false;
    if (button && button.isConnected) { button.disabled = false; button.textContent = original; }
  }
}

function quickAction(action) {
  if (action === "sale") return openSaleDialog();
  if (action === "product") return openProductDialog();
  if (action === "customer") return openCustomerDialog();
  if (action === "stock") {
    if (state.page !== "inventory") navigate("inventory").then(() => openAdjustmentDialog());
    else openAdjustmentDialog();
  }
}

async function downloadFile(path, filename) {
  try {
    const response = await fetch(`${API}${path}`);
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.message || `Export failed (${response.status})`);
    }
    const blob = await response.blob();
    const anchor = document.createElement("a");
    anchor.href = URL.createObjectURL(blob);
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(anchor.href);
  } catch (error) { toast(error.message, "error"); }
}

function downloadText(content, filename, contentType) {
  const anchor = document.createElement("a");
  anchor.href = URL.createObjectURL(new Blob([content], { type: contentType }));
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(anchor.href);
}

loadPage();
