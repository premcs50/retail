package com.example.retail;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.example.retail.repository.ProductRepository;
import com.example.retail.repository.InvoiceRepository;
import com.example.retail.repository.PurchaseRepository;
import com.example.retail.repository.SupplierRepository;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class RetailApplicationTests {
	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ProductRepository products;

	@Autowired
	private InvoiceRepository invoices;

	@Autowired
	private SupplierRepository suppliers;

	@Autowired
	private PurchaseRepository purchases;

	private String sku;

	@BeforeEach
	void setUp() {
		sku = "SKU-" + UUID.randomUUID();
	}

	@Test
	void contextLoads() {
	}

	@Test
	void opensLiveUpdateStream() throws Exception {
		mockMvc.perform(get("/api/events/stream"))
				.andExpect(status().isOk())
				.andExpect(request().asyncStarted());
	}

	@Test
	void createsProductsAndRejectsDuplicateSkus() throws Exception {
		String product = productJson(sku, 10, 5);
		mockMvc.perform(post("/api/products").contentType(MediaType.APPLICATION_JSON).content(product))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.sku").value(sku))
				.andExpect(jsonPath("$.stockQuantity").value(5));

		mockMvc.perform(post("/api/products")
				.contentType(MediaType.APPLICATION_JSON)
				.content(productJson(sku.toLowerCase(), 10, 1)))
				.andExpect(status().isConflict())
				.andExpect(jsonPath("$.message").value("SKU already exists."));
	}

	@Test
	void invoiceDeductsStockAndRejectsOverselling() throws Exception {
		mockMvc.perform(post("/api/products")
				.contentType(MediaType.APPLICATION_JSON)
				.content(productJson(sku, 10, 3)))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.sku").value(sku));
		long productId = products.findBySkuIgnoreCase(sku).orElseThrow().getId();

		mockMvc.perform(post("/api/invoices")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"staffName\":\"Test\",\"items\":[{\"productId\":" + productId
						+ ",\"quantity\":2}],\"paymentMode\":\"CASH\",\"amountPaid\":22}"))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.invoice.total").value(22));

		mockMvc.perform(get("/api/products/{id}", productId))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.stockQuantity").value(1));

		mockMvc.perform(post("/api/invoices")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"items\":[{\"productId\":" + productId + ",\"quantity\":2}]}"))
				.andExpect(status().isConflict());
	}

	@Test
	void rejectsInvalidProductPrice() throws Exception {
		mockMvc.perform(post("/api/products")
				.contentType(MediaType.APPLICATION_JSON)
				.content(productJson(sku, -1, 0)))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.fields.sellingPrice").exists());
	}

	@Test
	void returnsRestoreStockAndCannotExceedOriginalSale() throws Exception {
		mockMvc.perform(post("/api/products")
				.contentType(MediaType.APPLICATION_JSON)
				.content(productJson(sku, 10, 3)))
				.andExpect(status().isCreated());
		long productId = products.findBySkuIgnoreCase(sku).orElseThrow().getId();
		String staff = "return-" + UUID.randomUUID();

		mockMvc.perform(post("/api/invoices")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"staffName\":\"" + staff + "\",\"items\":[{\"productId\":" + productId
						+ ",\"quantity\":2}],\"paymentMode\":\"CASH\",\"amountPaid\":22}"))
				.andExpect(status().isCreated());
		long invoiceId = invoices.findByStaffNameIgnoreCase(staff).get(0).getId();

		mockMvc.perform(post("/api/invoices/{id}/returns", invoiceId)
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"productId\":" + productId + ",\"quantity\":1,\"reason\":\"Damaged\"}"))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.amount").value(11));
		mockMvc.perform(get("/api/products/{id}", productId))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.stockQuantity").value(2));

		mockMvc.perform(post("/api/invoices/{id}/returns", invoiceId)
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"productId\":" + productId + ",\"quantity\":2,\"reason\":\"Excess quantity\"}"))
				.andExpect(status().isConflict());
	}

	@Test
	void purchaseReceiptAddsStockOnlyOnce() throws Exception {
		String supplierName = "Supplier-" + UUID.randomUUID();
		mockMvc.perform(post("/api/suppliers")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"name\":\"" + supplierName + "\"}"))
				.andExpect(status().isCreated());
		long supplierId = suppliers
				.findByNameContainingIgnoreCaseOrPhoneContainingIgnoreCaseOrEmailContainingIgnoreCase(
						supplierName, supplierName, supplierName).get(0).getId();
		mockMvc.perform(post("/api/products")
				.contentType(MediaType.APPLICATION_JSON)
				.content(productJson(sku, 10, 0)))
				.andExpect(status().isCreated());
		long productId = products.findBySkuIgnoreCase(sku).orElseThrow().getId();

		mockMvc.perform(post("/api/purchases")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\"supplierId\":" + supplierId + ",\"items\":[{\"productId\":" + productId
						+ ",\"quantity\":4,\"unitCost\":6.5}]}"))
				.andExpect(status().isCreated());
		long purchaseId = purchases.findBySupplierIdOrderByCreatedAtDesc(supplierId).get(0).getId();
		mockMvc.perform(get("/api/products/{id}", productId))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.stockQuantity").value(0));

		mockMvc.perform(put("/api/purchases/{id}/receive", purchaseId))
				.andExpect(status().isOk());
		mockMvc.perform(get("/api/products/{id}", productId))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.stockQuantity").value(4))
				.andExpect(jsonPath("$.costPrice").value(6.5));
		mockMvc.perform(put("/api/purchases/{id}/receive", purchaseId))
				.andExpect(status().isConflict());
	}

	private String productJson(String productSku, double price, int stock) {
		return "{\"name\":\"Test product\",\"sku\":\"" + productSku + "\",\"sellingPrice\":" + price
				+ ",\"costPrice\":5,\"taxRate\":10,\"taxable\":true,\"initialStock\":" + stock
				+ ",\"reorderLevel\":1}";
	}
}
