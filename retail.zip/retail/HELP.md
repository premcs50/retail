# Retail API

Spring Boot REST API for the retail product, inventory, sales, procurement, customer, supplier, finance, reporting, notification, configuration, audit, and barcode workflows in the supplied user stories.

## Run locally

Java 17 is required. The default profile uses an in-memory H2 database:

```powershell
.\mvnw.cmd spring-boot:run
```

The API listens on `http://localhost:8080`. H2 data is reset when the application stops. The H2 web console is disabled by default.

### Web application

The retail dashboard is served by the same application. After starting it, open `http://localhost:8080/` in a browser. The UI uses the same-origin `/api` endpoints, so no separate frontend server or CORS configuration is needed. Successful API create, update, and delete requests are broadcast to connected dashboards over Server-Sent Events; dashboard data refreshes automatically after changes, including changes made by Postman. For Postman updates to appear, the collection's `baseUrl` must point to the same running application serving the frontend. If port 8080 is already in use, start on port 8081 with `.\mvnw.cmd spring-boot:run "-Dspring-boot.run.arguments=--server.port=8081"` and open `http://localhost:8081/`; set Postman's `baseUrl` to `http://localhost:8081` too.

To use MySQL, set the connection values before starting the application:

```powershell
$env:DB_URL = "jdbc:mysql://localhost:3306/retail"
$env:DB_USERNAME = "retail_user"
$env:DB_PASSWORD = "your-local-password"
$env:DDL_AUTO = "update"
.\mvnw.cmd spring-boot:run
```

`DB_URL`, `DB_USERNAME`, and `DB_PASSWORD` are optional; their defaults select local H2. `DDL_AUTO` defaults to `update` for development. Configure and apply managed database migrations before using this API in production.

## Main endpoints

All endpoints are under `/api`. JSON request bodies use `Content-Type: application/json` unless noted.

| Area | Routes |
|---|---|
| Categories | `GET/POST /categories`, `PUT/DELETE /categories/{id}` |
| Products | `GET/POST /products`, `GET/PUT/DELETE /products/{id}`, `GET /products/barcode/{barcode}`, `POST /products/import` (multipart field `file`) |
| Inventory | `GET /inventory/stock`, `GET /inventory/low-stock`, `POST /inventory/{productId}/adjustments`, `POST /inventory/stock-counts`, `GET /inventory/movements` |
| Invoices | `GET/POST /invoices`, `GET /invoices/{id}`, `GET /invoices/{id}/print`, `PUT /invoices/{id}/void` |
| Payments and returns | `GET /payments`, `POST /invoices/{id}/payments`, `POST /invoices/{id}/returns` |
| Customers | `GET/POST /customers`, `GET/PUT /customers/{id}`, `GET /customers/{id}/invoices` |
| Suppliers | `GET/POST /suppliers`, `GET/PUT /suppliers/{id}`, `PUT /suppliers/{id}/deactivate`, `GET /suppliers/{id}/products`, `PUT /suppliers/{supplierId}/products/{productId}`, `GET /products/{productId}/suppliers` |
| Purchases | `GET/POST /purchases`, `GET /purchases/{id}`, `PUT /purchases/{id}/receive` |
| Dashboard and reports | `GET /dashboard`; `GET /reports/sales`, `/reports/inventory`, `/reports/profit`, `/reports/trends`, `/reports/peak-sales`, `/reports/products`, `/reports/categories`, `/reports/customer-segments`, `/reports/suppliers`, `/reports/payment-modes`, `/reports/sales-targets`; `POST /reports/sales-targets`; `GET /reports/custom` |
| Exports | `GET /reports/sales/export`, `/reports/inventory/export`, `/dashboard/export`, `/audit-logs/export` (CSV) |
| Cash and shifts | `GET /cash/summary`, `POST /cash/expenses`, `/cash/deposits`, `/cash/reconciliation`; `GET/POST /shifts`, `POST /shifts/{id}/close` |
| Settings | `GET/PUT /settings`, `PUT /settings/{key}`, `GET /settings/backup`, `POST /settings/backup/restore` |
| Notifications | `GET/POST /notifications`, `PUT /notifications/{id}/acknowledge`, `GET/PUT /notification-preferences` |
| Audit | `GET /audit-logs`, `GET /audit-logs/{entityType}/{entityId}`, `GET /audit-logs/compliance-report` |
| Live UI updates | `GET /events/stream` (Server-Sent Events; broadcasts successful API writes to connected dashboards) |
| Barcodes and POS | `GET /barcodes/lookup/{barcode}`, `GET /barcodes/missing`, `GET /barcodes/labels?productIds=1,2` (printable HTML), `POST/GET /barcodes/offline-queue`, `POST /barcodes/offline-sync` |

### Example requests

Create a product (prices are non-negative; tax rate is a percentage from 0 to 100):

```json
{
  "name": "Coffee",
  "sku": "COF-001",
  "barcode": "1234567890123",
  "sellingPrice": 12.50,
  "costPrice": 7.25,
  "taxRate": 8.5,
  "taxable": true,
  "categoryId": 1,
  "unit": "each",
  "initialStock": 20,
  "reorderLevel": 5
}
```

Create an invoice. Tax is calculated from each taxable product's stored rate. The invoice-level `discount` is a currency amount, as are item discounts. `amountPaid` and `paymentMode` are optional; omit `amountPaid` to leave the invoice unpaid.

```json
{
  "customerId": 4,
  "staffName": "cashier-1",
  "items": [
    { "productId": 1, "quantity": 2, "discount": 0.50 }
  ],
  "discount": 1.00,
  "paymentMode": "CASH",
  "amountPaid": 25.00
}
```

Product imports accept a CSV upload with a header row. Supported column names are `name`, `sku`, `sellingPrice` (required), `barcode`, `costPrice`, `taxRate`, `taxable`, `categoryId`, `unit`, `initialStock`, `reorderLevel`, and `active`. Stock count requests use `{"counts":[{"productId":1,"physicalCount":8}]}`; each count is the new physical quantity, not a delta.

Date/time filters use ISO local date-time values, for example `start=2026-10-28T00:00:00&end=2026-10-28T23:59:59`. `GET /reports/sales` supports `groupBy=day|staff|customer`; trends support `period=hour|day|month`.

Store defaults and switches are stored as strings through `PUT /api/settings`. Common keys are `tax.defaultRate`, `tax.defaultTaxable`, `inventory.defaultUnit`, `inventory.defaultReorderLevel`, `billing.maxDiscountPercent`, and `payment.enabledModes` (a comma-separated list such as `CASH,CARD,UPI`). These defaults apply to new products and invoices; product-specific tax values remain authoritative. Configure payment modes before recording invoice payments if a store-specific allow-list is required.

Validation errors return HTTP 400 with a `fields` object. Duplicate keys and other persistence constraint conflicts return HTTP 409. Missing resources return HTTP 404. Stock cannot become negative; invoices reject inactive products and insufficient stock.

## Story scope and integration boundaries

The endpoints cover the workflows across all 14 supplied epics. Product and invoice stock changes, purchase receiving, returns, and voids are transactional and produce stock-movement and audit records. Product/category/customer/supplier data, settings, notifications, and operational records are persisted through JPA.

This starting scaffold intentionally has **no authentication or authorization**: role-permission settings can be stored, but are not enforced, and audit entries use the actor `system`. Do not expose it to untrusted clients or use it for production transactions until authentication, role enforcement, and production database migrations are added.

Email and SMS notification channels are recorded as notification delivery preferences/intents only; no provider credentials or delivery adapters are configured. Barcode labels are printable HTML containing the product and barcode text; generating barcode images/standards-compliant label formats requires a printer-specific or barcode-generation integration. Offline scans are stored by the API when connectivity is available and can be synchronized into an invoice; the POS client must retain its queue while disconnected.

## Tests

Run the application and API workflow tests with:

```powershell
.\mvnw.cmd test
```
